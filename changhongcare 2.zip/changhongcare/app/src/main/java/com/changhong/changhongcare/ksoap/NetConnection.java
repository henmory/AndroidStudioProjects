package com.changhong.changhongcare.ksoap;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.util.Log;

import com.changhong.changhongcare.structFromService.MessageModel;

import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

/**
 * author: henmory
 * time:  11/18/16
 * function:
 * description:该文件主要查看网络通信是否正常
 */

public abstract class NetConnection {

    private final String tag = "NetConnection";

    private MessageModel messageModel = new MessageModel();//从服务器返回的数据结构
    private static boolean isConnecting = false;//网络正忙的标志

    public static AsyncTask<Void, Void, SoapObject> getTask() {
        return task;
    }

    public static AsyncTask<Void,Void,SoapObject> task;//网络线程标志


    private void setMessageModelFromSoapObject(SoapObject soapObject){
        SoapPrimitive soapPrimitive;
        Object object;
        object = soapObject.getProperty(KsoapConfig.MessageModel.ReturnMesssage);//返回内容结果描述
        messageModel.setReturnMessage(object.toString());

        object = soapObject.getProperty(KsoapConfig.MessageModel.ReturnObject);//返回内容
        messageModel.setReturnObject(object);
        if (null != object){
            Log.d(tag, "ReturnObject = " + object.toString());
        }

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(KsoapConfig.MessageModel.ReturnStatus);//获取结果值
        String string = (String) soapPrimitive.getValue();
        int ret  = Integer.parseInt(string);
        messageModel.setReturnStatus(ret);
    }


    public NetConnection(Context context, final HttpTransportSE transport, final String soapAction,
                         final SoapSerializationEnvelope envelope){

        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();
        // TODO: 11/18/16 测试网络接口
        //没有网络或者网络连接忙
        if (info == null ||  !info.isConnected()){
            messageModel.setReturnMessage("net error");
            messageModel.setReturnStatus(0);
            netConnectionFail(messageModel);
            return;
        }
        //上次调用没有完成，等待上次结束后再用
        if (isConnecting){
            messageModel.setReturnMessage("net is busy");
            messageModel.setReturnStatus(0);
            netConnectionFail(messageModel);
            return;
        }
        task = new AsyncTask<Void, Void, SoapObject>() {
            /**
             *  @author henmory
             *  @date 11/23/16
             *  @description    如果客户端是强制取消的，无论该函数执行到哪里，这个线程都会中断，并调用onCancelled
             *                  如果客户端不是强制的，如果取消在iscalled之前，那么不会继续网络连接
             *                  如果已经执行过，那么程序会继续下载，完成后调用oncalled
             *  @param
             *
             *
             *  @return
             */
            @Override
            protected SoapObject doInBackground(Void... params) {
                Log.d(tag,"doInBackground");
                try {
                    if (isCancelled()){
                        isConnecting = false;
                        return null;
                    }
                    isConnecting = true;
                    Log.d(tag,"soapaction = " + soapAction + "; envelope = " + envelope);
                    transport.call(soapAction, envelope);
                    SoapObject soapObject = (SoapObject) envelope.getResponse();
                    Log.d(tag, "doInBackground = " + soapObject.toString());
                    return soapObject;
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }
            /**
             *  @author henmory
             *  @date 11/23/16
             *  @description    客户端只有发生取消操作都不会执行
             *                  oncalled的优先级要高于自己
             *
             *  @param
             *
             *  @return
             */
            @Override
            protected void onPostExecute(SoapObject soapObject) {
                super.onPostExecute(soapObject);
                isConnecting = false;
                if (isCancelled()){
                    Log.d(tag,"用户取消网络....");
                    return;
                }
                if (null == soapObject) {//出现异常
                    Log.d(tag, "exception error");
                    messageModel.setReturnMessage("网络错误");
                    messageModel.setReturnStatus(0);
                    messageModel.setReturnObject(null);
                    netConnectionFail(messageModel);
                } else {//通信正常
                    setMessageModelFromSoapObject(soapObject);
                    netConnectionSuccess(messageModel);
                }
                task = null;
            }
            /**
             *  @author henmory
             *  @date 11/23/16
             *  @description    只要发生取消操作就行执行
             *
             *  @param
             *
             *  @return
             */
            @Override
            protected void onCancelled() {
                Log.d(tag,"onCancelled");
                isConnecting = false;
                task = null;
            }
        }.execute();
    }
    //这两个接口，主要任务是判断通信是否正常
    public abstract void netConnectionSuccess(Object data);//通信完成
    public abstract void netConnectionFail(Object data);//通信失败




}
