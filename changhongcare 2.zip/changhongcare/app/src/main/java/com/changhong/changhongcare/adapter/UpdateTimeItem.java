package com.changhong.changhongcare.adapter;

/**
 * author: henmory
 * time:  12/19/16
 * function:
 * description:
 */

public class UpdateTimeItem {
    private int icon;
    private String description;
    private int select;

    public UpdateTimeItem(int icon, String description, int select) {
        this.icon = icon;
        this.description = description;
        this.select = select;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getSelect() {
        return select;
    }

    public void setSelect(int select) {
        this.select = select;
    }

    @Override
    public String toString() {
        return "UpdateTimeItem{" +
                "icon=" + icon +
                ", description='" + description + '\'' +
                ", select=" + select +
                '}';
    }
}
