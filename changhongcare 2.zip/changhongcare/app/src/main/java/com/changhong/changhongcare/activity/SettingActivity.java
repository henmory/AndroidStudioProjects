package com.changhong.changhongcare.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.changhong.changhongcare.R;
import com.changhong.changhongcare.adapter.SettingItem;
import com.changhong.changhongcare.adapter.SettingItemAdapter;

import java.util.ArrayList;
import java.util.List;

public class SettingActivity extends AppCompatActivity {

    private ListView listView;
    private SettingItemAdapter adapter;
    private List<SettingItem> settingItems = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listView = (ListView) findViewById(R.id.lv_setting_item);
        settingItems.add(new SettingItem(R.drawable.account_and_safe, "账号与安全", R.drawable.go_to_next));
        settingItems.add(new SettingItem(R.drawable.new_message_notify, "新消息通知", R.drawable.go_to_next));
        settingItems.add(new SettingItem(R.drawable.secret, "隐私", R.drawable.go_to_next));
        settingItems.add(new SettingItem(R.drawable.about_us, "关于我们", R.drawable.go_to_next));
        settingItems.add(new SettingItem(R.drawable.share, "分享", R.drawable.go_to_next));
        adapter = new SettingItemAdapter(settingItems, this, R.layout.list_item_setting);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 0://账号与安全
                        break;
                    case 1://新消息通知
                        break;
                    case 2://隐私
                        break;
                    case 3://关于我们
                        startActivity(new Intent(SettingActivity.this, AboutUsActivity.class));
                        break;
                    case 4://分享
                        break;

                }
            }
        });
    }

}
