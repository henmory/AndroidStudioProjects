package com.changhong.changhongcare.deprecated;
// TODO: 2/10/17 已经遗弃 
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.Callback;
import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.activity.AmapActivity;
import com.changhong.changhongcare.activity.LoginActivity;
import com.changhong.changhongcare.ksoap.DevicesService;
import com.changhong.changhongcare.ksoap.PersonService;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.utils.MyGestureDetectorListener;

public class Boot_2Activity extends AppCompatActivity {

    private final static String tag = "Boot_2Activity";
    private MyGestureDetectorListener myGestureDetector;
    private GestureDetector mDetector;
    private Button btnExperienceImediately;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boot_2);
        Log.d(tag, "booot_2");

        myGestureDetector = new MyGestureDetectorListener() {
            @Override
            public void handleToLeft() {
            }

            @Override
            public void handleToRight() {
                startActivity(new Intent(Boot_2Activity.this,Boot_1Activity.class));
//                overridePendingTransition(0,0);
                finish();
            }
        };
        mDetector = new GestureDetector(this, myGestureDetector);

        bindview();
    }


    void bindview(){
        btnExperienceImediately = (Button) findViewById(R.id.btn_experience_imediately);
        btnExperienceImediately.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnExperienceImediately.setBackgroundResource(R.drawable.experience_imediately_clicked);
                startApp();
            }
        });
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        return mDetector.onTouchEvent(event);
    }



    void startApp(){
        Config.initAppPara(this);
        ifNeedEntryLogin(this);
    }

    /**
     *  @author henmory
     *  @date 11/23/16
     *  @description    1.没有记住用户名密码,进入登陆界面
     *                  2.信息不全，进入登陆界面
     *                  3.信息全，登陆失败，进入登陆界面
     *                  4.信息全，登陆成功，进入主界面
     *
     *
     *  @param
     *
     *  @return
     */

    void ifNeedEntryLogin(final Activity activity) {

        if (0 == Config.passwordRememberedFlag) {
            Log.d(tag,"没有记录密码");
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        } else if (TextUtils.isEmpty(Config.phoneNumber) || TextUtils.isEmpty(Config.password)) {
            Log.d(tag,"记录密码，但是其中为空");
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        } else {
            Log.d(tag, "从配置文件中获取数据，登陆");
            entryMainActivityFromBoot(activity);
        }
    }

    void entryMainActivityFromBoot(final  Activity activity){

        final CustomProgressDialog customProgressDialog = new CustomProgressDialog(activity,
                "应用程序加载中...");
        customProgressDialog.show();
//        ProgressDialog.show(activity, null, "应用程序加载中,请稍后...",false,true);
        Log.d(tag, "phone = " + Config.phoneNumber + "; password = " + Config.password);
        PersonService.login(activity, Config.phoneNumber, Config.password, new SuccessCallback() {
            @Override
            public void onSuccess(Object data) {
//                String token = (String) data;
//                Config.cacheToken(Boot_2Activity.this,token);//缓冲token

                //获取其它数据,无论失败还是成功，都要进入主界面
                DevicesService.getBindDevicesPositionList(Boot_2Activity.this, Config.phoneNumber, new Callback() {
                    @Override
                    public void callBack(Object o) {
                        startActivity(new Intent(Boot_2Activity.this, AmapActivity.class));
                        customProgressDialog.dismiss();
                    }
                });
                finish();

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object data) {
                customProgressDialog.dismiss();
                Toast.makeText(activity, data.toString(),Toast.LENGTH_SHORT).show();
                startActivity(new Intent(activity, LoginActivity.class));
                finish();

            }
        });
    }
}
