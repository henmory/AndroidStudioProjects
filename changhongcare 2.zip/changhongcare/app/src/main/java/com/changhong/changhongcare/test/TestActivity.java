package com.changhong.changhongcare.test;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.ksoap.DevicesService;
import com.changhong.changhongcare.ksoap.PersonService;


public class TestActivity extends AppCompatActivity {

    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        btn = (Button) findViewById(R.id.btn_test);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                testGetFamilyNums();
//                testGetBindDevicePositionList();
//                testGetBindDeviceUploadPositionInterval();
                testGetBindDeviceHistoryTrace();
//                testsetBindDeviceUploadPositionInterval();
            }


        });
    }
    void testLogin() {
        //登陆接口测试
        PersonService.login(TestActivity.this, "13488783239", "12345", new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                System.out.println("login success");
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                System.out.println("login failed");

            }
        });
    }

    void testGetBindDeviceList() {
        DevicesService.getBindDevicesList(TestActivity.this, "13488783239", new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                System.out.println("getBindDevicesList success = " + object.toString());

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                System.out.println("getBindDevicesList failed" + object.toString());

            }
        });
    }

    void testGetBindDevicePositionList() {
        DevicesService.getBindDevicesPositionList(TestActivity.this, "13488783239", 1 + "", new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                System.out.println("getBindDevicesPositionList success");
                System.out.println(object.toString());

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                System.out.println("getBindDevicesPositionList failed");

            }
        });

    }
    void testGetFamilyNums(){
        DevicesService.getDeviceFamilyNumbers(TestActivity.this, 1843387 + "", new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {

            }
        });
    }

    void testGetBindDeviceUploadPositionInterval(){
        DevicesService.getBindDeviceUploadPositionInterval(TestActivity.this, 1843387 + "", new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {

            }
        });
    }
    void testsetBindDeviceUploadPositionInterval(){
        DevicesService.setBindDeviceUploadPositionInterval(TestActivity.this, 1238387 + "", 600, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {

            }
        });
    }
    void testGetBindDeviceHistoryTrace(){
        DevicesService.getBindDeviceHistoryTrace(TestActivity.this, "17716154076", 1, 210209 + "", "2017-1-11 00:00", "2017-1-11 23:59", 1,
                new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {

                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        Toast.makeText(TestActivity.this, object.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
