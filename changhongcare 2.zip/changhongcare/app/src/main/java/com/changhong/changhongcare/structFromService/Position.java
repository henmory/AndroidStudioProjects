package com.changhong.changhongcare.structFromService;


/**
 * author: henmory
 * time:  11/3/16
 * function:
 * description:
 */

public class Position {
    private String accStatus;
    private String  address;
    private String alarm;//警报
    private String cellID;//基站id
    private int deviceBell;
    private String deviceID;//设备ID
    private String deviceIMEI;
    private String deviceName;
    private String deviceTele;
    private int deviceType;
    private String deviceTypeName;
    private int direction;
    private int fenceNum;
    private String firstLinkManTel;
    private String firstUseTime;
    private String garrisonStatus;
    private int garrisonSwitch;
    private String gpsTime;//定位时间???
    private int gsm;//GSM信号强度(1~6)
    private int highSpeed;
    private double la;
    private double lo;
    private String locationTimeSpan;
    private String mileage;
    private String mileageDate;
    private String nickName;
    private String openAccountTime;
    private int pointed;//定位模式(0~5), 0:定位失败, 1:混合定位(GPS), 2:混合定位(基站), 3:混合定位(定位中, 即二者均无法定位), 4:基站定位(成功), 5:基站定位(定位中, 即无法定位)
    private int positionMode;
    private int power; //电量(0~100)??(或0~5)不确定
    private String relayStatus;
    private int statelliteNum;
    private String serviceEndTime;
    private int speed;
    private String status;//状态(0: 离线, 1: 在线)
    private int totalMileage;

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    private String imgUrl;

    public int getTotalMileage() {
        return totalMileage;
    }

    public void setTotalMileage(int totalMileage) {
        this.totalMileage = totalMileage;
    }

    public String getAccStatus() {
        return accStatus;
    }

    public void setAccStatus(String accStatus) {
        this.accStatus = accStatus;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAlarm() {
        return alarm;
    }

    public void setAlarm(String alarm) {
        this.alarm = alarm;
    }

    public String getCellID() {
        return cellID;
    }

    public void setCellID(String cellID) {
        this.cellID = cellID;
    }

    public int getDeviceBell() {
        return deviceBell;
    }

    public void setDeviceBell(int deviceBell) {
        this.deviceBell = deviceBell;
    }

    public String getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(String deviceID) {
        this.deviceID = deviceID;
    }

    public String getDeviceIMEI() {
        return deviceIMEI;
    }

    public void setDeviceIMEI(String deviceIMEI) {
        this.deviceIMEI = deviceIMEI;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDeviceTele() {
        return deviceTele;
    }

    public void setDeviceTele(String deviceTele) {
        this.deviceTele = deviceTele;
    }

    public int getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(int deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceTypeName(Object property) {
        return deviceTypeName;
    }

    public void setDeviceTypeName(String deviceTypeName) {
        this.deviceTypeName = deviceTypeName;
    }

    public int getDirection() {
        return direction;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    public int getFenceNum() {
        return fenceNum;
    }

    public void setFenceNum(int fenceNum) {
        this.fenceNum = fenceNum;
    }

    public String getFirstLinkManTel() {
        return firstLinkManTel;
    }

    public void setFirstLinkManTel(String firstLinkManTel) {
        this.firstLinkManTel = firstLinkManTel;
    }

    public String getFirstUseTime() {
        return firstUseTime;
    }

    public void setFirstUseTime(String firstUseTime) {
        this.firstUseTime = firstUseTime;
    }

    public String getGarrisonStatus() {
        return garrisonStatus;
    }

    public void setGarrisonStatus(String garrisonStatus) {
        this.garrisonStatus = garrisonStatus;
    }

    public int getGarrisonSwitch() {
        return garrisonSwitch;
    }

    public void setGarrisonSwitch(int garrisonSwitch) {
        this.garrisonSwitch = garrisonSwitch;
    }

    public String getGpsTime() {
        return gpsTime;
    }

    public void setGpsTime(String gpsTime) {
        this.gpsTime = gpsTime;
    }

    public int getGsm() {
        return gsm;
    }

    public void setGsm(int gsm) {
        this.gsm = gsm;
    }

    public int getHighSpeed() {
        return highSpeed;
    }

    public void setHighSpeed(int highSpeed) {
        this.highSpeed = highSpeed;
    }

    public double getLa() {
        return la;
    }

    public void setLa(double la) {
        this.la = la;
    }

    public double getLo() {
        return lo;
    }

    public void setLo(double lo) {
        this.lo = lo;
    }

    public String getLocationTimeSpan() {
        return locationTimeSpan;
    }

    public void setLocationTimeSpan(String locationTimeSpan) {
        this.locationTimeSpan = locationTimeSpan;
    }

    public String getMileage() {
        return mileage;
    }

    public void setMileage(String mileage) {
        this.mileage = mileage;
    }

    public String getMileageDate() {
        return mileageDate;
    }

    public void setMileageDate(String mileageDate) {
        this.mileageDate = mileageDate;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getOpenAccountTime() {
        return openAccountTime;
    }

    public void setOpenAccountTime(String openAccountTime) {
        this.openAccountTime = openAccountTime;
    }

    public int getPointed() {
        return pointed;
    }

    public void setPointed(int pointed) {
        this.pointed = pointed;
    }

    public int getPositionMode() {
        return positionMode;
    }

    public void setPositionMode(int positionMode) {
        this.positionMode = positionMode;
    }

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public String getRelayStatus() {
        return relayStatus;
    }

    public void setRelayStatus(String relayStatus) {
        this.relayStatus = relayStatus;
    }

    public int getStatelliteNum() {
        return statelliteNum;
    }

    public void setStatelliteNum(int statelliteNum) {
        this.statelliteNum = statelliteNum;
    }

    public String getServiceEndTime() {
        return serviceEndTime;
    }

    public void setServiceEndTime(String serviceEndTime) {
        this.serviceEndTime = serviceEndTime;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Position{" +
                "accStatus='" + accStatus + '\'' +
                ", address='" + address + '\'' +
                ", alarm='" + alarm + '\'' +
                ", cellID='" + cellID + '\'' +
                ", deviceBell=" + deviceBell +
                ", deviceID=" + deviceID +
                ", deviceIMEI='" + deviceIMEI + '\'' +
                ", deviceName='" + deviceName + '\'' +
                ", deviceTele='" + deviceTele + '\'' +
                ", deviceType=" + deviceType +
                ", deviceTypeName='" + deviceTypeName + '\'' +
                ", direction=" + direction +
                ", fenceNum=" + fenceNum +
                ", firstLinkManTel='" + firstLinkManTel + '\'' +
                ", firstUseTime='" + firstUseTime + '\'' +
                ", garrisonStatus='" + garrisonStatus + '\'' +
                ", garrisonSwitch=" + garrisonSwitch +
                ", gpsTime='" + gpsTime + '\'' +
                ", gsm=" + gsm +
                ", highSpeed=" + highSpeed +
                ", la=" + la +
                ", lo=" + lo +
                ", locationTimeSpan='" + locationTimeSpan + '\'' +
                ", mileage='" + mileage + '\'' +
                ", mileageDate='" + mileageDate + '\'' +
                ", nickName='" + nickName + '\'' +
                ", openAccountTime='" + openAccountTime + '\'' +
                ", pointed=" + pointed +
                ", positionMode=" + positionMode +
                ", power=" + power +
                ", relayStatus='" + relayStatus + '\'' +
                ", statelliteNum=" + statelliteNum +
                ", serviceEndTime='" + serviceEndTime + '\'' +
                ", speed=" + speed +
                ", status='" + status + '\'' +
                ", totalMileage=" + totalMileage +
                '}';
    }
}
