package com.changhong.changhongcare.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.changhong.changhongcare.R;
import com.changhong.changhongcare.adapter.HelpItem;
import com.changhong.changhongcare.adapter.HelpItemAdapter;
import com.changhong.changhongcare.adapter.SettingItem;
import com.changhong.changhongcare.adapter.SettingItemAdapter;

import java.util.ArrayList;
import java.util.List;

public class HelpActivity extends AppCompatActivity {
    private ListView listView;
    private HelpItemAdapter adapter;
    private List<HelpItem> helpItems = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listView = (ListView) findViewById(R.id.lv_help_item);
        helpItems.add(new HelpItem(R.drawable.function_description, "功能介绍", R.drawable.go_to_next));
//        helpItems.add(new HelpItem(R.drawable.question_feedback, "问题反馈", R.drawable.go_to_next));
        adapter = new HelpItemAdapter(helpItems, this, R.layout.list_item_help);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 0://功能介绍
                        startActivity(new Intent(HelpActivity.this, DescriptionActivity.class));
                        break;
//                    case 1://问题反馈
//                        startActivity(new Intent(HelpActivity.this, QuestionFeedbackActivity.class));
//                        break;
                }
            }
        });
    }

}
