package com.changhong.changhongcare.Interface;

/**
 * author: henmory
 * time:  11/18/16
 * function:
 * description:
 */

public interface FailCallback {
     void onFail(Object object);
}
