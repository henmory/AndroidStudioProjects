package com.changhong.changhongcare.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.Callback;
import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.ksoap.DevicesService;
import com.changhong.changhongcare.ksoap.PersonService;

public class ModifyPasswordActivity extends AppCompatActivity {

    private EditText evPhoneNumber;
    private EditText evCode;
    private EditText evOldPassword;
    private EditText evNewPassword;
    private Button btnModifyPassword;
    private Button btnGetCode;
    private String num;
    private String Code;
    private String oldPassword ;
    private String newPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_password);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        bindViews();
    }


    private void bindViews(){
        evPhoneNumber = (EditText) findViewById(R.id.et_phone_number);
        evCode = (EditText) findViewById(R.id.et_sms_code);
        evOldPassword = (EditText) findViewById(R.id.et_old_password);
        evNewPassword = (EditText) findViewById(R.id.et_new_password);
        btnModifyPassword = (Button) findViewById(R.id.btn_modify);
        btnGetCode = (Button) findViewById(R.id.btn_get_code);

        btnGetCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                num = evPhoneNumber.getText().toString();

                if (TextUtils.isEmpty(num)){
                    Toast.makeText(ModifyPasswordActivity.this, "电话号码不能为空", Toast.LENGTH_SHORT).show();
                }else{

                    final CustomProgressDialog customProgressDialog = new CustomProgressDialog(ModifyPasswordActivity.this, "获取验证码...");
                    customProgressDialog.show();

                    PersonService.getCode(ModifyPasswordActivity.this, num, new SuccessCallback() {
                        @Override
                        public void onSuccess(Object data) {
                            customProgressDialog.dismiss();
                            Toast.makeText(ModifyPasswordActivity.this, "验证码发送成功",Toast.LENGTH_SHORT).show();
                        }
                    }, new FailCallback() {
                        @Override
                        public void onFail(Object data) {
                            customProgressDialog.dismiss();
                            Toast.makeText(ModifyPasswordActivity.this, data.toString(),Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });

        btnModifyPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Code = evCode.getText().toString();
                oldPassword = evOldPassword.getText().toString();
                newPassword = evNewPassword.getText().toString();
                if (TextUtils.isEmpty(num)){
                    Toast.makeText(ModifyPasswordActivity.this, "验证码错误", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(Code) || TextUtils.isEmpty(oldPassword) || TextUtils.isEmpty(newPassword)){
                    Toast.makeText(ModifyPasswordActivity.this, "字段不能为空", Toast.LENGTH_SHORT).show();
                }else {

                    final CustomProgressDialog customProgressDialog = new CustomProgressDialog(ModifyPasswordActivity.this, "修改密码...");
                    customProgressDialog.show();

                    PersonService.isVerCodeCorrect(ModifyPasswordActivity.this, num, Code, new SuccessCallback() {

                        //验证验证码正确，重置密码
                        @Override
                        public void onSuccess(Object data) {

                            //修改密码
                            PersonService.modifyPwd(ModifyPasswordActivity.this, num, newPassword, oldPassword, new SuccessCallback() {
                                @Override
                                public void onSuccess(Object object) {
                                    customProgressDialog.dismiss();
                                    Toast.makeText(ModifyPasswordActivity.this, "修改密码成功",Toast.LENGTH_SHORT).show();
                                    finish();//删除本页面
                                    UserAccountActivity.mInstance.finish();

                                }
                            }, new FailCallback() {
                                @Override
                                public void onFail(Object object) {
                                    customProgressDialog.dismiss();
                                    Toast.makeText(ModifyPasswordActivity.this, object.toString(),Toast.LENGTH_SHORT).show();

                                }
                            });

                        }
                    }, new FailCallback() {
                        //验证码失败后，提示用户错误
                        @Override
                        public void onFail(Object data) {
                            customProgressDialog.dismiss();
                            Toast.makeText(ModifyPasswordActivity.this, data.toString(),Toast.LENGTH_SHORT).show();
                        }
                    });
                }

            }
        });
    }

}
