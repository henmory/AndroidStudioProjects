package com.changhong.changhongcare.adapter;

import android.content.Context;

import com.changhong.changhongcare.R;
import com.changhong.changhongcare.activity.FamilyNumberSettingActivity;
import com.changhong.changhongcare.utils.CommonAdapter;
import com.changhong.changhongcare.utils.CommonViewHolder;

import java.util.List;

/**
 * author: henmory
 * time:  12/6/16
 * function:
 * description:
 */

public class FamilyNumberItemAdapter extends CommonAdapter<FamilyNumItem> {

    public FamilyNumberItemAdapter(List<FamilyNumItem> mDatas, Context mContext, int mItemLayout) {
        super(mDatas, mContext, mItemLayout);
    }

    @Override
    public void convert(CommonViewHolder holder, FamilyNumItem familyNumItem) {
        holder.setText(R.id.tv_family_num_description, familyNumItem.getDescription());
        holder.setImageResource(R.id.iv_family_num_image,familyNumItem.getIcon());
        //添加按钮的点击事件
//        holder.setOnClickListener(R.id.iv_family_num_image, new FamilyNumberSettingActivity());
    }
}
