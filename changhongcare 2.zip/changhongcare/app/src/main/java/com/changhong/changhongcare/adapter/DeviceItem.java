package com.changhong.changhongcare.adapter;

import android.widget.ImageView;

/**
 * author: henmory
 * time:  12/19/16
 * function:
 * description: 绑定设备列表
 */

public class DeviceItem {
    private String name;
    private int icon;
    private int operation;

    public DeviceItem(String name, int icon, int operation) {
        this.name = name;
        this.icon = icon;
        this.operation = operation;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public int getOperation() {
        return operation;
    }

    public void setOperation(int operation) {
        this.operation = operation;
    }

    @Override
    public String toString() {
        return "DeviceItem{" +
                "name='" + name + '\'' +
                ", icon=" + icon +
                ", operation=" + operation +
                '}';
    }
}
