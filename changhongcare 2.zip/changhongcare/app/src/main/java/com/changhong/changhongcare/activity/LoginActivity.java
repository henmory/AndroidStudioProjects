package com.changhong.changhongcare.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.Callback;
import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.ksoap.DevicesService;
import com.changhong.changhongcare.ksoap.PersonService;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.customview.CustomProgressDialog;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{
    private final String tag = "LoginActivity";
    private EditText etPhoneNumber;
    private EditText etPassword;
    private Button btnLogin;
    private Button btnReigster;
    private TextView tvForgetPassword;
//    private ImageView ivSelectPassword;
    public static LoginActivity mInstace = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        bindView();
        initViewPara();
        Log.d(tag, "if remember password = " + Config.passwordRememberedFlag);
        Log.d(tag, "sp file phoneNumber = " + Config.phoneNumber + "; password = " + Config.password);
        mInstace = this;
    }
    void bindView(){
        etPhoneNumber = (EditText) findViewById(R.id.et_phone_number);
        etPassword = (EditText) findViewById(R.id.et_password);
        btnLogin = (Button) findViewById(R.id.btn_login);
        btnReigster = (Button) findViewById(R.id.btn_register);
        tvForgetPassword = (TextView) findViewById(R.id.tv_forget_password);
//        ivSelectPassword = (ImageView) findViewById(R.id.iv_select_password);
        btnLogin.setOnClickListener(this);
        btnReigster.setOnClickListener(this);
        tvForgetPassword.setOnClickListener(this);
//        ivSelectPassword.setOnClickListener(this);
    }
    void initViewPara(){
        if (1 == Config.passwordRememberedFlag){
//            ivSelectPassword.setImageResource(R.drawable.selected);
            etPhoneNumber.setText(Config.phoneNumber);
            etPassword.setText(Config.password);
        }else{
//            ivSelectPassword.setImageResource(R.drawable.unselected);
        }

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_login:
                login();
                break;
            case R.id.btn_register:
                register();
                break;
            case R.id.tv_forget_password:
                forgetPassword();
//            case R.id.iv_select_password:
//                checkboxIfChecked();
//                break;
        }
    }
    /**
     *  @author henmory
     *  @date 11/19/16
     *  @description    单击登陆按钮逻辑处理
     *                  填入信息不完全，提示
     *                  否则，判断是否保存密码逻辑，之后登陆
     *
     *
     *  @param
     *
     *  @return
    */
    void login(){
        Config.phoneNumber = etPhoneNumber.getText().toString();
        Config.password = etPassword.getText().toString();
        if (Config.phoneNumber.length() == 0 || Config.password.length() == 0){
            Toast.makeText(LoginActivity.this, "输入错误",Toast.LENGTH_SHORT).show();
        }else {
            //不予判断是否记住密码，改为登陆成功自动保存
//            ifRememberPhoneNumAndPassword();//判断是否保存密码逻辑
            Log.d(tag, "start log, phonenumber = " + Config.phoneNumber + "; password = " + Config.password);
            entryMainActivityFromLoginActivity(this);//登陆
        }

    }

    /**
     *  @author henmory
     *  @date 12/9/16
     *  @description    从登陆界面进入主界面
     *                  登陆成功后，先不进入主界面，要从服务器获取其它信息
     *                  无论获取是否成功都进入主界面
     *
     *  @param
     *
     *  @return
    */
    void entryMainActivityFromLoginActivity(final Activity activity){

        final CustomProgressDialog customProgressDialog = new CustomProgressDialog(activity, "登陆中...");
        customProgressDialog.show();


        PersonService.login(this, Config.phoneNumber, Config.password, new SuccessCallback() {
            @Override
            public void onSuccess(Object data) {
                //登陆成功，缓冲token
//                String token = (String) data;
//                Config.cacheToken(LoginActivity.this,token);//缓冲token
                Config.cachePhoneNumber(LoginActivity.this, Config.phoneNumber);
                Config.cachePassword(LoginActivity.this, Config.password);

                //获取其它数据,无论失败还是成功，都要进入主界面
                DevicesService.getBindDevicesPositionList(LoginActivity.this, Config.phoneNumber, new Callback() {
                    @Override
                    public void callBack(Object o) {
                        startActivity(new Intent(LoginActivity.this, AmapActivity.class));

                        customProgressDialog.dismiss();
                    }
                });
                finish();

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object data) {
                Log.d(tag, "login error code = " + data);
                customProgressDialog.dismiss();
                Toast.makeText(LoginActivity.this, data.toString(),Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     *  @author henmory
     *  @date 11/19/16
     *  @description 点击注册按钮，逻辑处理
     *
     *  @param
     *
     *  @return
    */
    void register(){
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }

    /**
     *  @author henmory
     *  @date 11/21/16
     *  @description    忘记密码处理逻辑
     *
     *  @param
     *
     *  @return
    */

    void forgetPassword(){
        Log.d(tag,"forget password");
        startActivity(new Intent(this, ForgetPasswordActivity.class));

    }
    /**
     *  @author henmory
     *  @date 11/19/16
     *  @description    记住密码checkbox是否选中
     *
     *  @param
     *
     *  @return
    */

    @Deprecated
    void checkboxIfChecked(){
        if (1 == Config.passwordRememberedFlag){
            Config.passwordRememberedFlag = 0;
//            ivSelectPassword.setImageResource(R.drawable.unselected);
            Config.cachePasswordRememberedFlag(this, 0);
        }else{
            Config.passwordRememberedFlag = 1;
//            ivSelectPassword.setImageResource(R.drawable.selected);

            Config.cachePasswordRememberedFlag(this, 1);
        }
        Log.d(tag, "remember password state change, state = " +  Config.passwordRememberedFlag);
    }

    /**
     *  @author henmory
     *  @date 11/24/16
     *  @description    点击登陆和注册时，如果记录，那么写入sp中
     *                  否则，从sp中移除
     *
     *  @param
     *
     *  @return
    */
    @Deprecated
    void ifRememberPhoneNumAndPassword(){

        Config.phoneNumber = etPhoneNumber.getText().toString();
        Config.password = etPassword.getText().toString();

        if (1 == Config.passwordRememberedFlag) {
            Config.cachePhoneNumber(this, Config.phoneNumber);
            Config.cachePassword(this, Config.password);
        } else {
            Config.removePhoneNumber(this);
            Config.removePassword(this);
        }


    }


}
