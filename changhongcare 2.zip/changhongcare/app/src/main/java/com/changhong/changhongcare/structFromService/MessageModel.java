package com.changhong.changhongcare.structFromService;


/**
 * author: henmory
 * time:  11/18/16
 * function:
 * description:
 */

public class MessageModel {
        private String ReturnMessage;
        private Object ReturnObject;
        private int ReturnStatus;

        public int getReturnStatus() {
            return ReturnStatus;
        }

        public void setReturnStatus(int returnStatus) {
            ReturnStatus = returnStatus;
        }

        public String getReturnMessage() {
            return ReturnMessage;
        }

        public void setReturnMessage(String returnMessage) {
            ReturnMessage = returnMessage;
        }

        public Object getReturnObject() {
            return ReturnObject;
        }

        public void setReturnObject(Object returnObject) {
            ReturnObject = returnObject;
        }

        @Override
        public String toString() {
            return "ReturnStatus = " + ReturnStatus + "; ReturnMessage = " + ReturnMessage + "; ReturnObject = " + ReturnObject.toString();
        }
}
