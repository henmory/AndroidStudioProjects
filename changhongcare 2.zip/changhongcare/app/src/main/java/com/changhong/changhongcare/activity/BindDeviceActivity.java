package com.changhong.changhongcare.activity;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.changhong.changhongcare.R;

import java.util.ArrayList;
import java.util.List;

public class BindDeviceActivity extends AppCompatActivity {

    private static final String TAG = "BindDeviceActivity";
    private EditText etFeaturePhoneNum;
    private RadioGroup rgSmartPhoneNum;
    private RadioButton radioButton1;
    private RadioButton radioButton2;
    private Button btnBind;
    private List<String> numbers = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bind_device);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        bindViews();
//        initDatas();
    }

    void bindViews(){
        etFeaturePhoneNum = (EditText) findViewById(R.id.et_bind_numer);
        rgSmartPhoneNum = (RadioGroup) findViewById(R.id.rg);
        radioButton1 = (RadioButton) findViewById(R.id.rb_number_1);
        radioButton2 = (RadioButton) findViewById(R.id.rb_number_2);
        btnBind = (Button) findViewById(R.id.btn_bind);

        btnBind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int select_id = rgSmartPhoneNum.getCheckedRadioButtonId();
                String smartPhoneNumber =  etFeaturePhoneNum.getText().toString();
                bindDevice(numbers.get(select_id), smartPhoneNumber);

            }
        });

    }
    //目前只支持双卡
    void initDatas(){
        getNativePhoneNumbers();
        radioButton1.setChecked(true);
        radioButton1.setText(numbers.get(0));
        if (numbers.size() > 1){
            radioButton2.setChecked(false);
            radioButton2.setText(numbers.get(1));
        }
    }

    //获取本机的电话号码
    void getNativePhoneNumbers(){
        TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        String numbers = tm.getLine1Number();
        Log.d(TAG, numbers);
    }

    void bindDevice(String smartPhoneNumber, String featurePhoneNumber){

    }

}
