package com.changhong.changhongcare.adapter;


/**
 * author: henmory
 * time:  11/25/16
 * function:
 * description:
 */

public class NavigationItem {
    public NavigationItem(int iconId, String description) {
        this.iconId = iconId;
        this.description = description;
    }

    public int getIconId() {
        return iconId;
    }

    public void setIconId(int iconId) {
        this.iconId = iconId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "NavigationItem{" +
                "iconId=" + iconId +
                ", description=" + description +
                '}';
    }

    private int iconId;
    private String description;


}
