package com.changhong.changhongcare.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.Callback;
import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.ksoap.DevicesService;
import com.changhong.changhongcare.ksoap.PersonService;

import java.util.ArrayList;

public class BootActivity extends AppCompatActivity {

    private final static String tag = "BootActivity";

    private ViewPager mViewPager;
    private Button btnStartApp;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_boot);

        Config.initAppPara(this);

        if (chooseAppEntryWhichActivity()){
            return;
        }
        mViewPager = (ViewPager)findViewById(R.id.viewpager);

        //将要分页显示的View装入数组中
        LayoutInflater mLi = LayoutInflater.from(this);
        View view1 = mLi.inflate(R.layout.content_boot_1, null);
        View view2 = mLi.inflate(R.layout.content_boot_2, null);

        //每个页面的数据
        final ArrayList<View> views = new ArrayList<View>();
        views.add(view1);
        views.add(view2);

        //填充ViewPager的数据适配器
        PagerAdapter mPagerAdapter = new PagerAdapter() {

            @Override
            public boolean isViewFromObject(View arg0, Object arg1) {
                return arg0 == arg1;
            }

            @Override
            public int getCount() {
                return views.size();
            }

            @Override
            public void destroyItem(ViewGroup container, int position, Object object) {
                ((ViewPager)container).removeView(views.get(position));
            }

//                @Override
//                public CharSequence getPageTitle(int position) {
//                    return titles.get(position);
//                }
            @Override
            public Object instantiateItem(ViewGroup container, int position) {
                ((ViewPager)container).addView(views.get(position));
                View view = views.get(position);
                if (position == 1){
                    btnStartApp = (Button) view.findViewById(R.id.btn_experience_imediately);
                    btnStartApp.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startApp();
                        }
                    });
                }

                return views.get(position);
            }
        };

        mViewPager.setAdapter(mPagerAdapter);
    }


    /**
     *  @author henmory
     *  @date 2/15/17
     *  @description    用户点击开始体验，进入登陆界面
     *
     *  @param
     *
     *  @return
    */
    void startApp(){
        Log.d(tag,"第一次进入app，初始化app");
        startActivity(new Intent(this, LoginActivity.class));
        //只有进入登陆界面，以后就不再进入
        Config.cacheEntryBootFlag(this, 0);
        Config.entry_boot_flag = 0;
        finish();
//        ifNeedEntryLogin(this);
    }

    /**
     *  @author henmory
     *  @date 11/23/16
     *  @description    1.没有记住用户名密码,进入登陆界面
     *                  2.信息不全，进入登陆界面
     *                  3.信息全，登陆失败，进入登陆界面
     *                  4.信息全，登陆成功，进入主界面
     *
     *
     *  @param
     *
     *  @return
     */
    @Deprecated
    void ifNeedEntryLogin(final Activity activity) {

        if (0 == Config.passwordRememberedFlag) {
            Log.d(tag,"没有记录密码");
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        } else if (TextUtils.isEmpty(Config.phoneNumber) || TextUtils.isEmpty(Config.password)) {
            Log.d(tag,"记录密码，但是其中为空");
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        } else {
            Log.d(tag, "从配置文件中获取数据，登陆");
            entryMainActivityFromBoot(activity);
        }
    }

    void entryMainActivityFromBoot(final  Activity activity){

        final CustomProgressDialog customProgressDialog = new CustomProgressDialog(activity,
                "应用程序加载中...");
        customProgressDialog.show();
        Log.d(tag, "phone = " + Config.phoneNumber + "; password = " + Config.password);

        PersonService.login(activity, Config.phoneNumber, Config.password, new SuccessCallback() {
            @Override
            public void onSuccess(Object data) {
                //获取其它数据,无论失败还是成功，都要进入主界面
                DevicesService.getBindDevicesPositionList(BootActivity.this, Config.phoneNumber, new Callback() {
                    @Override
                    public void callBack(Object o) {
                        startActivity(new Intent(BootActivity.this, AmapActivity.class));
                        customProgressDialog.dismiss();
                        finish();//删除本activity
                    }
                });

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object data) {
                customProgressDialog.dismiss();
                Toast.makeText(activity, data.toString(),Toast.LENGTH_SHORT).show();
                startActivity(new Intent(activity, LoginActivity.class));
                finish();//删除本activity
            }
        });
    }

    /**
     *  @author henmory
     *  @date 2/15/17
     *  @description    如果用户第一次打开软件，进入导航界面
     *                  如果用户不是第一次进入，同时没有记住用户名和密码，进入登陆界面
     *                  如果用户已经记住了用户名和密码,直接登陆
     *                  登陆成功进入主界面
     *                  登陆失败，进入登陆界面
     *
     *  @param
     *
     *  @return
     *          true 进入登陆界面或者主界面
     *          false 进入导航页
    */
    private boolean chooseAppEntryWhichActivity(){
        //用户第一次打开软件，进入导航页
        if (Config.entry_boot_flag == 1){
            Log.d(tag,"进入boot导航页");
            return false;
        }
        //直接登陆
        if (null != Config.phoneNumber && null != Config.password){
            Log.d(tag,"不进入boot界面，直接登陆");
            entryMainActivityFromBoot(this);
            return true;
        }else{
            Log.d(tag,"进入登陆界面");
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return true;
        }
    }

}
