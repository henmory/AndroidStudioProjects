package com.changhong.changhongcare.activity;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.SmsSendFailedCallback;
import com.changhong.changhongcare.Interface.SmsSendSuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.utils.Utils;

public class AddDeviceActivity extends AppCompatActivity {
    private EditText evFeaturePhoneNumber;
    private Button btnAdd;
    private CustomProgressDialog customProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_device);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        bindViews();
    }

    private void bindViews() {
        evFeaturePhoneNumber = (EditText) findViewById(R.id.et_feature_phone_number);
        btnAdd = (Button) findViewById(R.id.btn_bind);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String featureNum = evFeaturePhoneNumber.getText().toString();
                if (TextUtils.isEmpty(featureNum)) {
                    Toast.makeText(AddDeviceActivity.this, "电话号码不能为空", Toast.LENGTH_SHORT).show();
                } else {
                    customProgressDialog = new CustomProgressDialog(AddDeviceActivity.this, "短信发送中...");
                    customProgressDialog.show();
                    Utils.sendSMS(AddDeviceActivity.this, featureNum, "bd", new SmsSendSuccessCallback() {
                        @Override
                        public void onSucess() {
                            customProgressDialog.dismiss();
                            Toast.makeText(AddDeviceActivity.this,"短信发送成功", Toast.LENGTH_SHORT).show();
                            finish();
                        }

                    }, new SmsSendFailedCallback() {
                        @Override
                        public void onFailed() {
                            customProgressDialog.dismiss();
                            Toast.makeText(AddDeviceActivity.this,"短信发送失败", Toast.LENGTH_SHORT).show();

                        }
                    });
                }
            }
        });
    }
}
