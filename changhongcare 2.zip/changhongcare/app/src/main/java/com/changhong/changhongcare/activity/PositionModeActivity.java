package com.changhong.changhongcare.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.adapter.PositionModeItem;
import com.changhong.changhongcare.adapter.PositionModeItemAdapter;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.ksoap.DevicesService;

import java.util.ArrayList;
import java.util.List;

public class PositionModeActivity extends AppCompatActivity {

    private static final String TAG = "PositionModeActivity";


    private final int update_time_0 = 300;
    private final int update_time_1 = 600;
    private final int update_time_2 = 900;
    private final int update_time_3 = 3600;

    private int position_time;//更新时间
    private int position_index;//对应的索引
    private String deviceID;//设备id


    private ListView listViews;
    private PositionModeItemAdapter adapter;
    private List<PositionModeItem> positionModeItems;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_position_mode);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        initData();
    }

    void initData(){

        //从前一个activity中获取deviceID
        Intent intent = getIntent();
        deviceID = intent.getStringExtra(Config.KEY_DEVICE_ID);

        //从服务器获取心跳间隔

        final CustomProgressDialog customProgressDialog = new CustomProgressDialog(PositionModeActivity.this,
                "请稍后...");
        customProgressDialog.show();
        DevicesService.getBindDeviceUploadPositionInterval(PositionModeActivity.this, deviceID, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) { //成功
                position_time = (Integer)object;
                customProgressDialog.dismiss();
                initViews();
            }
        }, new FailCallback() {//失败，
            @Override
            public void onFail(Object object) {
                customProgressDialog.dismiss();
                Toast.makeText(PositionModeActivity.this, "获取心跳间隔失败!", Toast.LENGTH_LONG).show();
                position_time = update_time_0;
                initViews();
            }
        });
    }


    void initViews(){

        switch (position_time){
            case update_time_0:
                position_index = 0;
                break;
            case update_time_1:
                position_index = 1;
                break;
            case update_time_2:
                position_index = 2;
                break;
            case update_time_3:
                position_index = 3;
                break;
        }


        listViews = (ListView) findViewById(R.id.id_lv_position_mode);
        positionModeItems = new ArrayList<>();
        if (0 == position_index) {
            positionModeItems.add(new PositionModeItem("快速模式 (每5分钟上传一次位置信息)", R.drawable.select_update_time));
            positionModeItems.add(new PositionModeItem("普通模式 (每10分钟上传一次位置信息)", R.drawable.unselect_update_time));
            positionModeItems.add(new PositionModeItem("缓慢模式 (每15分钟上传一次位置信息)", R.drawable.unselect_update_time));
            positionModeItems.add(new PositionModeItem("超长模式 (每60分钟上传一次位置信息)", R.drawable.unselect_update_time));
        } else if (1 == position_index) {
            positionModeItems.add(new PositionModeItem("快速模式 (每5分钟上传一次位置信息)", R.drawable.unselect_update_time));
            positionModeItems.add(new PositionModeItem("普通模式 (每10分钟上传一次位置信息)", R.drawable.select_update_time));
            positionModeItems.add(new PositionModeItem("缓慢模式 (每15分钟上传一次位置信息)", R.drawable.unselect_update_time));
            positionModeItems.add(new PositionModeItem("超长模式 (每60分钟上传一次位置信息)", R.drawable.unselect_update_time));
        } else if (2 == position_index) {
            positionModeItems.add(new PositionModeItem("快速模式 (每5分钟上传一次位置信息)", R.drawable.unselect_update_time));
            positionModeItems.add(new PositionModeItem("普通模式 (每10分钟上传一次位置信息)", R.drawable.unselect_update_time));
            positionModeItems.add(new PositionModeItem("缓慢模式 (每15分钟上传一次位置信息)", R.drawable.select_update_time));
            positionModeItems.add(new PositionModeItem("超长模式 (每60分钟上传一次位置信息)", R.drawable.unselect_update_time));
        } else if (3 == position_index) {
            positionModeItems.add(new PositionModeItem("快速模式 (每5分钟上传一次位置信息)", R.drawable.unselect_update_time));
            positionModeItems.add(new PositionModeItem("普通模式 (每10分钟上传一次位置信息)", R.drawable.unselect_update_time));
            positionModeItems.add(new PositionModeItem("缓慢模式 (每15分钟上传一次位置信息)", R.drawable.unselect_update_time));
            positionModeItems.add(new PositionModeItem("超长模式 (每60分钟上传一次位置信息)", R.drawable.select_update_time));
        }
        adapter = new PositionModeItemAdapter(positionModeItems, PositionModeActivity.this, R.layout.list_item_position_mode);

        listViews.setAdapter(adapter);
        listViews.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(final  AdapterView<?> parent, View view, final int position, long id) {
                if (position == position_index){//选择一样,不用操作
                    return;
                }

                //开始设置
                final CustomProgressDialog customProgressDialog = new CustomProgressDialog(PositionModeActivity.this,
                        "请稍后...");
                customProgressDialog.show();


                switch (position) {
                    case 0:
                        position_time = update_time_0;
                        break;
                    case 1:
                        position_time = update_time_1;
                        break;
                    case 2:
                        position_time = update_time_2;
                        break;
                    case 3:
                        position_time = update_time_3;
                        break;
                    default:
                        position_time = update_time_0;
                        break;
                }
                //服务器请求更改
                DevicesService.setBindDeviceUploadPositionInterval(PositionModeActivity.this, deviceID, position_time,
                        new SuccessCallback() {
                            @Override
                            public void onSuccess(Object object) {

                                position_index = position;//规范化position
                                //更新控件状态
                                PositionModeItem positionModeItem;
                                for (int i = 0; i < adapter.getCount(); i++) {
                                    positionModeItem = (PositionModeItem) parent.getItemAtPosition(i);
                                    if (i == position) {
                                        positionModeItem.setIcon(R.drawable.select_update_time);
                                    } else {
                                        positionModeItem.setIcon(R.drawable.unselect_update_time);
                                    }
                                }
                                //刷新界面
                                adapter.notifyDataSetInvalidated();


                                customProgressDialog.dismiss();
                                Toast.makeText(PositionModeActivity.this, "设置成功!", Toast.LENGTH_LONG).show();
//                                get(PositionModeActivity.this, deviceID);
                            }
                        }, new FailCallback() {
                            @Override
                            public void onFail(Object object) {
                                customProgressDialog.dismiss();
                                Toast.makeText(PositionModeActivity.this, "设置失败!", Toast.LENGTH_LONG).show();

                            }
                        });
            }
        });
    }

}
