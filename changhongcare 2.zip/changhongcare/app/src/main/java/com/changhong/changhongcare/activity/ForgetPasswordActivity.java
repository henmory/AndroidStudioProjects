package com.changhong.changhongcare.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.Callback;
import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.ksoap.DevicesService;
import com.changhong.changhongcare.ksoap.PersonService;

public class ForgetPasswordActivity extends AppCompatActivity {
    private EditText evPhoneNumber;
    private EditText evCode;
    private EditText evPassword;
    private EditText evMarkPassword;
    private Button btnResetPassword;
    private Button btnGetCode;
    private String num;
    private String Code;
    private String password ;
    private String markPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        bindViews();
    }

    private void bindViews(){
        evPhoneNumber = (EditText) findViewById(R.id.et_phone_number);
        evCode = (EditText) findViewById(R.id.et_sms_code);
        evPassword = (EditText) findViewById(R.id.et_create_password);
        evMarkPassword = (EditText) findViewById(R.id.et_mark_password);
        btnResetPassword = (Button) findViewById(R.id.btn_mark);
        btnGetCode = (Button) findViewById(R.id.btn_get_code);

        btnGetCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                num = evPhoneNumber.getText().toString();

                if (TextUtils.isEmpty(num)){
                    Toast.makeText(ForgetPasswordActivity.this, "电话号码不能为空", Toast.LENGTH_SHORT).show();
                }else{

                    final CustomProgressDialog customProgressDialog = new CustomProgressDialog(ForgetPasswordActivity.this, "获取验证码...");
                    customProgressDialog.show();

                    PersonService.getCode(ForgetPasswordActivity.this, num, new SuccessCallback() {
                        @Override
                        public void onSuccess(Object data) {
                            customProgressDialog.dismiss();
                            Toast.makeText(ForgetPasswordActivity.this, "验证码发送成功",Toast.LENGTH_SHORT).show();
                        }
                    }, new FailCallback() {
                        @Override
                        public void onFail(Object data) {
                            customProgressDialog.dismiss();
                            Toast.makeText(ForgetPasswordActivity.this, data.toString(),Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });

        btnResetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                num = evPhoneNumber.getText().toString();
                Code = evCode.getText().toString();
                password = evPassword.getText().toString();
                markPassword = evMarkPassword.getText().toString();

                if (TextUtils.isEmpty(num) || TextUtils.isEmpty(Code)
                        || TextUtils.isEmpty(password) || TextUtils.isEmpty(markPassword)){
                    Toast.makeText(ForgetPasswordActivity.this, "所有字段不能为空", Toast.LENGTH_SHORT).show();
                }else {

                    if(!password.equals(markPassword)){
                        Toast.makeText(ForgetPasswordActivity.this, "两次密码输入不一致", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    final CustomProgressDialog customProgressDialog = new CustomProgressDialog(ForgetPasswordActivity.this, "重置密码...");
                    customProgressDialog.show();

                    PersonService.isVerCodeCorrect(ForgetPasswordActivity.this, num, Code, new SuccessCallback() {

                        //验证验证码正确，重置密码
                        @Override
                        public void onSuccess(Object data) {

                            //重置密码
                            PersonService.resetPwd(ForgetPasswordActivity.this, num, password, new SuccessCallback() {
                                @Override
                                public void onSuccess(Object object) {
                                    customProgressDialog.dismiss();
//                                    Toast.makeText(ForgetPasswordActivity.this, "重置密码成功",Toast.LENGTH_SHORT).show();
                                    finish();//删除本页面

                                    //登陆进入主界面
                                    final CustomProgressDialog customProgressDialog = new CustomProgressDialog(ForgetPasswordActivity.this, "登陆中...");
                                    customProgressDialog.show();

                                    PersonService.login(ForgetPasswordActivity.this, num, password, new SuccessCallback() {
                                        @Override
                                        public void onSuccess(Object data) {

                                            //获取其它数据,无论失败还是成功，都要进入主界面
                                            DevicesService.getBindDevicesPositionList(ForgetPasswordActivity.this, num, new Callback() {
                                                @Override
                                                public void callBack(Object o) {
                                                    startActivity(new Intent(ForgetPasswordActivity.this, AmapActivity.class));
                                                    customProgressDialog.dismiss();
                                                }
                                            });
                                            LoginActivity.mInstace.finish();//登陆成功删除登陆页面,否则进入登陆界面
                                        }
                                    }, new FailCallback() {
                                        @Override
                                        public void onFail(Object data) {
                                            customProgressDialog.dismiss();
                                            Toast.makeText(ForgetPasswordActivity.this, data.toString(),Toast.LENGTH_SHORT).show();
                                        }
                                    });


                                }
                            }, new FailCallback() {
                                @Override
                                public void onFail(Object object) {
                                    customProgressDialog.dismiss();
                                    Toast.makeText(ForgetPasswordActivity.this, object.toString(),Toast.LENGTH_SHORT).show();

                                }
                            });

                        }
                    }, new FailCallback() {
                        //验证码失败后，提示用户错误
                        @Override
                        public void onFail(Object data) {
                            customProgressDialog.dismiss();
                            Toast.makeText(ForgetPasswordActivity.this, data.toString(),Toast.LENGTH_SHORT).show();
                        }
                    });
                }

            }
        });
    }
}
