package com.changhong.changhongcare.structFromService;


/**
 * author: henmory
 * time:  11/3/16
 * function:
 * description:
 */

public class Fence {
    private int deviceID;
    private int fenceNum;
    private String latitute;
    private String longitude;
    private String name;
    private String radius;

    public String getRadius() {
        return radius;
    }

    public void setRadius(String radius) {
        this.radius = radius;
    }

    public int getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(int deviceID) {
        this.deviceID = deviceID;
    }

    public int getFenceNum() {
        return fenceNum;
    }

    public void setFenceNum(int fenceNum) {
        this.fenceNum = fenceNum;
    }

    public String getLatitute() {
        return latitute;
    }

    public void setLatitute(String latitute) {
        this.latitute = latitute;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Fence{" +
                "deviceID=" + deviceID +
                ", fenceNum=" + fenceNum +
                ", latitute='" + latitute + '\'' +
                ", longitude='" + longitude + '\'' +
                ", name='" + name + '\'' +
                ", radius='" + radius + '\'' +
                '}';
    }
}
