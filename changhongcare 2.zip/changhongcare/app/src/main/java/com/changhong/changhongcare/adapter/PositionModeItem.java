package com.changhong.changhongcare.adapter;

/**
 * author: henmory
 * time:  12/19/16
 * function:
 * description: 绑定设备列表
 */

public class PositionModeItem {
    private String description;
    private int icon;

    public PositionModeItem(String description, int icon) {
        this.description = description;
        this.icon = icon;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    @Override
    public String toString() {
        return "PositionModeItem{" +
                "description='" + description + '\'' +
                ", icon=" + icon +
                '}';
    }
}
