package com.changhong.changhongcare.adapter;

/**
 * author: henmory
 * time:  12/19/16
 * function:
 * description:
 */

public class SettingItem {
    private int icon;
    private String description;
    private int goToNext;

    public SettingItem(int icon, String description, int goToNext) {
        this.icon = icon;
        this.description = description;
        this.goToNext = goToNext;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getGoToNext() {
        return goToNext;
    }

    public void setGoToNext(int goToNext) {
        this.goToNext = goToNext;
    }

    @Override
    public String toString() {
        return "SettingItem{" +
                "icon=" + icon +
                ", description='" + description + '\'' +
                ", goToNext=" + goToNext +
                '}';
    }
}
