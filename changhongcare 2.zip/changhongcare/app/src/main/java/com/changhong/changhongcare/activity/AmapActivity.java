package com.changhong.changhongcare.activity;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.BounceInterpolator;
import android.view.animation.Interpolator;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationClientOption.AMapLocationMode;
import com.amap.api.location.AMapLocationListener;
import com.amap.api.maps2d.AMap;
import com.amap.api.maps2d.AMapOptions;
import com.amap.api.maps2d.CameraUpdateFactory;
import com.amap.api.maps2d.LocationSource;
import com.amap.api.maps2d.MapView;
import com.amap.api.maps2d.Projection;
import com.amap.api.maps2d.UiSettings;
import com.amap.api.maps2d.model.BitmapDescriptor;
import com.amap.api.maps2d.model.BitmapDescriptorFactory;
import com.amap.api.maps2d.model.Circle;
import com.amap.api.maps2d.model.LatLng;
import com.amap.api.maps2d.model.Marker;
import com.amap.api.maps2d.model.MarkerOptions;
import com.amap.api.services.core.LatLonPoint;
import com.amap.api.services.geocoder.GeocodeResult;
import com.amap.api.services.geocoder.GeocodeSearch;
import com.amap.api.services.geocoder.RegeocodeQuery;
import com.amap.api.services.geocoder.RegeocodeResult;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.adapter.DeviceItem;
import com.changhong.changhongcare.customview.CustomAskUserDialog;
import com.changhong.changhongcare.ksoap.DevicesService;
import com.changhong.changhongcare.adapter.NavigationItem;
import com.changhong.changhongcare.adapter.NavigationItemAdapter;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.structFromService.Position;
import com.changhong.changhongcare.utils.DisplayUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class AmapActivity extends AppCompatActivity implements LocationSource, AMapLocationListener, AMap.OnMarkerClickListener, GeocodeSearch.OnGeocodeSearchListener {

    private final static String TAG = "AmapActivity";
    //////////////////////////////////////界面相关////////////////////////////////////////////////////////////////
    private final static int TITLE_SIZE = 36;
    private final static int NAVIGATION_NAME_SIZE = 24;
    private final static int NAVIGATION_ITEM_SIZE = 50;

    private TextView tvTitle;//标题
    private Toolbar toolbar;//工具栏
    private ImageView ivDeviceList;//设备列表
    private List<NavigationItem> navigationItemList;//侧边栏项
    private ListView lv_navigation;
    private ActionBarDrawerToggle drawerToggle; //为actionbar设置的事件监听器
    private DrawerLayout mDrawerLayout; //整个布局
    private TextView tvUserName;//导航栏用户名称
    private ImageView ivUserImage;//用户头像
    private ClickEventHandler clickEventHandler = new ClickEventHandler();//处理界面的单击事件
    private ImageView ivPosition;
    private DeviceListDialog deviceListDialog;//设备列表对话框
    private DeviceParamDialog deviceParamDialog;//设备参数对话框


    ///////////////////退出当前账号使用////////////////////////////
    private Handler handler;//处理activity,与界面更新复用
    private static final int MSG_DESTORY_AMAP_ACTIVITY = 0;
    public static AmapActivity mInstace = null;

    /////////////////界面更新相关////////////////
    private static final int MSG_RESRESH_AMAP_ACTIVITY = 1;
    private Timer timer;
    private TimerTask task;

    // 定义一个变量，来标识是否退出整个应用程序
    private static boolean isExit = false;
    private static final int MSG_RESET_CLOCK_ACTIVITY = 2;

    ////////////////////////////////////////高德地图相关变量////////////////////////////////////////////////////////////////
    public AMap getaMap() {
        return aMap;
    }

    private AMap aMap;
    private MapView mapView;
    private UiSettings mUiSettings;
    private OnLocationChangedListener mListener;
    private AMapLocationClient mlocationClient;
    private AMapLocationClientOption mLocationOption;
    private Circle mCircle;
    private boolean mFirstFix = false;
    private Marker mLocMarker;
    private String locationMessage; //点击位置图标显示的信息

    public static LatLng getMylocation() {
        return my_location;
    }

    private static LatLng my_location;//目前定位位置---点击定位时使用
    private GeocodeSearch geocoderSearch;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amap);

        initToolBar();
//        initNavigation(); //不在这里初始化，在点击左上角图标时初始化
        ivPosition = (ImageView) findViewById(R.id.iv_position);
        ivPosition.setOnClickListener(clickEventHandler);
        mInstace = this;
        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case MSG_DESTORY_AMAP_ACTIVITY://点击退出当前账号，销毁amap activity
                        mInstace.startActivity(new Intent(AmapActivity.this, LoginActivity.class));
                        mInstace.finish();
                        break;
                    case MSG_RESRESH_AMAP_ACTIVITY:
                        Log.d(TAG, "刷新主界面");
                        DevicesService.getBindDevicesPositionList(AmapActivity.this, Config.phoneNumber, new com.changhong.changhongcare.Interface.Callback() {
                            @Override
                            public void callBack(Object object) {
                                updateAmapActivity();//更新界面
                                changeBindDeviceLatLngToString();//更新设备位置信息

//                                aMap.invalidate();//主界面更新
                            }
                        });
                        break;
                    case MSG_RESET_CLOCK_ACTIVITY:
                        isExit = false;
                        break;
                }
            }
        };


        //地图相关初始化
        mapView = (MapView) findViewById(R.id.map);
        mapView.onCreate(savedInstanceState);// 此方法必须重写
        init();


        //登陆成功后，获取绑定设备列表和位置信息.初始化地图完成后，在地图上标记设备位置
        showBindDevicesPositionOnAmap();

    }


    /**
     * @param
     * @return
     * @author henmory
     * @date 2/14/17
     * @description 当数据发生变化或者定时刷新界面
     */
    public void updateAmapActivity() {
        if (null != aMap) {
            aMap.clear();//清理地图标记

            //显示我的位置图标
            Bitmap bMap = BitmapFactory.decodeResource(this.getResources(),
                    R.drawable.my_location);
            BitmapDescriptor des = BitmapDescriptorFactory.fromBitmap(bMap);
            MarkerOptions options = new MarkerOptions();
            options.icon(des);
            options.anchor(0.5f, 1);
            options.position(my_location);
            options.title(Config.imei);//用imei作为每个设备的区别
            aMap.addMarker(options);

            showBindDevicesPositionOnAmap();//显示绑定设备
        }

    }

    /**
     * 初始化AMap对象
     */
    private void init() {
        if (aMap == null) {
            aMap = mapView.getMap();
            aMap.setOnMarkerClickListener(this);//添加点击我的位置监听器
            aMap.setLocationSource(this);// 设置定位监听
            aMap.setMyLocationEnabled(true);// 是否可触发定位并显示定位层
            mUiSettings = aMap.getUiSettings();

        }
        mUiSettings.setLogoPosition(AMapOptions.LOGO_POSITION_BOTTOM_CENTER);// 设置地图logo显示在底部居中
        mUiSettings.setScaleControlsEnabled(false);//设置地图默认的比例尺
        mUiSettings.setZoomControlsEnabled(true);//设置地图默认的缩放按钮
        mUiSettings.setCompassEnabled(false);//指南针
        mUiSettings.setMyLocationButtonEnabled(false); // 显示默认的定位按钮

        mUiSettings.setScrollGesturesEnabled(true);//手势滑动
        mUiSettings.setZoomGesturesEnabled(true);//手势放大缩小


        geocoderSearch = new GeocodeSearch(this);
        geocoderSearch.setOnGeocodeSearchListener(this);
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onResume() {
        Log.d(TAG, "amap resume");
        super.onResume();
        mapView.onResume();
        //初始化界面刷新时间,当界面处在最前面的适合开启定时器
        initRefreshTime();
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onPause() {
        Log.d(TAG, "amap pause");
        super.onPause();
        mapView.onPause();
        deactivate();
        mFirstFix = false;

        //与onresume相匹配
        task.cancel();
        timer.cancel();//amap不在最前面时，退出定时器
        task = null;
        timer = null;
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    @Override
    protected void onStop() {
        super.onStop();


    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }


    /**
     * 定位成功后回调函数
     */

    @Override
    public void onLocationChanged(AMapLocation amapLocation) {
        if (mListener != null && amapLocation != null) {
            if (amapLocation != null
                    && amapLocation.getErrorCode() == 0) {
                LatLng location = new LatLng(amapLocation.getLatitude(), amapLocation.getLongitude());
                my_location = location;
                if (!mFirstFix) {
                    mFirstFix = true;
//                    addCircle(location, amapLocation.getAccuracy());//添加定位精度圆
                    addMarker(location);//添加定位图标
                    locationMessage = amapLocation.getAddress();
                    System.out.println("我的位置: " + locationMessage);
//                    mSensorHelper.setCurrentMarker(mLocMarker);//定位图标旋转
                } else {
                    mCircle.setCenter(location);
                    mCircle.setRadius(amapLocation.getAccuracy());
                    mLocMarker.setPosition(location);
                }
                aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 13));
                changeBindDeviceLatLngToString();
            } else {
                String errText = "定位失败," + amapLocation.getErrorCode() + ": " + amapLocation.getErrorInfo();
                Log.e("AmapErr", errText);
            }
        }
    }

    /**
     * 激活定位
     */
    @Override
    public void activate(OnLocationChangedListener listener) {
        mFirstFix = false;
        mListener = listener;
        if (mlocationClient == null) {
            mlocationClient = new AMapLocationClient(this);
            mLocationOption = new AMapLocationClientOption();
            //设置定位监听
            mlocationClient.setLocationListener(this);
            //设置为高精度定位模式
            mLocationOption.setLocationMode(AMapLocationMode.Hight_Accuracy);
            //设置定位参数
            mlocationClient.setLocationOption(mLocationOption);
            // 此方法为每隔固定时间会发起一次定位请求，为了减少电量消耗或网络流量消耗，
            // 注意设置合适的定位时间的间隔（最小间隔支持为2000ms），并且在合适时间调用stopLocation()方法来取消定位请求
            // 在定位结束后，在合适的生命周期调用onDestroy()方法
            // 在单次定位情况下，定位无论成功与否，都无需调用stopLocation()方法移除请求，定位sdk内部会移除
            mlocationClient.startLocation();
        }
    }

    /**
     * 停止定位
     */
    @Override
    public void deactivate() {
        mListener = null;
        if (mlocationClient != null) {
            mlocationClient.stopLocation();
            mlocationClient.onDestroy();
        }
        mlocationClient = null;
    }

    public void addMarker(LatLng latlng) {
        if (mLocMarker != null) {
            return;
        }
        Bitmap bMap = BitmapFactory.decodeResource(this.getResources(),
                R.drawable.my_location);//显示我的位置图标
        BitmapDescriptor des = BitmapDescriptorFactory.fromBitmap(bMap);
        MarkerOptions options = new MarkerOptions();
        options.icon(des);
        options.anchor(0.5f, 1);
        options.position(latlng);
        options.title(Config.imei);//用imei作为每个设备的区别
        mLocMarker = aMap.addMarker(options);

    }

    /**
     * marker点击时跳动一下
     */
    public void jumpPoint(final Marker marker) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        Projection proj = aMap.getProjection();
        final LatLng markerLatlng = marker.getPosition();
        Point markerPoint = proj.toScreenLocation(markerLatlng);
        markerPoint.offset(0, -100);
        final LatLng startLatLng = proj.fromScreenLocation(markerPoint);
        final long duration = 1500;

        final Interpolator interpolator = new BounceInterpolator();
        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed
                        / duration);
                double lng = t * markerLatlng.longitude + (1 - t)
                        * startLatLng.longitude;
                double lat = t * markerLatlng.latitude + (1 - t)
                        * startLatLng.latitude;
                marker.setPosition(new LatLng(lat, lng));
                if (t < 1.0) {
                    handler.postDelayed(this, 16);
                }
            }
        });
    }

    /**
     * @param
     * @return
     * @author henmory
     * @date 11/25/16
     * @description 点击我的位置事件  如果是本机为imei，如果是绑定设备就是服务器分配的deviceID
     */

    @Override
    public boolean onMarkerClick(Marker marker) {
        if (aMap != null) {
            jumpPoint(marker);
        }
        //获取点击设备的标识
        String title = marker.getTitle();
        Log.d(TAG, "click deviceID = " + title);
        if (title.equals(Config.imei)) {//本机位置

            SharePositionDialog dialog = new SharePositionDialog(AmapActivity.this, locationMessage);
            dialog.show();
        } else {//绑定功能机位置
            Log.d(TAG, "title = " + title);
            DeviceParamDialog deviceParamDialog = new DeviceParamDialog(AmapActivity.this, title);
            deviceParamDialog.show();
        }
        return true;
    }

    /**
     * 逆地理编码回调
     */

    //存储设备的位置字符串表示形式
    private void storeDevicePositionString(RegeocodeResult result) {
        List<Position> positions = DevicesService.getPositionList();//获取从服务器获取的设备列表
        RegeocodeQuery regeocodeQuery = result.getRegeocodeQuery();
        LatLonPoint latLonPoint = regeocodeQuery.getPoint();
        double lat = latLonPoint.getLatitude();
        double lon = latLonPoint.getLongitude();
        Log.d(TAG, "解析的位置为 la = " + lat + " ; lo = " + lon);
        Map<String, String> map = DevicesService.getMap();
        for (int i = 0; i < positions.size(); i++) {
            if (Math.abs(lat - positions.get(i).getLa()) < 0.000001
                    && Math.abs(lon - positions.get(i).getLo()) < 0.000001) {
                map.put(positions.get(i).getDeviceIMEI(), result.getRegeocodeAddress().getFormatAddress());
                break;
            }
        }
        Log.d(TAG, "解析位置" + map.toString());
    }

    @Override
    public void onRegeocodeSearched(RegeocodeResult result, int rCode) {
        if (rCode == 1000) {
            if (result != null && result.getRegeocodeAddress() != null
                    && result.getRegeocodeAddress().getFormatAddress() != null) {
                storeDevicePositionString(result);

            } else {
                Log.d(TAG, "经纬度解码成字符串失败");
            }
        } else {
            Log.d(TAG, "经纬度解码成字符串失败");
        }
    }

    /**
     * 地理编码查询回调
     */
    @Override
    public void onGeocodeSearched(GeocodeResult geocodeResult, int i) {

    }

    //-----------------------------------高德地图以外的控件处理-----------------------------------------------------------

    /**
     * @param
     * @return
     * @author henmory
     * @date 12/7/16
     * @description 初始化导航栏
     */
    void initNavigation() {
        bindNavigationViews();
        initNavigationContent();
    }

    void bindNavigationViews() {
        lv_navigation = (ListView) findViewById(R.id.drawer_setting);
        ivUserImage = (ImageView) findViewById(R.id.iv_user_account_image);
        tvUserName = (TextView) findViewById(R.id.tv_navigation_user_account_name);
    }

    void initNavigationContent() {
        //设置标题
        tvUserName.setText(Config.phoneNumber);//设置用户名
//        int frontSize = DisplayUtil.px2sp(AmapActivity.this, NAVIGATION_NAME_SIZE);
//        tvUserName.setTextSize(frontSize);

        //drawer设置
        navigationItemList = new ArrayList<>();
        navigationItemList.add(new NavigationItem(R.drawable.add_device, "添加设备"));
//        navigationItemList.add(new NavigationItem(R.drawable.refresh, "位置更新频率"));
//        navigationItemList.add(new NavigationItem(R.drawable.setting, "设置"));
        navigationItemList.add(new NavigationItem(R.drawable.help, "帮助手册"));
        navigationItemList.add(new NavigationItem(R.drawable.exit, "退出当前账号"));
        int tap = DisplayUtil.px2dip(AmapActivity.this, NAVIGATION_ITEM_SIZE);
        lv_navigation.setDividerHeight(tap);
        NavigationItemAdapter adapter = new NavigationItemAdapter(navigationItemList, AmapActivity.this, R.layout.list_item_navigation);
        lv_navigation.setAdapter(adapter);
        lv_navigation.setOnItemClickListener(clickEventHandler);
        ivUserImage.setOnClickListener(clickEventHandler);
    }


    /**
     * @param
     * @return
     * @author henmory
     * @date 12/7/16
     * @description 初始化工具栏
     */
    void initToolBar() {

        bindToolBarViews();//绑定视图
        setSupportActionBar(toolbar);//工具栏设置
        toolbar.setNavigationIcon(R.drawable.main_setting);//设置工具栏图标
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        //初始化标题
        initTitle();
        //设置标题点击事件
        tvTitle.setOnClickListener(clickEventHandler);

        //标题栏图标单击事件设置
        drawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.open, R.string.close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                initNavigation();
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }
        };
        mDrawerLayout.addDrawerListener(drawerToggle);//设置监听
    }

    void bindToolBarViews() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        tvTitle = (TextView) findViewById(R.id.tv_title);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout); //整个布局的id
    }

    void initTitle() {
        tvTitle.setText("长虹关爱");//默认标题
//        int  titleSize = DisplayUtil.px2sp(AmapActivity.this, TITLE_SIZE);
//        tvTitle.setTextSize(titleSize);


    }

    private static List<Position> deviceList = new ArrayList<>();

    //初始化设备列表
    void initSettingDatas(Menu menu) {
        menu.clear();
        String nickName = null;
        deviceList = DevicesService.getPositionList();
        for (int i = 0; i < deviceList.size(); i++) {
            nickName = deviceList.get(i).getNickName();
            if (null != nickName) {
                menu.add(Menu.NONE, i, Menu.NONE, nickName);
            } else {
                menu.add(Menu.NONE, i, Menu.NONE, deviceList.get(i).getDeviceID());
            }

        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
//        initSettingDatas(menu);
        return true;
    }

    @Override
    public void openContextMenu(View view) {
        super.openContextMenu(view);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        initSettingDatas(menu);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        for (int i = 0; i < deviceList.size(); i++) {
            if (i == item.getItemId()) {
                //弹出设备详细信息对话框，现在改为直接跳转到位置地图处
                LatLng latLng = new LatLng(deviceList.get(i).getLa(), deviceList.get(i).getLo());
                aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 13));
//                DeviceParamDialog deviceParamDialog = new DeviceParamDialog(AmapActivity.this, deviceList.get(i).getDeviceID());
//                deviceParamDialog.show();
                break;
            }
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
//        drawerToggle.syncState();//使得箭头和三道杠图案和抽屉拉和保持一致
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        drawerToggle.onConfigurationChanged(newConfig);
    }


    /**
     * @param
     * @author henmory
     * @date 12/7/16
     * @description 导航栏和工具栏点击事件处理类
     * @return
     */

    private class ClickEventHandler implements View.OnClickListener, AdapterView.OnItemClickListener {

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.iv_position://自定义定位我的位置，高德地图默认位置在右上角
                    aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(my_location, 13));
                    break;
                case R.id.tv_title://点击标题进入设备列表对话框
//                    deviceListDialog =  new DeviceListDialog(AmapActivity.this);
//                    deviceListDialog.show();
                    break;
                case R.id.iv_user_account_image://点击用户图标，进入用户信息
                    startActivity(new Intent(AmapActivity.this, UserAccountActivity.class));
                    break;
                default:
            }

        }

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            switch (position) {
                case 0://添加设备
                    startActivity(new Intent(AmapActivity.this, AddDeviceActivity.class));
                    break;
//                case 1://设置位置更新频率
//                    startActivity(new Intent(AmapActivity.this, UpdateTimeActivity.class));
//                    break;
//                case 1://进入设置界面
//                    startActivity(new Intent(AmapActivity.this, SettingActivity.class));
//                    break;
                case 1://帮助手册
                    startActivity(new Intent(AmapActivity.this, HelpActivity.class));
                    break;
                case 2://退出当前账号
                    exitCurrentAccount();
                    break;
            }

        }

    }

    /**
     * @param
     * @return
     * @author henmory
     * @date 12/8/16
     * @description 退出当前账户，目前没有跟服务器交互
     */

    private void exitCurrentAccount() {
//        LayoutInflater inflaterDl = LayoutInflater.from(AmapActivity.this);
//        LinearLayout layout = (LinearLayout)inflaterDl.inflate(R.layout.custom_exit_dialog, null );

//        AlertDialog.Builder builder = new AlertDialog.Builder(AmapActivity.this);
//        AlertDialog dialog = builder.create();
////        dialog.setMessage("你确定要退出当前账号？");
//        dialog.setContentView(R.layout.custom_exit_dialog);
//        dialog.setCanceledOnTouchOutside(false);
//        dialog.setCancelable(true);
//        dialog.getWindow().setContentView(R.layout.custom_exit_dialog);
//        dialog.setButton(DialogInterface.BUTTON_POSITIVE, "确定", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                System.out.println("sure");
//                Message message = Message.obtain();
//                message.what = MSG_DESTORY_AMAP_ACTIVITY;
//                message.setTarget(handler);
//                handler.sendMessage(message);
//            }
//        });
//        dialog.setButton(DialogInterface.BUTTON_NEGATIVE, "取消", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                System.out.println("cancle");
//            }
//        });
//        dialog.show();


        final CustomAskUserDialog dialog = new CustomAskUserDialog(AmapActivity.this);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(true);
        dialog.setContent("确定退出当前账户?");
        dialog.setOnNegativeListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.setOnPositiveListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("sure");
                dialog.dismiss();
                Message message = Message.obtain();
                message.what = MSG_DESTORY_AMAP_ACTIVITY;
                message.setTarget(handler);
                handler.sendMessage(message);
            }
        });
        dialog.show();
    }

    //登陆成功后，获取绑定设备列表和位置信息.初始化地图完成后，在地图上标记设备位置
    public void showBindDevicesPositionOnAmap() {
        List<Position> positions = DevicesService.getPositionList();
        LatLng location;
        for (int i = 0; i < positions.size(); i++) {
            location = new LatLng(positions.get(i).getLa(), positions.get(i).getLo());
            Bitmap bMap = BitmapFactory.decodeResource(this.getResources(),
                    R.drawable.bind_device_position_big);//显示绑定设备的位置图标
            BitmapDescriptor des = BitmapDescriptorFactory.fromBitmap(bMap);
            MarkerOptions options = new MarkerOptions();
            options.icon(des);
            options.anchor(0.5f, 1);
            options.position(location);
            options.title(positions.get(i).getDeviceID());//用设备的id标识
            aMap.addMarker(options);
            Log.d(TAG, "showBindDevicesPositionOnAmap");
        }
    }

    //通过设备的经纬度，上传高德，获取位置字符串表示形式
    //onRegeocodeSearched为回调函数
    public void changeBindDeviceLatLngToString() {
        List<Position> positions = DevicesService.getPositionList();//获取从服务器获取的设备列表
        for (int i = 0; i < positions.size(); i++) {
            Log.d(TAG, "解析绑定设备的位置 la = " + positions.get(i).getLa() + "; lo = " + positions.get(i).getLo());
            changePositionLatLngToString(new LatLng(positions.get(i).getLa(), positions.get(i).getLo()));
        }
    }

    //通过设备的经纬度，上传高德，获取位置字符串表示形式
    private void changePositionLatLngToString(LatLng latLng) {
        LatLonPoint latLonPoint = new LatLonPoint(latLng.latitude, latLng.longitude);
        RegeocodeQuery query = new RegeocodeQuery(latLonPoint, 200,
                GeocodeSearch.AMAP);// 第一个参数表示一个Latlng，第二参数表示范围多少米，第三个参数表示是火系坐标系还是GPS原生坐标系
        geocoderSearch.getFromLocationAsyn(query);// 设置同步逆地理编码请求
    }

    //初始化界面刷新时间，开启定时器刷新界面
    private void initRefreshTime() {
        Log.d(TAG, "初始定时器");
        int index = Config.refresh_index;
        int time;
        switch (index) {
            case 0:
                time = 10;
                break;
            case 1:
                time = 30;
                break;
            case 2:
                time = 60;
                break;
            default:
                time = 60;
        }

        if (null == task) {
            task = new TimerTask() {
                @Override
                public void run() {
                    Log.d(TAG, "run");
                    sendUpdateAmapMessage();
                }
            };
        }

        Log.d(TAG, "time = " + time + "");
        if (null == timer) {
            timer = new Timer();
        }

        timer.schedule(task, time * 1000, time * 1000);

    }

    public void sendUpdateAmapMessage() {
        Message message = Message.obtain();
        message.what = MSG_RESRESH_AMAP_ACTIVITY;
        message.setTarget(handler);
        handler.sendMessage(message);
    }

    //退出整个应用程序
    private void exit() {
        if (!isExit) {
            isExit = true;
            Toast.makeText(getApplicationContext(), "再按一次退出程序",
                    Toast.LENGTH_SHORT).show();
            // 利用handler延迟发送更改状态信息
            handler.sendEmptyMessageDelayed(MSG_RESET_CLOCK_ACTIVITY, 2000);
        } else {
            finish();
            System.exit(0);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            exit();
            return false;
        }
        return super.onKeyDown(keyCode, event);
    }
}

