package com.changhong.changhongcare.adapter;

import android.content.Context;

import com.changhong.changhongcare.R;
import com.changhong.changhongcare.utils.CommonAdapter;
import com.changhong.changhongcare.utils.CommonViewHolder;

import java.util.List;

/**
 * author: henmory
 * time:  12/19/16
 * function:
 * description:
 */

public class UpdateTimeItemAdapter extends CommonAdapter<UpdateTimeItem> {
    public UpdateTimeItemAdapter(List<UpdateTimeItem> mDatas, Context mContext, int mItemLayout) {
        super(mDatas, mContext, mItemLayout);
    }

    @Override
    public void convert(CommonViewHolder holder, UpdateTimeItem updateTimeItem) {
        holder.setImageResource(R.id.iv_item_update_time_icon, updateTimeItem.getIcon());
        holder.setText(R.id.tv_item_update_time_description, updateTimeItem.getDescription());
        holder.setImageResource(R.id.iv_item_update_time_select, updateTimeItem.getSelect());
    }
}
