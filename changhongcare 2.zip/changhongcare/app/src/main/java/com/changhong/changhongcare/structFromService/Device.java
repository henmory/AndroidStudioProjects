package com.changhong.changhongcare.structFromService;

/**
 * author: henmory
 * time:  11/3/16
 * function:
 * description:
 */

public class Device {
    private int deviceID;
    private String deviceIMEI;
    private String deviceImgUrl;
    private String deviceName;
    private Position devicePos;
    private String deviceTel;
    private String deviceType;
    private String nickName;

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public int getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(int deviceID) {
        this.deviceID = deviceID;
    }

    public String getDeviceIMEI() {
        return deviceIMEI;
    }

    public void setDeviceIMEI(String deviceIMEI) {
        this.deviceIMEI = deviceIMEI;
    }

    public String getDeviceImgUrl() {
        return deviceImgUrl;
    }

    public void setDeviceImgUrl(String deviceImgUrl) {
        this.deviceImgUrl = deviceImgUrl;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public Position getDevicePos() {
        return devicePos;
    }

    public void setDevicePos(Position devicePos) {
        this.devicePos = devicePos;
    }

    public String getDeviceTel() {
        return deviceTel;
    }

    public void setDeviceTel(String deviceTel) {
        this.deviceTel = deviceTel;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    @Override
    public String toString() {
        return "Device{" +
                "deviceID=" + deviceID +
                ", deviceIMEI='" + deviceIMEI + '\'' +
                ", deviceImgUrl='" + deviceImgUrl + '\'' +
                ", deviceName='" + deviceName + '\'' +
                ", devicePos=" + devicePos +
                ", deviceTel='" + deviceTel + '\'' +
                ", deviceType='" + deviceType + '\'' +
                ", nickName='" + nickName + '\'' +
                '}';
    }
}
