package com.changhong.changhongcare.structFromService;


/**
 * author: henmory
 * time:  11/3/16
 * function:
 * description:
 */

public class FamilyNumber {
    private String deviceID;
    private String linkmanName;
    private String linkmanPhone;
    private int seqNum;

    public String getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(String deviceID) {
        this.deviceID = deviceID;
    }

    public String getLinkmanName() {
        return linkmanName;
    }

    public void setLinkmanName(String linkmanName) {
        this.linkmanName = linkmanName;
    }

    public String getLinkmanPhone() {
        return linkmanPhone;
    }

    public void setLinkmanPhone(String linkmanPhone) {
        this.linkmanPhone = linkmanPhone;
    }

    public int getSeqNum() {
        return seqNum;
    }

    public void setSeqNum(int seqNum) {
        this.seqNum = seqNum;
    }

    @Override
    public String toString() {
        return "FamilyNumber{" +
                "deviceID=" + deviceID +
                ", linkmanName='" + linkmanName + '\'' +
                ", linkmanPhone='" + linkmanPhone + '\'' +
                ", seqNum=" + seqNum +
                '}';
    }
}
