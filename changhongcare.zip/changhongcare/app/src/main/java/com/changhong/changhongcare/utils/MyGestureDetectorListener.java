package com.changhong.changhongcare.utils;

import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;

/**
 * author: henmory
 * time:  11/21/16
 * function:
 * description:
 */

public abstract class MyGestureDetectorListener extends GestureDetector.SimpleOnGestureListener {
    private final static String tag = "GestureDetectorListener";
    private static final  int FLING_DISTANCE = 50;
    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        if (e1.getX() - e2.getX() > FLING_DISTANCE){
            Log.d(tag, "to left");
            handleToLeft();
        }else{
            Log.d(tag, "to right");
            handleToRight();
        }
        return true;
    }

    public abstract void handleToLeft();
    public abstract void handleToRight();
}
