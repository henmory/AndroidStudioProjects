package com.changhong.changhongcare.newprotocol.structfromserver;

/**
 * author: henmory
 * time:  6/23/17
 * function:
 * description:
 */

public class FuncFamNumView {
    private long devID;//设备id
    private String name;//亲情号名称
    private int seq;//亲情号序号
    private String phone;//亲情号手机号

    public FuncFamNumView() {
    }

    public FuncFamNumView(long devID, String name, int seq, String phone) {
        this.devID = devID;
        this.name = name;
        this.seq = seq;
        this.phone = phone;
    }

    public long getDevID() {
        return devID;
    }

    public void setDevID(long devID) {
        this.devID = devID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSeq() {
        return seq;
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "FuncFamNumView{" +
                "devID=" + devID +
                ", name='" + name + '\'' +
                ", seq=" + seq +
                ", phone='" + phone + '\'' +
                '}';
    }
}
