package com.changhong.changhongcare.newprotocol.structfromserver;

/**
 * author: henmory
 * time:  6/21/17
 * function:
 * description:
 */

public class FuncBasicPosView {
    private long id;
    private double lat;
    private double lng;
    private String gpsTime;
    private int status;

    public FuncBasicPosView() {
    }

    public FuncBasicPosView(long id, double lat, double lng, String gpsTime, int status) {
        this.id = id;
        this.lat = lat;
        this.lng = lng;
        this.gpsTime = gpsTime;
        this.status = status;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public String getGpsTime() {
        return gpsTime;
    }

    public void setGpsTime(String gpsTime) {
        this.gpsTime = gpsTime;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
