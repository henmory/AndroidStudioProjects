package com.changhong.changhongcare.newprotocol.service;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.newprotocol.okhttp.HttpMethord;
import com.changhong.changhongcare.newprotocol.okhttp.NetConnection;
import com.changhong.changhongcare.newprotocol.okhttp.ServerConfig;
import com.changhong.changhongcare.newprotocol.structfromserver.FuncFamNumView;
import com.changhong.changhongcare.newprotocol.structfromserver.LocModePara;
import com.changhong.changhongcare.newprotocol.structfromserver.NickSetParam;
import com.changhong.changhongcare.newprotocol.structfromserver.old.MessageModel;
import com.changhong.changhongcare.pay.alipay.struct.AlipayResultParam;
import com.changhong.changhongcare.pay.alipay.struct.PayParam;

import org.json.JSONException;
import org.json.JSONObject;


/**
 * Created by dan on 10/24/16.
 * <p>
 * description：该文件逻辑主要是在网络通信基础上:
 * 1.过滤一些不需要向上一级反应的步骤：(从服务器回来数据)
 * 1.用户主动点击取消下载，那么当NetConnection层返回数据后， 自己处理后不需要任何向上一级投递信息
 * 2.
 * 2.(传入服务器数据)
 * 屏蔽一些界面不需要填，而服务器需要的参数，在此文件补齐，避免写太多参数
 */

public class ServiceInterface {

    private static final String TAG = "ServiceInterface";

    //添加设备
    public void addBindDevice(Context context, final String userAccount, String userTele, String code,
                              final SuccessCallback successCallback, final FailCallback failCallback) {
        if (TextUtils.isEmpty(userAccount) || TextUtils.isEmpty(userTele) || TextUtils.isEmpty(code)) {
            return;
        }

        new NetConnection(context) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel) data;
                if (messageModel.getReturnStatus() == 0) {
                    if (null != failCallback) {
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                } else {//登陆成功
                    if (null != successCallback) {
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel) data;
                if (null != failCallback) {
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };

    }




/**
 *  @author henmory
 *  @date 6/1/17
 *  @description all above is based on soap, below is http
 *
 *  @param
 *
 *  @return
 */

    /**
     * @param
     * @return
     * @author henmory
     * @date 6/1/17
     * @description the methord is called when service interface requests unsuccessfully
     */
    private void failed(Object data, FailCallback failCallback) {
        JSONObject jsonObject = (JSONObject) data;
        try {
            int retCode = jsonObject.getInt(ServerConfig.KEY_ERROR_CODE);
            if (retCode == ServerConfig.USER_CANCLE_NET_REQUEST_ERROR_CODE) {
                //do nothing
            } else {
                if (null != failCallback) {
                    failCallback.onFail(data);
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
            if (null != failCallback) {
                failCallback.onFail(data);
            }
        }
    }
    //init the request of serve's verification code

    /**
     * because of the protocol of server, we have to post one key and value to it
     * in fact, it's useless currently.
     * perhaps i'll be used some day
     * so, just use it as this format
     * <p>
     * token is uncessary
     */
    public void initVerificationRequest(Context context, String key, String value,
                                        final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.POST, ServerConfig.INIT_REQUEST_OF_SERVICE_VERIFICATION_CODE,
                ServerConfig.KEY_TOKEN, "",
                key, value) {
            @Override
            public void netConnectionSuccess(Object data) {
                Log.d(TAG, "initVerificationRequest: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {
                Log.d(TAG, "initVerificationRequest: " + data.toString());
                failed(data, failCallback);
            }
        };
    }

    public void verifyUserWhetherExist(Context context, String phoneNumber,
                                       final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.GET, ServerConfig.CHECKUSER,
                ServerConfig.KEY_TOKEN, "",
                PersonService.KEY_PHONE_NUM, phoneNumber) {

            @Override
            public void netConnectionSuccess(Object data) {
                Log.d(TAG, "verifyUserWhetherExist: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {
                failed(data, failCallback);

            }
        };
    }

    //get verification code
    //token is uncessary

    /**
     * @param codeType: 0 注册
     *                  1 找回密码
     *                  2. 登陆
     * @return
     * @author henmory
     * @date 6/5/17
     * @description
     */
    public void getSMSVerificationCode(Context context, String phoneNumber, String codeType, String sessionId, String graphicCode,
                                       final SuccessCallback successCallback,
                                       final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.POST, ServerConfig.GET_VERIFICATION_CODE,
                ServerConfig.KEY_TOKEN, "",
                PersonService.KEY_PHONE_NUM, phoneNumber,
                PersonService.KEY_LOGIN_TYPE, Config.LoginType + "",
                PersonService.KEY_TYPE, codeType,
                PersonService.KEY_SESSION_ID, sessionId,
                PersonService.KEY_GRAPHIC_VERIFICATION_CODE, graphicCode) {
            @Override
            public void netConnectionSuccess(Object data) {
                Log.d(TAG, "getVerificationCode: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {
                failed(data, failCallback);
            }
        };

    }

    public void getImageVerificationCode(Context context, String phoneNumber, String sessionId,
                                         final SuccessCallback successCallback,
                                         final FailCallback failCallback) {

        new NetConnection(context, HttpMethord.GET, ServerConfig.GET_IMAGE_VERIFICATION_CODE,
                ServerConfig.KEY_TOKEN, "",
                PersonService.KEY_PHONE_NUM, phoneNumber,
                PersonService.KEY_SESSION_ID, sessionId) {
            @Override
            public void netConnectionSuccess(Object data) {
                Log.d(TAG, "getVerificationCode: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {
                failed(data, failCallback);
            }
        };

    }

    public void verifyVerificationCode(Context context, String phoneNumber, String codeType, String sessionId, String verificationCode,
                                       final SuccessCallback successCallback,
                                       final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.POST, ServerConfig.VERIFY_VERIFICATION_CODE,
                ServerConfig.KEY_TOKEN, "",
                PersonService.KEY_PHONE_NUM, phoneNumber,
                PersonService.KEY_LOGIN_TYPE, Config.LoginType + "",
                PersonService.KEY_TYPE, codeType,
                PersonService.KEY_VERIFICATION_CODE, verificationCode,
                PersonService.KEY_SESSION_ID, sessionId) {

            @Override
            public void netConnectionSuccess(Object data) {
                Log.d(TAG, "verifyVerificationCode: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {
                failed(data, failCallback);
            }
        };

    }

    public void register(Context context, String phoneNumber, String newPwd, int pwdMode,
                         int clientId, String verificationCode, final SuccessCallback successCallback,
                         final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.POST, ServerConfig.REGISTER,
                ServerConfig.KEY_TOKEN, "",
                PersonService.KEY_NUM, phoneNumber,
                PersonService.KEY_LOGIN_TYPE, Config.LoginType + "",
                PersonService.KEY_NEW_PASSWORD, newPwd,
                PersonService.KEY_PASSWORD_MODE, pwdMode + "",
                PersonService.KEY_CLIENT_ID, clientId + "",
                PersonService.KEY_VERIFICATION_CODE, verificationCode) {

            @Override
            public void netConnectionSuccess(Object data) {
                Log.d(TAG, "register: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {
                failed(data, failCallback);
            }
        };

    }


    public void login(Context context, String phoneNumber, String curPwd, int pwdMode,
                      int clientId, final SuccessCallback successCallback,
                      final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.POST, ServerConfig.LOGIN,
                ServerConfig.KEY_TOKEN, "",
                PersonService.KEY_NUM, phoneNumber,
                PersonService.KEY_LOGIN_TYPE, Config.LoginType + "",
                PersonService.KEY_CURRENT_PASSWORD, curPwd,
                PersonService.KEY_PASSWORD_MODE, pwdMode + "",
                PersonService.KEY_CLIENT_ID, clientId + "") {

            @Override
            public void netConnectionSuccess(Object data) {
                Log.d(TAG, "login: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {
                failed(data, failCallback);
            }
        };

    }

    public void reset(Context context, String phoneNumber, String newPwd,
                      int pwdMode, String verifyCode, final SuccessCallback successCallback,
                      final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.POST, ServerConfig.RESET,
                ServerConfig.KEY_TOKEN, "",
                PersonService.KEY_NUM, phoneNumber,
                PersonService.KEY_NEW_PASSWORD, newPwd,
                PersonService.KEY_PASSWORD_MODE, pwdMode + "",
                PersonService.KEY_VERIFICATION_CODE, verifyCode) {

            @Override
            public void netConnectionSuccess(Object data) {
                Log.d(TAG, "reset: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {
                failed(data, failCallback);
            }
        };

    }


    public void modifyPassword(Context context, String phoneNumber, String curPwd, String newPwd,
                               int pwdMode, final SuccessCallback successCallback,
                               final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.POST, ServerConfig.MODIFY,
                ServerConfig.KEY_TOKEN, "",
                PersonService.KEY_NUM, phoneNumber,
                PersonService.KEY_CURRENT_PASSWORD, curPwd,
                PersonService.KEY_NEW_PASSWORD, newPwd,
                PersonService.KEY_PASSWORD_MODE, pwdMode + "") {

            @Override
            public void netConnectionSuccess(Object data) {
                Log.d(TAG, "modifyPwd: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {
                failed(data, failCallback);
            }
        };

    }

    public void logout(Context context, String token, final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.DELETE, ServerConfig.LOGOUT,
                ServerConfig.KEY_TOKEN, token) {

            @Override
            public void netConnectionSuccess(Object data) {
                Log.d(TAG, "logout: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {
                failed(data, failCallback);
            }
        };

    }


    public void pay(Context context, String token, PayParam payParam,
                    final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.POST, ServerConfig.PAY,
                ServerConfig.KEY_TOKEN, token,
                PayService.KEY_CHANNEL, payParam.getChannel(),
                PayService.KEY_TYPE, payParam.getType() + "",
                PayService.KEY_AMOUNT, payParam.getAmount() + "",
                PayService.KEY_SERVICETIME, payParam.getMonth()+"") {
            @Override
            public void netConnectionSuccess(Object data) {
                Log.d(TAG, "pay: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {
                failed(data, failCallback);

            }
        };
    }

    public void payNotifyServer(Context context, String token, AlipayResultParam alipayResultParam,
                    final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.POST, ServerConfig.ALIPAYNOTIFY,
                ServerConfig.KEY_TOKEN, token,
                PayService.KEY_MEMO, alipayResultParam.getMemo(),
                PayService.KEY_RESULT, alipayResultParam.getResult() + "",
                PayService.KEY_RESULTSTATIS, alipayResultParam.getResultStatus() + "") {
            @Override
            public void netConnectionSuccess(Object data) {
                Log.d(TAG, "pay: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {
                failed(data, failCallback);

            }
        };
    }

    public void getPayDetails(Context context, String token, final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.GET, ServerConfig.PAY,
                ServerConfig.KEY_TOKEN, token){
            @Override
            public void netConnectionSuccess(Object data) {
                Log.d(TAG, "pay: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {
                failed(data, failCallback);

            }
        };
    }

    //获取设备列表
    public  void getDeviceList(Context context, String token,
                                     final SuccessCallback successCallback, final FailCallback failCallback){

        new NetConnection(context, HttpMethord.GET, ServerConfig.LIST, ServerConfig.KEY_TOKEN, token){

            @Override
            public void netConnectionSuccess(Object data) {
                Log.d(TAG, "getDeviceList: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {
                failed(data, failCallback);
            }
        };
    }

    //获取设备位置列表
    public void getBindDevicesPositionList(Context context, String token, String isNeedChangePoint,
                                           final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.GET, ServerConfig.MULTDEVICEINFO,
                ServerConfig.KEY_TOKEN, token,
                DevicesService.KEY_ISNEEDCHANGEPOINT, isNeedChangePoint) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                Log.d(TAG, "getBindDevicesPositionList: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                failed(data, failCallback);
            }
        };
    }
    //获取单个设备的位置
    public void getSingleBindDevicePosition(Context context, String token, String deviceId, String isNeedChangePoint,
                                           final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.GET, ServerConfig.REALTIMELOC,
                ServerConfig.KEY_TOKEN, token,
                DevicesService.KEY_DEV_ID, deviceId,
                DevicesService.KEY_ISNEEDCHANGEPOINT, isNeedChangePoint) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                Log.d(TAG, "getSingleBindDevicePosition: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                failed(data, failCallback);
            }
        };
    }

    //获取亲情号码
    public void getFamilyNumberList(Context context, String token, String deviceId,
                                            final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.GET, ServerConfig.FAMILYNUMLIST,
                ServerConfig.KEY_TOKEN, token,
                DevicesService.KEY_DEV_ID, deviceId){
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                Log.d(TAG, "getFamilyNumberList: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                failed(data, failCallback);
            }
        };
    }

    //获取亲情号码
    public void addFamilyNumber(Context context, String token, FuncFamNumView famNumView,
                                    final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.POST, ServerConfig.FAMILYNUMLIST,
                ServerConfig.KEY_TOKEN, token,
                DevicesService.KEY_DEV_ID, famNumView.getDevID()+"",
                DevicesService.KEY_NAME, famNumView.getName(),
                DevicesService.KEY_SEQ, famNumView.getSeq()+"",
                DevicesService.KEY_PHONE, famNumView.getPhone()){
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                Log.d(TAG, "addFamilyNumber: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                failed(data, failCallback);
            }
        };
    }

    //获取亲情号码
    public void deleteFamilyNumber(Context context, String token, String devId, int seq,
                                final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.DELETE, ServerConfig.FAMILYNUMLIST,
                ServerConfig.KEY_TOKEN, token,
                DevicesService.KEY_DEV_ID, devId,
                DevicesService.KEY_SEQ, seq+""){
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                Log.d(TAG, "addFamilyNumber: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                failed(data, failCallback);
            }
        };
    }
    public void updateDeviceNickname(Context context, String token, NickSetParam nickSetParam,
                                     final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.POST, ServerConfig.SETNICK,
                ServerConfig.KEY_TOKEN, token,
                DevicesService.KEY_DEVID, nickSetParam.getId()+"",
                DevicesService.KEY_NICK, nickSetParam.getNick()){
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                Log.d(TAG, "addFamilyNumber: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                failed(data, failCallback);
            }
        };

    }


    //获取亲情号码
    public void getLocationMode(Context context, String token, String deviceId,
                                    final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.GET, ServerConfig.GETLOCATIONMODE,
                ServerConfig.KEY_TOKEN, token,
                DevicesService.KEY_DEV_ID, deviceId){
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                Log.d(TAG, "getLocationMode: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                failed(data, failCallback);
            }
        };
    }

    //获取亲情号码
    public void setLocationMode(Context context, String token, LocModePara locModePara,
                                final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.POST, ServerConfig.SETLOCATIONMODE,
                ServerConfig.KEY_TOKEN, token,
                DevicesService.KEY_DEV_ID, locModePara.getId()+"",
                DevicesService.KEY_LOCMODE, locModePara.getLocMode()+""){
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                Log.d(TAG, "setLocationMode: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                failed(data, failCallback);
            }
        };
    }


    public  void getDeviceHistoryTrace(Context context, String token,  String deviceID,int isNeedLBS,
                                       String startTime, String endTime,
                                       final SuccessCallback successCallback, final FailCallback failCallback) {
        new NetConnection(context, HttpMethord.GET, ServerConfig.HISTORYLOC,
                ServerConfig.KEY_TOKEN, token,
                DevicesService.KEY_DEV_ID, deviceID+"",
                DevicesService.KEY_ISNEEDLBS, isNeedLBS+"",
                DevicesService.KEY_START_TIME, startTime,
                DevicesService.KEY_END_TIME, endTime){
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                Log.d(TAG, "getDeviceHistoryTrace: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                failed(data, failCallback);
            }
        };
    }


    //删除设备
    public void deleteBindDevice(Context context, final String token, String deviceID,
                                 final SuccessCallback successCallback, final FailCallback failCallback) {

        new NetConnection(context, HttpMethord.DELETE, ServerConfig.DELETEDEVICE,
                ServerConfig.KEY_TOKEN, token,
                DevicesService.KEY_DEV_ID, deviceID){
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                Log.d(TAG, "deleteBindDevice: " + data.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(data);
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                failed(data, failCallback);
            }
        };
    }

}
