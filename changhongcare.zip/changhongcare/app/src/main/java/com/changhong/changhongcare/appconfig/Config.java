package com.changhong.changhongcare.appconfig;

import android.content.Context;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.changhong.changhongcare.utils.SharedPreferencesHelper;
import com.changhong.changhongcare.utils.Utils;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;

import java.io.IOException;
import java.util.Map;

import static android.content.Context.TELEPHONY_SERVICE;

/**
 * author: henmory
 * time:  11/18/16
 * function:
 * description:
 */

public class Config {


    //values during the developing period time
    public static int LoginType = 2; //phone
    public static int PwdMode = 0; //不加密
    public static int ClientId = 4;//test

    private final static String  tag = "Config";
    public static String phoneNumber = null ;
    public static String password = null;
    public static String token = null;
    public static int passwordRememberedFlag = 1; // 默认记住密码
    public static int refresh_index = 0;//主界面刷新频率 默认为10秒
    public static int entry_boot_flag = 1;//默认进入
//    public static int position_mode_index = 0;

    public static String getDeviceid() {
        return device_id;
    }

    public static String device_id;



    //只有第一次进入app才有用，提示用户绑定设备，介绍主要功能.
    public static int first_enter_app = 1;//默认是第一次进入
    //软件的有效期
    public static String deadLine = null;


    public static final String KEY_IMEI = "imei";
    public final static String KEY_PHONE_NUMBER = "phone_number";
    public final static String KEY_PASSWORD = "password";
    public final static String KEY_PASSWORD_REMEMBERED_FLAG = "password_remembered_flag";
    public static final String KEY_TOKEN = "Token";
    public final static String KEY_REFRESH = "refresh_time";
    public final static String KEY_ENTRY_BOOT_FLAG = "entry_boot_flag";
    public final static String KEY_POSITION_MODE = "position_mode";
    public static final String KEY_DEVICE_ID = "device_id";
    public static final String KEY_FIRST_ENTRY_APP = "first-entry-app";



    public static void cachePhoneNumber(Context context, String string){
        phoneNumber = string;
        SharedPreferencesHelper.put(context, KEY_PHONE_NUMBER, string);
    }
    public static void cachePassword(Context context, String string){
        password = string;
        SharedPreferencesHelper.put(context, KEY_PASSWORD, string);
    }
    public static void cachePasswordRememberedFlag(Context context, int state){
        passwordRememberedFlag = state;
        SharedPreferencesHelper.put(context, KEY_PASSWORD_REMEMBERED_FLAG, state);
    }

    public static void cacheToken(Context context, String string) {
        token = string;
        SharedPreferencesHelper.put(context, KEY_TOKEN, string);
    }
    public static void cacheRefreshTime(Context context, int value) {
        refresh_index = value;
        SharedPreferencesHelper.put(context, KEY_REFRESH, value);
    }
    public static void cacheEntryBootFlag(Context context, int value) {
        entry_boot_flag = value;
        SharedPreferencesHelper.put(context, KEY_ENTRY_BOOT_FLAG, value);
    }
//
//    public static void cachePositionMode(Context context, int value) {
//        position_mode_index = value;
//        SharedPreferencesHelper.put(context, KEY_POSITION_MODE, value);
//    }

    public static void cacheFirst_enter_app(Context context, int value) {
        first_enter_app = value;
        SharedPreferencesHelper.put(context, KEY_FIRST_ENTRY_APP, value);
    }

    public static int getFirst_enter_app(Context context, String key) {
        first_enter_app = (int) SharedPreferencesHelper.get(context, key, 1);
        return first_enter_app;
    }



    public static String getCachedPhoneNumber(Context context, String key){
        phoneNumber = (String) SharedPreferencesHelper.get(context, key, null);
        return phoneNumber;
    }
    public static String getCachedPassword(Context context, String key){
        password = (String) SharedPreferencesHelper.get(context, key, null);
        return password;
    }
    public static int getCachedPasswordRememberedFlag(Context context, String key){
        passwordRememberedFlag = (int) SharedPreferencesHelper.get(context, key, false);
        return passwordRememberedFlag;
    }
    public static int getCachedBootEntryFlag(Context context, String key){
        entry_boot_flag = (int) SharedPreferencesHelper.get(context, key, false);
        return entry_boot_flag;
    }
    public static String getCachedTokencacheToken() {
        return token;
    }


    public static void removePhoneNumber(Context context){
        SharedPreferencesHelper.remove(context, Config.KEY_PHONE_NUMBER);
    }
    public static void removePassword(Context context){
        SharedPreferencesHelper.remove(context, Config.KEY_PASSWORD);
    }

    /**
     *  @author henmory
     *  @date 11/20/16
     *  @description    进入app初始化sp参数
     *
     *  @param
     *
     *  @return
    */
    public static void initAppPara(Context context){
        Map<String, ?> map = SharedPreferencesHelper.getAll(context);

        if (map.size() > 0){
            phoneNumber = (String) map.get(Config.KEY_PHONE_NUMBER);
            password = (String) map.get(Config.KEY_PASSWORD);
            token = (String) map.get(Config.KEY_TOKEN);

            Object o = map.get(Config.KEY_ENTRY_BOOT_FLAG);
            if (o != null){
                entry_boot_flag = (Integer)o;
            }else{
                entry_boot_flag = 1;
            }
            //取消记住密码选项，自动记住密码
//            Object o  = map.get(KEY_PASSWORD_REMEMBERED_FLAG);
//            if (o != null){
//                passwordRememberedFlag = (Integer) o;
//            }else{
//                passwordRememberedFlag = 0;
//            }
            o = map.get(Config.KEY_REFRESH);
            if (o != null){
                refresh_index = (Integer)o ;
            }else{
                refresh_index = 0;
            }
//            o = map.get(Config.KEY_POSITION_MODE);
//            if (o != null){
//                position_mode_index = (Integer) o;
//            }else{
//                position_mode_index = 0;
//            }
            cacheFirst_enter_app(context, 0);

        }else{//第一次开启app
            cacheFirst_enter_app(context, 1);
            refresh_index = 0;
            cacheRefreshTime(context, 0);
            cacheEntryBootFlag(context,1);//进入导航页
//            position_mode_index = 0;
//            cachePositionMode(context, 0);
        }
        device_id = -1+"";
        Log.d(tag, "phoneNumber = " + phoneNumber + "; password = " + password + "; first_enter_app = " + first_enter_app
                + " ; entty_boot_flag = " + entry_boot_flag + "; token = " + token);
    }

}
