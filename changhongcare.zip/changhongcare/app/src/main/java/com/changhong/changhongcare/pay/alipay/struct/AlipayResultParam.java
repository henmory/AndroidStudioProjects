package com.changhong.changhongcare.pay.alipay.struct;

/**
 * author: henmory
 * time:  6/15/17
 * function:
 * description:
 */

public class AlipayResultParam {
    String memo; //描述信息
    String result; //处理结果
    String resultStatus; //结果码

    public AlipayResultParam(String memo, String result, String resultStatus) {
        this.memo = memo;
        this.result = result;
        this.resultStatus = resultStatus;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getResultStatus() {
        return resultStatus;
    }

    public void setResultStatus(String resultStatus) {
        this.resultStatus = resultStatus;
    }
}
