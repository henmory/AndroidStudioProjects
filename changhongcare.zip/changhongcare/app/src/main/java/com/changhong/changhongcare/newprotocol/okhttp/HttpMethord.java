package com.changhong.changhongcare.newprotocol.okhttp;

/**
 * Created by dan on 6/24/16.
 */
public class HttpMethord {
    public static final String GET = "GET";
    public static final String POST = "POST";
    public static final String DELETE = "DELETE";
}
