package com.changhong.changhongcare.oldprotocol.ksoap;

/**
 * Created by dan on 10/24/16.
 */

public class KsoapConfig {

    public static final String NAME_SPACE = "http://tempuri.org/";

    public class MessageModel{
        public static final int ReturnMesssage = 0;
        public static final int ReturnObject = 1;
        public static final int ReturnStatus = 2;
    }

    public class PersonService{

        public static final String END_POINT = "http://118.126.10.86:9001/CHElderPhoneWcfService/PersonService.svc";
        public static final String KEY_FLAG = "IPersonService/";

        /**********************user mode*******************/
        //out: ResponseMessage
        public class Register{
            public static final String KEY_METHORD_NAME = "Register";
            public static final String KEY_USER_ACCOUNT = "account";
            public static final String KEY_PASSWORD = "password_icon";
            public static final String KEY_CODE = "code";
        }
        public class GetCodeBySMS{
            public static final String KEY_METHORD_NAME = "GetCodeBySMS";
            public static final String KEY_TELEPHONE = "telephone";
        }
        public class GetCodeByPhone{
            public static final String KEY_METHORD_NAME = "GetCodeByPhone";

            public static final String KEY_TELEPHONE = "telephone";
        }
        public class GetCodeByEmail{
            public static final String KEY_METHORD_NAME = "GetCodeByEmail";
            public static final String KEY_EMAIL = "email";
        }
        public class ValidateUser{
            public static final String KEY_METHORD_NAME = "ValidateUser";
            public static final String KEY_USER_ACCOUNT = "userAccount";
        }
        public class IsVeriCodeCorrect{
            public static final String KEY_METHORD_NAME = "IsVeriCodeCorrect";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_CODE = "code";

        }
        public class Login{
            public static final String KEY_METHORD_NAME = "Login";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_PASSWORD = "password";
        }
        public class ResetPwd{
            public static final String KEY_METHORD_NAME = "ResetPwd";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_PASSWORD = "password";
        }
        public class ModifyPwd{
            public static final String KEY_METHORD_NAME = "ModifyPwd";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_NEW_PWD = "newPwd";
            public static final String KEY_OLD_WD = "oldPwd";
        }
        /**********************user mode*******************/
        public class AddDevice{
            public static final String KEY_METHORD_NAME = "AddDevice";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_USER_TELE = "userTele";
            public static final String KEY_CODE = "code";
        }
        public class RemoveDevice{
            public static final String KEY_METHORD_NAME = "RemoveDevice";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_IMEI = "imei";
        }

        public class GetPersonDevice{
            public static final String KEY_METHORD_NAME = "GetPersonDevice";
            public static final String KEY_USER_ACCOUNT = "userAccount";
        }
        public class GetPersonOneDeviceInfo{
            public static final String KEY_METHORD_NAME = "GetPersonOneDeviceInfo";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_DEVICE_ID = "deviceID";
        }
        public class GetPersonDevicesPosInfo{
            public static final String KEY_METHORD_NAME = "GetPersonDevicesPosInfo";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_IS_NEED_CHANGE_POINT = "isNeedChangePoint";
        }
        public class UploadSharePic{
            public static final String KEY_METHORD_NAME = "UploadSharePic";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_DEVICE_IMEI = "deviceIMEI";
            public static final String KEY_UP_IMAGE = "upImage";
        }
        public class DownloadSharePic{
            public static final String KEY_METHORD_NAME = "DownloadSharePic";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_DEVICE_IMEI = "deviceIMEI";
            public static final String KEY_DEVICE_TYPE = "deviceType";
        }
        /*暂时无用
        public class GetHistoryAlarm{
            public static final String KEY_METHORD_NAME = "GetHistoryAlarm";
            public static final String KEY_DEVICE_ID = "deviceID";
        }
        public static final String KEY_METHORD_NAME = "IosTest";
        */
    }

    public class DeviceService{
        public static final String END_POINT = "http://118.126.10.86:9001/CHElderPhoneWcfService/DeviceService.svc";
        public static final String KEY_FLAG = "IDeviceService/";
        public class GetDeviceHispos{
            public static final String KEY_METHORD_NAME = "GetDeviceHispos";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_IS_NEED_CHANGE_POINT = "isNeedChangePoint";
            public static final String KEY_DEVICE_ID = "deviceID";
            public static final String KEY_TIME_START = "timeStart";
            public static final String KEY_TIME_END = "timeEnd";
            public static final String KEY_IS_NEED_LBS = "isNeedLBS";

        }
        public class GetRelationsByDeviceID{
            public static final String KEY_METHORD_NAME = "GetRelationsByDeviceID";
            public static final String KEY_DEVICE_ID = "deviceID";

        }
        public class SetDeviceRelation{
            public static final String KEY_METHORD_NAME = "SetDeviceRelation";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_DEVICE_ID = "deviceID";
            public static final String KEY_SEQ_NO = "seqNO";
            public static final String KEY_TEL_NO = "telNO";
            public static final String KEY_RELATION = "relationName";

        }
        public class DeleteRelationByDeviceID{
            public static final String KEY_METHORD_NAME = "DeleteRelationByDeviceID";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_DEVICE_ID = "deviceID";
            public static final String KEY_SEQ_NO = "seqNO";
            public static final String KEY_TEL_NO = "telNO";
        }
        public class GetAllEleFence{
            public static final String KEY_METHORD_NAME = "GetAllEleFence";
            public static final String KEY_DEVICE_ID = "deviceID";

        }
        public class SetDeviceFence{
            public static final String KEY_METHORD_NAME = "SetDeviceFence";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_DEVICE_ID = "deviceID";
            public static final String KEY_FENCE_ID = "fenceID";
            public static final String KEY_LO = "lo";
            public static final String KEY_LA = "la";
            public static final String KEY_RAD = "rad";
            public static final String KEY_FENCE_NAME = "fenceName";

        }
        public class DeleteOneFence{
            public static final String KEY_METHORD_NAME = "DeleteOneFence";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_FENCE_ID = "fenceID";

        }
        public class SetDevicetInterval{
            public static final String KEY_METHORD_NAME = "SetDevicetInterval";
            public static final String KEY_DEVICE_ID = "deviceID";
            public static final String KEY_INTERVAL = "interval";

        }
        public class GeDevicetInterval{
            public static final String KEY_METHORD_NAME = "GeDevicetInterval";
            public static final String KEY_DEVICE_ID = "deviceID";

        }

        public class UpdateOneDeviceNickName{
            public static final String KEY_METHORD_NAME = "UpdateOneDeviceNickName";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_DEVICE_ID = "deviceID";
            public static final String KEY_NICK_NAME = "nickName";
            public static final String KEY_TELE = "tele";

        }
        public class GetRecentFivePos{
            public static final String KEY_METHORD_NAME = "GetRecentFivePos";
            public static final String KEY_IS_NEED_CHANGE_POINT = "isNeedChangePoint";

        }
        /*暂时无用
        public class GetDevicesPosByDeviceIDSFromRam{
            public static final String KEY_METHORD_NAME = "GetDevicesPosByDeviceIDSFromRam";
            public static final String KEY_USER_ACCOUNT = "userAccount";
            public static final String KEY_IS_NEED_CHANGE_POINT = "isNeedChangePoint";
            public static final String KEY_DEVICE_IDS = "deviceIDs";

        }
        public class GetDeviceByBounds{
            public static final String KEY_METHORD_GET_DEVICE_BY_BOUNDS_NAME = "GetDeviceByBounds";

        }
        public class GetDeviceByBoundsAdd{
            public static final String KEY_METHORD_GET_DEVICE_BY_BOUNDS_ADD_NAME = "GetDeviceByBoundsAdd";

        }
        public class GetOnlineAndNewDevice{
            public static final String KEY_METHORD_GET_ONLINE_AND_NEW_DEVICE_NAME = "GetOnlineAndNewDevice";

        }
        */
    }


}
