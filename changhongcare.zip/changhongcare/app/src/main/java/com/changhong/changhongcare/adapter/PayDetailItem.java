package com.changhong.changhongcare.adapter;

/**
 * author: henmory
 * time:  6/20/17
 * function:
 * description:
 */

public class PayDetailItem {

    private String time;//支付时间
    private String flowNo;//流水号
    private double amount;//消费金额
    private String payMethord;//支付方式
    private int payStatus;//支付状态
    private int serviceTime;//购买服务套餐月数

    public PayDetailItem() {
    }

    public PayDetailItem(String time, String flowNo, double amount, String payMethord, int payStatus, int serviceTime) {
        this.time = time;
        this.flowNo = flowNo;
        this.amount = amount;
        this.payMethord = payMethord;
        this.payStatus = payStatus;
        this.serviceTime = serviceTime;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getFlowNo() {
        return flowNo;
    }

    public void setFlowNo(String flowNo) {
        this.flowNo = flowNo;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getPayMethord() {
        return payMethord;
    }

    public void setPayMethord(String payMethord) {
        this.payMethord = payMethord;
    }

    public int getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(int payStatus) {
        this.payStatus = payStatus;
    }

    public int getServiceTime() {
        return serviceTime;
    }

    public void setServiceTime(int serviceTime) {
        this.serviceTime = serviceTime;
    }

    @Override
    public String toString() {
        return "PayDetailItem{" +
                "time='" + time + '\'' +
                ", flowNo='" + flowNo + '\'' +
                ", amount=" + amount +
                ", payMethord='" + payMethord + '\'' +
                ", payStatus=" + payStatus +
                ", serviceTime=" + serviceTime +
                '}';
    }
}
