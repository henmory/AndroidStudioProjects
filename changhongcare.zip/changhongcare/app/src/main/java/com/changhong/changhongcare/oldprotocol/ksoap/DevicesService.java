package com.changhong.changhongcare.oldprotocol.ksoap;

import android.content.Context;
import android.util.Log;

import com.amap.api.maps2d.model.LatLng;
import com.changhong.changhongcare.Interface.Callback;
import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.oldprotocol.structFromService.Device;
import com.changhong.changhongcare.oldprotocol.structFromService.Position;
import com.changhong.changhongcare.oldprotocol.structFromService.FamilyNumber;


import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * author: henmory
 * time:  12/23/16
 * function:
 * description:在用户操作逻辑处理完之后，根据服务器返回的结果，按照操作成功失败，处理逻辑数据，把前台需要的数据解析出来
 */

public class DevicesService {

    private final static String TAG = "DevicesService";
    private static ServiceInterface serviceInterface = new ServiceInterface();


    public static List<Position> getPositionList() {
        return positionList;
    }

    private static List<Position> positionList = new ArrayList<>();

    public static List<Position> getHistoryPositionList() {
        return historyPositionList;
    }

    private static List<Position> historyPositionList = new ArrayList<>();

    public static Map<String, String> getMap() {
        return map;
    }

    public static void setMap(Map<String, String> map) {
        DevicesService.map = map;
    }

    private static Map<String, String> map = new HashMap<>();//key=imei，value=pisition=====绑定设备位置的字符串表示形式

    //////////////////////////////////////////暂时没有用//////////////////////////////////////////////////////
    private static Device device = new Device();// TODO: 12/23/16 更改为列表 设备列表

    /**
     * @param string 服务器传回的数据
     * @return 1 表示解析成功
     * 0 表示解析出错
     * @author henmory
     * @date 11/2/16
     * @description: 服务器传回的设备信息是string类型，需要转型为 Device
     */
    private static int string2DeviceInfoStruct(final String string) {
        if (string == null || string.isEmpty()) {
            return 0;
        }
        Log.d(TAG, "original string = " + string.toString());
        String leftString = string;
        int end = leftString.indexOf(",");
        if (end > 0) {
            String deviceID = leftString.substring(0, end);
            Log.d(TAG, "str_device_id = " + deviceID);
            int id = Integer.parseInt(deviceID);
            device.setDeviceID(id);

            leftString = leftString.substring(end + 1);
            Log.d(TAG, "no str_device_id = " + leftString);
            end = leftString.indexOf(",");

            if (end > 0) {
                String name = leftString.substring(0, end);
                Log.d(TAG, "name  = " + name);
                device.setDeviceName(name);

                leftString = leftString.substring(end + 1);
                Log.d(TAG, "no name = " + leftString);
                end = leftString.indexOf(",");
                if (end > 0) {
                    String strIMEI = leftString.substring(0, end);
                    Log.d(TAG, "strIMEI = " + strIMEI);
                    device.setDeviceIMEI(strIMEI);

                    leftString = leftString.substring(end + 1);
                    Log.d(TAG, "no IMei = " + leftString);
                    if (leftString.length() > 0) {
                        device.setDeviceType(leftString);
                        return 1;
                    }
                }
            }
        }
        return 0;
    }

    //获取设备列表
    public static void getBindDevicesList(Context context, String userAccount,
                                          final SuccessCallback successCallback, final FailCallback failCallback) {
        //获取绑定设备列表
        serviceInterface.getBindDevicesList(context, userAccount, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                String data = (String) object;
                if (1 == string2DeviceInfoStruct(data)) {
                    if (null != successCallback) {
                        successCallback.onSuccess(device);
                    }
                }

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (null != failCallback) {
                    failCallback.onFail(object);
                }
            }
        });

    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    private static void getPosInfoFromSoapObject(SoapObject soapObject, Position position) {

        SoapPrimitive soapPrimitive = (SoapPrimitive) soapObject.getProperty(0);
        if (null != soapPrimitive)
            position.setAccStatus((String) soapPrimitive.getValue());//电池

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(1);
        if (null != soapPrimitive)
            position.setAddress((String) soapPrimitive.getValue());//地址

        //alarm 暂时不用
//        SoapObject soap = (SoapObject) soapObject.getProperty(2);
//        if (null != soap) {
//            soapPrimitive = (SoapPrimitive) soapObject.getProperty(0);
//            if (null != soapPrimitive)
//                position.setAlarm((String) soapPrimitive.getValue()); //// TODO: 11/7/16
//        }

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(3);
        if (null != soapPrimitive)
            position.setCellID((String) soapPrimitive.getValue());

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(4);
        int deviceBell = Integer.parseInt((String) soapPrimitive.getValue());
        position.setDeviceBell(deviceBell);

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(5);
        String deviceID = (String) soapPrimitive.getValue();
        position.setDeviceID(deviceID);


        soapPrimitive = (SoapPrimitive) soapObject.getProperty(6);
        if (null != soapPrimitive)
            position.setDeviceIMEI((String) soapPrimitive.getValue());

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(7);
        if (null != soapPrimitive)
            position.setDeviceName((String) soapPrimitive.getValue());


//        soap = (SoapObject) soapObject.getProperty(8);
//        if (null != soap) {
//            soapPrimitive = (SoapPrimitive) soapObject.getProperty(0);
//            if (null != soapPrimitive)
//                position.setDeviceTele((String) soapPrimitive.getValue()); //// TODO: 11/7/16
//        }


        soapPrimitive = (SoapPrimitive) soapObject.getProperty(9);
        int deviceType = Integer.parseInt((String) soapPrimitive.getValue());
        position.setDeviceType(deviceType);

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(10);
        if (null != soapPrimitive)
            position.setDeviceTypeName((String) soapPrimitive.getValue());

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(11);
        int direction = Integer.parseInt((String) soapPrimitive.getValue());
        position.setDirection(direction);

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(12);
        int fenceNum = Integer.parseInt((String) soapPrimitive.getValue());
        position.setFenceNum(fenceNum);

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(13);
        if (null != soapPrimitive)
            position.setFirstLinkManTel((String) soapPrimitive.getValue());

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(14);
        if (null != soapPrimitive)
            position.setFirstUseTime((String) soapPrimitive.getValue());

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(15);
        if (null != soapPrimitive)
            position.setGarrisonStatus((String) soapPrimitive.getValue());

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(16);
        int garrisonSwitch = Integer.parseInt((String) soapPrimitive.getValue());
        position.setGarrisonSwitch(garrisonSwitch);

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(17);
        if (null != soapPrimitive)
            position.setGpsTime((String) soapPrimitive.getValue());


        soapPrimitive = (SoapPrimitive) soapObject.getProperty(18);
        int gsm = Integer.parseInt((String) soapPrimitive.getValue());
        position.setGsm(gsm);

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(19);
        int highSpeed = Integer.parseInt((String) soapPrimitive.getValue());
        position.setHighSpeed(highSpeed);


        soapPrimitive = (SoapPrimitive) soapObject.getProperty(20);
        double la = Double.parseDouble((String) soapPrimitive.getValue());
        position.setLa(la);


        soapPrimitive = (SoapPrimitive) soapObject.getProperty(21);
        double lo = Double.parseDouble((String) soapPrimitive.getValue());
        position.setLo(lo);

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(22);
        if (null != soapPrimitive)
            position.setLocationTimeSpan((String) soapPrimitive.getValue());

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(23);
        if (null != soapPrimitive)
            position.setMileage((String) soapPrimitive.getValue());

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(24);
        if (null != soapPrimitive)
            position.setMileageDate((String) soapPrimitive.getValue());

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(25);
        if (null != soapPrimitive)
            position.setNickName((String) soapPrimitive.getValue());

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(26);
        if (null != soapPrimitive)
            position.setOpenAccountTime((String) soapPrimitive.getValue());

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(27);
        int pointed = Integer.parseInt((String) soapPrimitive.getValue());
        position.setPointed(pointed);

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(28);
        int positionMode = Integer.parseInt((String) soapPrimitive.getValue());
        position.setPositionMode(positionMode);

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(29);
        int power = Integer.parseInt((String) soapPrimitive.getValue());
        position.setPower(power);

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(30);
        if (null != soapPrimitive)
            position.setRelayStatus((String) soapPrimitive.getValue());

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(31);
        int statelliteNum = Integer.parseInt((String) soapPrimitive.getValue());
        position.setStatelliteNum(statelliteNum);

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(32);
        if (null != soapPrimitive)
            position.setServiceEndTime((String) soapPrimitive.getValue());

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(33);
        int speed = Integer.parseInt((String) soapPrimitive.getValue());
        position.setSpeed(speed);

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(34);
        if (null != soapPrimitive)
            position.setStatus((String) soapPrimitive.getValue());

        soapPrimitive = (SoapPrimitive) soapObject.getProperty(35);
        int totalMileage = Integer.parseInt((String) soapPrimitive.getValue());
        position.setTotalMileage(totalMileage);
    }

    //获取详细的设备信息
    private static void getDetailedDeviceInfo(SoapObject soapObject) {
//        Log.d(TAG, soapObject.toString());

        Position detailedInfo = new Position();

        //设置id
        SoapPrimitive soapPrimitive = (SoapPrimitive) soapObject.getProperty(0);
        if (null != soapPrimitive) {
            String strID = (String) soapPrimitive.getValue();
            detailedInfo.setDeviceID(strID);
        }


        //设置IMEI
        soapPrimitive = (SoapPrimitive) soapObject.getProperty(1);
        String strIMEI = (String) soapPrimitive.getValue();
        detailedInfo.setDeviceIMEI(strIMEI);

        //设置imgurl
        soapPrimitive = (SoapPrimitive) soapObject.getProperty(2);
        String imgUrl = (String) soapPrimitive.getValue();
        detailedInfo.setImgUrl(imgUrl);

        //设置设备名称
        soapPrimitive = (SoapPrimitive) soapObject.getProperty(3);
        if (null != soapPrimitive) {

            String deviceName = (String) soapPrimitive.getValue();
            detailedInfo.setDeviceName(deviceName);
        }
        //设置位置信息
        SoapObject positionObject = (SoapObject) soapObject.getProperty(4);
        getPosInfoFromSoapObject(positionObject, detailedInfo);

        //设置设备电话号码
        soapPrimitive = (SoapPrimitive) soapObject.getProperty(5);
        if (null != soapPrimitive) {
            String deviceTel = (String) soapPrimitive.getValue();
            detailedInfo.setDeviceTele(deviceTel);
        }
        //设置设备类型
        soapPrimitive = (SoapPrimitive) soapObject.getProperty(6);
        String strType = (String) soapPrimitive.getValue();
        int type = Integer.parseInt(strType);
        detailedInfo.setDeviceType(type);

        //设置设备nick name
        soapPrimitive = (SoapPrimitive) soapObject.getProperty(7);
        String nickName = (String) soapPrimitive.getValue();
        detailedInfo.setNickName(nickName);

        positionList.add(detailedInfo);
        Log.d(TAG, "所有设备：" + positionList.toString());

    }

    /**
     *  @author henmory
     *  @date 12/26/16
     *  @description 获取设备列表，所有设备的所有信息
     *
     *  @param  successCallback 成功后回调
     *          failCallback 失败后回调
     *
     *  @return
    */
    public static void getBindDevicesPositionList(Context context, String userAccount, String isNeedChangePoint,
                                                  final SuccessCallback successCallback, final FailCallback failCallback) {
        //获取绑定设备列表
        serviceInterface.getBindDevicesPositionList(context, userAccount, isNeedChangePoint, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                SoapObject data = (SoapObject) object;
                SoapObject temp = null;
                positionList.clear();
                for (int i = 0; i < data.getPropertyCount(); i++) {
                    temp = (SoapObject) data.getProperty(i);
                    Log.d(TAG, "devce_index = " + i);
                    Log.d(TAG, "data = " + temp.toString());
                    getDetailedDeviceInfo(temp);
                }
                if (null != successCallback) {
                    List<LatLng> latlngList = new ArrayList<>();
                    for (int i = 0; i < positionList.size(); i++) {
                        latlngList.add(new LatLng(positionList.get(i).getLa(), positionList.get(i).getLo()));
                    }
                    successCallback.onSuccess(latlngList);
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (null != failCallback) {
                    failCallback.onFail(object);
                }
            }
        });
    }

    /**
     *  @author henmory
     *  @date 12/26/16
     *  @description    获取设备列表 所有设备的所有信息
     *
     *  @param  callback 无论成功或者失败都调用，用在最初进入app时，显示主界面
     *
     *  @return
    */
    public static void getBindDevicesPositionList(Context context, String userAccount, final Callback callback){
        getBindDevicesPositionList(context, userAccount, 1 + "", new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(TAG, "getBindDevicesPositionList success");
                if (null != callback){
                    callback.callBack(object);
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d(TAG, "getBindDevicesPositionList failed");
                if (null != callback){
                    callback.callBack(object);
                }
            }
        });
    }


    /**
     *  @author henmory
     *  @date 12/26/16
     *  @description    获取设备的亲情号码
     *
     *  @param
     *
     *  @return
    */

    public static void getDeviceFamilyNumbers(Context context, String deviceID,
                                              final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.getDeviceFamilyNumbers(context, deviceID, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                if (successCallback != null){
                    List<FamilyNumber> familyNumbers = getFamilyNumbers((SoapObject)object);

                    successCallback.onSuccess(familyNumbers);
                }

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (failCallback != null){
                    Log.d(TAG, "failed " + object.toString());
                    failCallback.onFail(object);
                }
            }
        });
    }

    private static List<FamilyNumber> getFamilyNumbers(SoapObject o){
        List<FamilyNumber> familyNumbers = new ArrayList<>();
        SoapObject object;
        SoapPrimitive soapPrimitive;
        for(int i = 0; i < o.getPropertyCount(); i++){

            FamilyNumber familyNumber = new FamilyNumber();
            object = (SoapObject) o.getProperty(i);
            Log.d(TAG, "第 " + i + " 个亲情号码" + object.toString());

            //获取设备ID
            soapPrimitive = (SoapPrimitive) object.getProperty(0);
            familyNumber.setDeviceID((String) soapPrimitive.getValue());

            //获取亲情号码名称 // TODO: 1/10/17 两个结构体不一样 
//            soapPrimitive = (SoapPrimitive) object.getProperty(1);
//            familyNumber.setLinkmanName((String) soapPrimitive.getValue());


            //获取亲情号码
            soapPrimitive = (SoapPrimitive) object.getProperty(2);
            familyNumber.setLinkmanPhone((String) soapPrimitive.getValue());

            //设置亲情号码索引
            soapPrimitive = (SoapPrimitive) object.getProperty(3);
            String str_index = (String) soapPrimitive.getValue();
            int i_index = Integer.parseInt(str_index);
            familyNumber.setSeqNum(i_index);

            Log.d(TAG, "本地保存亲情号码：" + familyNumber.toString());

            //添加
            familyNumbers.add(familyNumber);
        }

        return familyNumbers;
    }

    /**
     *  @author henmory
     *  @date 12/28/16
     *  @description    获取设备上传位置心跳
     *
     *  @param
     *
     *  @return
    */

    public static void getBindDeviceUploadPositionInterval(Context context, String deviceID,
                                                           final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.getBindDeviceUploadPositionInterval(context, deviceID, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(TAG, object.toString());
                String interval = (String) object;
                int ret = Integer.parseInt(interval);
                if (successCallback != null){

                    successCallback.onSuccess(ret);
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (failCallback != null){
                    Log.d(TAG, "failed " + object.toString());
                    failCallback.onFail(object);
                }
            }
        });
    }

    /**
     *  @author henmory
     *  @date 12/28/16
     *  @description    设置设备的心跳
     *
     *  @param
     *
     *  @return
    */
    public static void setBindDeviceUploadPositionInterval(Context context, final String deviceID, final int interval,
                                                           final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.setBindDeviceUploadPositionInterval(context, deviceID, interval, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                if (null != object){
                    Log.d(TAG, "心跳设置成功");
                }
                //更新ram中数据，防止服务器更新完成后，客户端显示不出来
                for (int i = 0; i < positionList.size(); i++){
                    if (deviceID.equals(positionList.get(i).getDeviceID())){
                        positionList.get(i).setPositionMode(interval);
                    }
                }
                if (successCallback != null){
                    successCallback.onSuccess(null);
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (failCallback != null){
                    Log.d(TAG, "failed " + object.toString());
                    failCallback.onFail(object);
                }
            }
        });
    }
    
    /**
     *  @author henmory
     *  @date 12/28/16
     *  @description    获取设备的历史轨迹（只能是某一天的历史轨迹）
     *
     *  @param
     *
     *  @return
    */
    public static void getBindDeviceHistoryTrace(Context context, String userAccount, int isNeedChangePoint, String deviceID,
                                          String startTime, String endTime, int isNeedLBS,
                                          final SuccessCallback successCallback, final FailCallback failCallback){

        serviceInterface.getBindDeviceHistoryTrace(context, userAccount, isNeedChangePoint, deviceID,
                                                    startTime, endTime, isNeedLBS, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(TAG, object.toString());
                historyPositionList.clear();
                getHistoryTrace((SoapObject)object);
                if (null != successCallback){
                    successCallback.onSuccess(historyPositionList);
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (failCallback != null){
                    Log.d(TAG, "failed " + object.toString());
                    failCallback.onFail(object);
                }
            }
        });

    }

    private static void getHistoryTrace(SoapObject object){
        SoapObject o;
        for (int i = 0; i < object.getPropertyCount(); i++){
            Position position = new Position();
            o = (SoapObject) object.getProperty(i);
            getPosInfoFromSoapObject(o, position);
            Log.d(TAG, "本地保存的历史轨迹：" + position.toString());
            historyPositionList.add(position);
        }
        Log.d(TAG, "所有存的历史轨迹：" + historyPositionList.toString());

    }

    /**
     *  @author henmory
     *  @date 12/30/16
     *  @description    添加设备
     *
     *  @param
     *
     *  @return
    */

    // TODO: 12/30/16 没有完成
    public void addBindDevice(Context context, final String userAccount,String userTele, String code,
                              final SuccessCallback successCallback, final FailCallback failCallback) {
        serviceInterface.addBindDevice(context, userAccount, userTele, code, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {

            }
        });
    }
    /**
     *  @author henmory
     *  @date 12/30/16
     *  @description    删除设备
     *
     *  @param
     *
     *  @return
    */
    // TODO: 12/30/16 没有完成

    public static void deleteBindDevice(Context context, final String userAccount, String imei,
                                 final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.deleteBindDevice(context, userAccount, imei, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                if (null != successCallback){
                    successCallback.onSuccess(null);
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (failCallback != null){
                    Log.d(TAG, "failed " + object.toString());
                    failCallback.onFail(object);
                }
            }
        });

    }

    /**
     *  @author henmory
     *  @date 12/30/16
     *  @description 删除亲情号码
     *
     *  @param
     *
     *  @return
    */

    public static void deleteDeviceFamilyNumbers(Context context, String userAccount, String deviceID, int seqNO, String telNO,
                                          final SuccessCallback successCallback, final FailCallback failCallback) {
        serviceInterface.deleteDeviceFamilyNumbers(context, userAccount, deviceID, seqNO, telNO,
                new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                if (null != successCallback){
                    successCallback.onSuccess(null);
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (null != failCallback){
                    failCallback.onFail(object);
                }
            }
        });
    }
    /**
     *  @author henmory
     *  @date 12/30/16
     *  @description    添加亲情号码
     *
     *  @param
     *
     *  @return
    */
    // TODO: 1/9/17 上传服务器需要加上亲情号码索引，但是网页上只能显示前3个，服务器可以添加任意个，客户端做的也要是任意个
    public static void addDeviceFamilyNumbers(Context context, String userAccount, String deviceID, int seqNO, String telNO, String name,
                                       final SuccessCallback successCallback, final FailCallback failCallback) {

        serviceInterface.addDeviceFamilyNumbers(context, userAccount, deviceID, seqNO, telNO, name, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(TAG, "addDeviceFamilyNumbers data = " + object.toString());
                if (null != successCallback){
                    successCallback.onSuccess(null);
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (null != failCallback){
                    failCallback.onFail(object);
                }
            }
        });

    }


    public static void updateDeviceNIckName(Context context, final String userAccount,String deviceID, String nickName, String tele,
                                     final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.updateDeviceNIckName(context, userAccount, deviceID, nickName, tele, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                if (null != successCallback){
                    successCallback.onSuccess(null);
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (null != failCallback){
                    failCallback.onFail(object.toString());
                }
            }
        });
    }

}
