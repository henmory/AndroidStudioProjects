package com.changhong.changhongcare.newprotocol.structfromserver;

/**
 * author: henmory
 * time:  6/26/17
 * function:
 * description:
 */

public class NickSetParam {
    private long id;
    private String nick;

    public NickSetParam(long id, String nick) {
        this.id = id;
        this.nick = nick;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }
}
