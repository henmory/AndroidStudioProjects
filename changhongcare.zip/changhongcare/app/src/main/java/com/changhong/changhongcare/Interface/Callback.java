package com.changhong.changhongcare.Interface;

/**
 * author: henmory
 * time:  12/23/16
 * function:
 * description:
 */

public interface Callback {
    void callBack(Object object);
}
