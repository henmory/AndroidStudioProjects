package com.changhong.changhongcare.newprotocol.service;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.newprotocol.okhttp.ServerConfig;
import com.changhong.changhongcare.newprotocol.structfromserver.FuncBasicPosView;
import com.changhong.changhongcare.newprotocol.structfromserver.FuncCurPosView;
import com.changhong.changhongcare.newprotocol.structfromserver.FuncFamNumView;
import com.changhong.changhongcare.newprotocol.structfromserver.FuncHistPosView;
import com.changhong.changhongcare.newprotocol.structfromserver.FuncPhoneView;
import com.changhong.changhongcare.newprotocol.structfromserver.LocModePara;
import com.changhong.changhongcare.newprotocol.structfromserver.NickSetParam;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * author: henmory
 * time:  12/23/16
 * function:
 * description:在用户操作逻辑处理完之后，根据服务器返回的结果，按照操作成功失败，处理逻辑数据，把前台需要的数据解析出来
 */

public class DevicesService {

    private final static String TAG = "DevicesService";
    public final static String KEY_ISNEEDCHANGEPOINT = "isNeedChangePoint";
    public final static String KEY_DEV_ID = "devId";
    public final static String KEY_ID = "Id";
    public final static String KEY_TYPE = "Type";

    public static final String KEY_IMEI = "Imei";
    public static final String KEY_NICK = "Nick";
    public static final String KEY_LAT = "Lat";
    public static final String KEY_LNG = "Lng";
    public static final String KEY_DEVID = "DevId";
    public static final String KEY_ALARM = "Alarm";
    public static final String KEY_GPS_TIME = "GpsTime";
    public static final String KEY_GSM = "Gsm";
    public static final String KEY_POINTED = "Pointed";
    public static final String KEY_POWER = "Power";
    public static final String KEY_SATELLITENUM = "SatelliteNum";
    public static final String KEY_STATUS = "Status";
    public static final String KEY_NAME = "Name";
    public static final String KEY_SEQ = "Seq";
    public static final String KEY_PHONE = "Phone";
    public static final String KEY_LOCMODE = "LocMode";
    public static final String KEY_ISNEEDLBS = "isNeedLBS";
    public static final String KEY_START_TIME = "beginTime";
    public static final String KEY_END_TIME = "endTime";
    private static final String KEY_SPEED = "Speed";

    private static ServiceInterface serviceInterface = new ServiceInterface();
    private static Map<String, String> map = new HashMap<>();//key=imei，value=pisition=====绑定设备位置的字符串表示形式



    private static List<FuncPhoneView> deviceList = new ArrayList<>();
    private static List<FuncBasicPosView> devicePositionList = new ArrayList<>();
    private static List<FuncFamNumView> deviceFamNumList = new ArrayList<>();


    private static FuncCurPosView funcCurPosView =  new FuncCurPosView();

    private static List<FuncHistPosView>  funcHistPosView = new ArrayList<>();

    public static List<FuncPhoneView> getDeviceList() {
        return deviceList;
    }

    public static List<FuncBasicPosView> getDevicePositionList() {
        return devicePositionList;
    }

    public static FuncCurPosView getFuncCurPosView() {
        return funcCurPosView;
    }
    public static Map<String, String> getMap() {
        return map;
    }

    public static void setMap(Map<String, String> map) {
        DevicesService.map = map;
    }

    public static List<FuncFamNumView> getDeviceFamNumList() {
        return deviceFamNumList;
    }

    public static List<FuncHistPosView> getHistoryPosition() {
        return funcHistPosView;
    }

    /**
     *  @author henmory
     *  @date 12/30/16
     *  @description    添加设备
     *
     *  @param
     *
     *  @return
    */

    // TODO: 12/30/16 没有完成
    public void addBindDevice(Context context, final String userAccount,String userTele, String code,
                              final SuccessCallback successCallback, final FailCallback failCallback) {
        serviceInterface.addBindDevice(context, userAccount, userTele, code, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {

            }
        });
    }

    private static void paraseDeviceList(Object object){
        JSONArray jsonArray = (JSONArray) object;
        FuncPhoneView funcPhoneView = null;
        JSONObject jsonObject;
        for (int i = 0; i < jsonArray.length(); i++){
            try {
                jsonObject = (JSONObject) jsonArray.get(i);
                funcPhoneView = new FuncPhoneView();
                funcPhoneView.setType(jsonObject.getInt(DevicesService.KEY_TYPE));
                funcPhoneView.setId(jsonObject.getLong(DevicesService.KEY_ID));
                funcPhoneView.setImei(jsonObject.getString(DevicesService.KEY_IMEI));
                String nickName = jsonObject.getString(DevicesService.KEY_NICK);
                if (TextUtils.isEmpty(nickName)){
                    funcPhoneView.setNick("设备" + i);
                }else{
                    funcPhoneView.setNick(nickName);
                }

                deviceList.add(funcPhoneView);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        Log.d(TAG, "paraseDeviceList: deviceList = " + deviceList.toString());

    }
    private static void paraseMultipleDevicePositionList(Object object){
        JSONArray jsonArray = (JSONArray) object;
        FuncBasicPosView fun = null;
        JSONObject jsonObject;
        for (int i = 0; i < jsonArray.length(); i++){
            try {
                fun = new FuncBasicPosView();
                jsonObject = (JSONObject) jsonArray.get(i);
                fun.setLat(jsonObject.getDouble(DevicesService.KEY_LAT));
                fun.setId(jsonObject.getLong(DevicesService.KEY_DEVID));
                fun.setLng(jsonObject.getDouble(DevicesService.KEY_LNG));
                fun.setGpsTime(jsonObject.getString(DevicesService.KEY_GPS_TIME));
                fun.setStatus(jsonObject.getInt(DevicesService.KEY_STATUS));
                devicePositionList.add(fun);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        Log.d(TAG, "parasePositionList: devicePositionList = " + devicePositionList.toString());
    }

    /**
     *  @author henmory
     *  @date 6/21/17
     *  @description 进入app后初始化数据
     *
     *  @param
     *
     *  @return
    */
    public static void initDeviceDatas(final Context context, final String token,
                                       final SuccessCallback successCallback, final FailCallback failCallback){

        // get device list
        getDeviceList(context, token, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {

                //get device position list
                getBindDevicesPositionList(context, token, 1 + "", new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        if (null != successCallback){
                            successCallback.onSuccess(null);
                        }
                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        if (null != failCallback){
                            failCallback.onFail(object);
                        }
                    }
                });
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (null != failCallback){
                    failCallback.onFail(object);
                }
            }
        });

    }

    /**
     *  @author henmory
     *  @date 6/21/17
     *  @description 获取设备列表
     *
     *  @param
     *
     *  @return
    */

    public static void getDeviceList(Context context, String token,
                                     final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.getDeviceList(context, token, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(TAG, "getDeviceList: " + object.toString());
                JSONObject jsonObject = (JSONObject) object;
                try {
                    int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                    if (retCode == 0) {//success---code
                        JSONArray jsonArray = jsonObject.getJSONArray(ServerConfig.KEY_DATA);
                        deviceList.clear();
                        paraseDeviceList(jsonArray);
                        if (null != successCallback) {
                            successCallback.onSuccess(null);
                        }
                    } else {
                        if (null != failCallback) {
                            failCallback.onFail(retCode);
                        }
                    }
                } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                    e.printStackTrace();
                    if (null != failCallback) {
                        failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                    }
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d(TAG, "getDeviceList: failed" + object.toString());
                if (null != failCallback) {
                    failCallback.onFail(object);
                }
            }
        });
    }


    /**
     *  @author henmory
     *  @date 12/26/16
     *  @description 获取设备列表，所有设备的所有信息
     *
     *  @param  successCallback 成功后回调
     *          failCallback 失败后回调
     *
     *  @return
     */
    public static void getBindDevicesPositionList(Context context, String token, String isNeedChangePoint,
                                                  final SuccessCallback successCallback, final FailCallback failCallback) {
        //获取绑定设备列表
        serviceInterface.getBindDevicesPositionList(context, token, isNeedChangePoint, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(TAG, "getBindDevicesPositionList: " + object.toString());
                JSONObject jsonObject = (JSONObject) object;
                try {
                    int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                    if (retCode == 0) {//success---code
                        JSONArray jsonArray = jsonObject.getJSONArray(ServerConfig.KEY_DATA);
                        devicePositionList.clear();
                        paraseMultipleDevicePositionList(jsonArray);
                        if (null != successCallback) {
                            successCallback.onSuccess(null);
                        }

                    } else {
                        if (null != failCallback) {
                            failCallback.onFail(retCode);
                        }
                    }
                } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                    e.printStackTrace();
                    if (null != failCallback) {
                        failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                    }
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d(TAG, "getBindDevicesPositionList: failed" + object.toString());
                if (null != failCallback) {
                    failCallback.onFail(object);
                }
            }
        });
    }

    private static void paraseSinglePosition(Object object){
        JSONObject jsonObject = (JSONObject) object;
        try {
            funcCurPosView.setLat(jsonObject.getDouble(DevicesService.KEY_LAT));
            funcCurPosView.setAlarm(jsonObject.getString(DevicesService.KEY_ALARM));
            funcCurPosView.setDeviceId(jsonObject.getLong(DevicesService.KEY_DEVID));
            funcCurPosView.setGpsTime(jsonObject.getString(DevicesService.KEY_GPS_TIME));
            funcCurPosView.setGsm(jsonObject.getInt(DevicesService.KEY_GSM));
            funcCurPosView.setPointed(jsonObject.getInt(DevicesService.KEY_POINTED));
            funcCurPosView.setPower(jsonObject.getInt(DevicesService.KEY_POWER));
            funcCurPosView.setLng(jsonObject.getLong(DevicesService.KEY_LNG));
            funcCurPosView.setSatelliteNum(jsonObject.getInt(DevicesService.KEY_SATELLITENUM));
            funcCurPosView.setStatus(jsonObject.getInt(DevicesService.KEY_STATUS));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.d(TAG, "paraseSinglePosition: funcCurPosView = " + funcCurPosView.toString());
    }
    /**
     *  @author henmory
     *  @date 12/26/16
     *  @description 获取设备列表，所有设备的所有信息
     *
     *  @param  successCallback 成功后回调
     *          failCallback 失败后回调
     *
     *  @return
     */
    public static void getSingleBindDevicePosition(Context context, String token, String deviceId,
                                                  final SuccessCallback successCallback, final FailCallback failCallback) {
        //获取绑定设备列表
        serviceInterface.getSingleBindDevicePosition(context, token, deviceId, 1+"",
                new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(TAG, "getSingleBindDevicePosition: " + object.toString());
                JSONObject jsonObject = (JSONObject) object;
                try {
                    int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                    if (retCode == 0) {//success---code
                        JSONObject jsonObject1 = jsonObject.getJSONObject(ServerConfig.KEY_DATA);
                        devicePositionList.clear();
                        paraseSinglePosition(jsonObject1);
                        if (null != successCallback) {
                            successCallback.onSuccess(null);
                        }

                    } else {
                        if (null != failCallback) {
                            failCallback.onFail(retCode);
                        }
                    }
                } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                    e.printStackTrace();
                    if (null != failCallback) {
                        failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                    }
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d(TAG, "getSingleBindDevicePosition: failed" + object.toString());
                if (null != failCallback) {
                    failCallback.onFail(object);
                }
            }
        });
    }

    private static void paraseFamilyNumList(Object object){
        JSONArray jsonArray = (JSONArray) object;
        FuncFamNumView fun = null;
        JSONObject jsonObject;

        for (int i = 0; i < jsonArray.length(); i++){
            try {
                jsonObject = (JSONObject) jsonArray.get(i);
                fun = new FuncFamNumView();
                fun.setDevID(jsonObject.getLong(DevicesService.KEY_DEVID));
                fun.setName(jsonObject.getString(DevicesService.KEY_NAME));
                fun.setPhone(jsonObject.getString(DevicesService.KEY_PHONE));
                fun.setSeq(jsonObject.getInt(DevicesService.KEY_SEQ));
                deviceFamNumList.add(fun);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        Log.d(TAG, "paraseFamilyNumListtionList: deviceFamNumList = " + deviceFamNumList.toString());
    }

    public static void getFamilyNumberList(Context context, String token, String deviceId,
                                                   final SuccessCallback successCallback, final FailCallback failCallback) {
        //获取绑定设备列表
        serviceInterface.getFamilyNumberList(context, token, deviceId,
                new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        Log.d(TAG, "getFamilyNumberList: " + object.toString());
                        JSONObject jsonObject = (JSONObject) object;
                        try {
                            int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                            if (retCode == 0) {//success---code
                                JSONArray jsonArray = jsonObject.getJSONArray(ServerConfig.KEY_DATA);
                                deviceFamNumList.clear();
                                paraseFamilyNumList(jsonArray);
                                if (null != successCallback) {
                                    successCallback.onSuccess(null);
                                }

                            } else {
                                if (null != failCallback) {
                                    failCallback.onFail(retCode);
                                }
                            }
                        } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                            e.printStackTrace();
                            if (null != failCallback) {
                                failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                            }
                        }
                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        Log.d(TAG, "getFamilyNumberList: failed" + object.toString());
                        if (null != failCallback) {
                            failCallback.onFail(object);
                        }
                    }
                });
    }


    public static void addFamilyNumber(Context context, String token, FuncFamNumView funcFamNumView,
                                           final SuccessCallback successCallback, final FailCallback failCallback) {
        //获取绑定设备列表
        serviceInterface.addFamilyNumber(context, token, funcFamNumView,
                new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        Log.d(TAG, "addFamilyNumber: " + object.toString());
                        JSONObject jsonObject = (JSONObject) object;
                        try {
                            int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                            if (retCode == 0) {//success---code
                                if (null != successCallback) {
                                    successCallback.onSuccess(null);
                                }

                            } else {
                                if (null != failCallback) {
                                    failCallback.onFail(retCode);
                                }
                            }
                        } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                            e.printStackTrace();
                            if (null != failCallback) {
                                failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                            }
                        }
                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        Log.d(TAG, "addFamilyNumber: failed" + object.toString());
                        if (null != failCallback) {
                            failCallback.onFail(object);
                        }
                    }
                });
    }

    //获取亲情号码
    public static void deleteFamilyNumber(Context context, String token, String devId, int seq,
                                   final SuccessCallback successCallback, final FailCallback failCallback) {
        //获取绑定设备列表
        serviceInterface.deleteFamilyNumber(context, token, devId, seq,
                new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        Log.d(TAG, "deleteFamilyNumber: " + object.toString());
                        JSONObject jsonObject = (JSONObject) object;
                        try {
                            int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                            if (retCode == 0) {//success---code
                                if (null != successCallback) {
                                    successCallback.onSuccess(null);
                                }

                            } else {
                                if (null != failCallback) {
                                    failCallback.onFail(retCode);
                                }
                            }
                        } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                            e.printStackTrace();
                            if (null != failCallback) {
                                failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                            }
                        }
                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        Log.d(TAG, "deleteFamilyNumber: failed" + object.toString());
                        if (null != failCallback) {
                            failCallback.onFail(object);
                        }
                    }
                });
    }

    public static void updateDeviceNickname(Context context, String token, NickSetParam nickSetParam,
                                            final SuccessCallback successCallback, final FailCallback failCallback) {
        //获取绑定设备列表
        serviceInterface.updateDeviceNickname(context, token, nickSetParam,
                new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        Log.d(TAG, "updateDeviceNickname: " + object.toString());
                        JSONObject jsonObject = (JSONObject) object;
                        try {
                            int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                            if (retCode == 0) {//success---code
                                if (null != successCallback) {
                                    successCallback.onSuccess(null);
                                }

                            } else {
                                if (null != failCallback) {
                                    failCallback.onFail(retCode);
                                }
                            }
                        } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                            e.printStackTrace();
                            if (null != failCallback) {
                                failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                            }
                        }
                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        Log.d(TAG, "updateDeviceNickname: failed" + object.toString());
                        if (null != failCallback) {
                            failCallback.onFail(object);
                        }
                    }
                });
    }



    public static void getLocationPosition(Context context, String token, String deviceId,
                                           final SuccessCallback successCallback, final FailCallback failCallback) {
        serviceInterface.getLocationMode(context, token, deviceId,
                new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        Log.d(TAG, "getLocationPosition: " + object.toString());
                        JSONObject jsonObject = (JSONObject) object;
                        try {
                            int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                            if (retCode == 0) {//success---code
                                int mode = jsonObject.getInt(ServerConfig.KEY_DATA);
                                if (null != successCallback) {
                                    successCallback.onSuccess(mode);
                                }

                            } else {
                                if (null != failCallback) {
                                    failCallback.onFail(retCode);
                                }
                            }
                        } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                            e.printStackTrace();
                            if (null != failCallback) {
                                failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                            }
                        }
                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        Log.d(TAG, "getLocationPosition: failed" + object.toString());
                        if (null != failCallback) {
                            failCallback.onFail(object);
                        }
                    }
                });
    }


    public static void setLocationPosition(Context context, String token, LocModePara locModePara,
                                       final SuccessCallback successCallback, final FailCallback failCallback) {
        //获取绑定设备列表
        serviceInterface.setLocationMode(context, token, locModePara,
                new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        Log.d(TAG, "setLocationPosition: " + object.toString());
                        JSONObject jsonObject = (JSONObject) object;
                        try {
                            int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                            if (retCode == 0) {//success---code
                                if (null != successCallback) {
                                    successCallback.onSuccess(null);
                                }

                            } else {
                                if (null != failCallback) {
                                    failCallback.onFail(retCode);
                                }
                            }
                        } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                            e.printStackTrace();
                            if (null != failCallback) {
                                failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                            }
                        }
                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        Log.d(TAG, "setLocationPosition: failed" + object.toString());
                        if (null != failCallback) {
                            failCallback.onFail(object);
                        }
                    }
                });
    }

    private static void parseHistoryPositions(Object object){

        JSONArray jsonArray = (JSONArray) object;
        FuncHistPosView tmp  = null;
        JSONObject jsonObject;
        for (int i = 0; i < jsonArray.length(); i++){
            try {
                jsonObject = (JSONObject) jsonArray.get(i);
                tmp = new FuncHistPosView();
                tmp.setLat(jsonObject.getDouble(DevicesService.KEY_LAT));
                tmp.setAlarm(jsonObject.getString(DevicesService.KEY_ALARM));
//                tmp.setDeviceId(jsonObject.getLong(DevicesService.KEY_DEVID));
                tmp.setGpsTime(jsonObject.getString(DevicesService.KEY_GPS_TIME));
                tmp.setGsm(jsonObject.getInt(DevicesService.KEY_GSM));
                tmp.setPointed(jsonObject.getInt(DevicesService.KEY_POINTED));
                tmp.setPower(jsonObject.getInt(DevicesService.KEY_POWER));
                tmp.setLng(jsonObject.getLong(DevicesService.KEY_LNG));
                tmp.setSatelliteNum(jsonObject.getInt(DevicesService.KEY_SATELLITENUM));
//                tmp.setStatus(jsonObject.getInt(DevicesService.KEY_STATUS));
                tmp.setSpeed(jsonObject.getInt(DevicesService.KEY_SPEED));
                funcHistPosView.add(tmp);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        Log.d(TAG, "paraseDeviceList: funcHistPosView = " + funcHistPosView.toString());

    }

    public static void getDeviceHistoryTrace(Context context, String token,  String deviceID,int isNeedLBS,
                                                 String startTime, String endTime,
                                                 final SuccessCallback successCallback, final FailCallback failCallback){

        serviceInterface.getDeviceHistoryTrace(context, token, deviceID, isNeedLBS,
                startTime, endTime,  new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        Log.d(TAG, "getDeviceHistoryTrace: " + object.toString());
                        JSONObject jsonObject = (JSONObject) object;
                        try {
                            int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                            if (retCode == 0) {//success---code
                                JSONArray jsonArray = jsonObject.getJSONArray(ServerConfig.KEY_DATA);
                                funcHistPosView.clear();
                                parseHistoryPositions(jsonArray);
                                if (null != successCallback) {
                                    successCallback.onSuccess(null);
                                }

                            } else {
                                if (null != failCallback) {
                                    failCallback.onFail(retCode);
                                }
                            }
                        } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                            e.printStackTrace();
                            if (null != failCallback) {
                                failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                            }
                        }
                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        if (failCallback != null){
                            Log.d(TAG, "failed " + object.toString());
                            failCallback.onFail(object);
                        }
                    }
                });

    }


    /**
     *  @author henmory
     *  @date 12/30/16
     *  @description    删除设备
     *
     *  @param
     *
     *  @return
     */
    public static void deleteBindDevice(Context context, final String token, String id,
                                        final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.deleteBindDevice(context, token, id, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(TAG, "deleteBindDevice: " + object.toString());
                JSONObject jsonObject = (JSONObject) object;
                try {
                    int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                    if (retCode == 0) {//success---code
                        if (null != successCallback) {
                            successCallback.onSuccess(null);
                        }

                    } else {
                        if (null != failCallback) {
                            failCallback.onFail(retCode);
                        }
                    }
                } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                    e.printStackTrace();
                    if (null != failCallback) {
                        failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                    }
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (failCallback != null){
                    Log.d(TAG, "failed " + object.toString());
                    failCallback.onFail(object);
                }
            }
        });

    }



}
