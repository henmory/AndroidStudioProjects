package com.changhong.changhongcare.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.adapter.PayDetailItem;
import com.changhong.changhongcare.adapter.PayDetailItemAdapter;
import com.changhong.changhongcare.adapter.SettingItem;
import com.changhong.changhongcare.adapter.SettingItemAdapter;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.newprotocol.service.PayService;
import com.changhong.changhongcare.pay.alipay.struct.PayFlowView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TopUpDetailsActivity extends AppCompatActivity {

    private static String TAG = "TopUpDetailsActivity";
    private ListView listView;
    private PayDetailItemAdapter adapter;
    private List<PayDetailItem> payItems = new ArrayList<>();

    private CustomProgressDialog customProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_up_details);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listView = (ListView) findViewById(R.id.lv_top_up_item);
        customProgressDialog = new CustomProgressDialog(this);
        customProgressDialog.setMessage("数据获取中...");
        customProgressDialog.show();

        PayService.getPayDetails(this, Config.token, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                List<PayDetailItem> payDetailItems = new ArrayList<PayDetailItem>();
                PayDetailItem payDetailItem = new PayDetailItem();
                JSONArray jsonArray = (JSONArray)object;
                for (int i = 0; i < jsonArray.length(); i++){
                    JSONObject jsonObject = null;
                    try {
                        jsonObject = (JSONObject) jsonArray.get(i);
                        Log.d(TAG, "onSuccess: " + jsonObject.toString());
                        payDetailItem.setAmount(jsonObject.getDouble(PayService.KEY_AMOUNT));
                        payDetailItem.setFlowNo(jsonObject.getString(PayService.KEY_FLOWNO));
                        payDetailItem.setPayMethord(jsonObject.getString(PayService.KEY_METHORD));
                        payDetailItem.setPayStatus(jsonObject.getInt(PayService.KEY_PAYSTATUS));
                        payDetailItem.setServiceTime(jsonObject.getInt(PayService.KEY_SERVICETIME));
                        payDetailItems.add(payDetailItem);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
                adapter = new PayDetailItemAdapter(payDetailItems, TopUpDetailsActivity.this, R.layout.list_item_pay_detail);
                listView.setAdapter(adapter);
                customProgressDialog.dismiss();
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                int ret = (int)object;
                customProgressDialog.dismiss();
                if (-2 == ret){
                    Toast.makeText(TopUpDetailsActivity.this,"请重新登陆", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(TopUpDetailsActivity.this,"获取数据失败,稍后重试", Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        });




    }

}
