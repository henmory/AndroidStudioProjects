package com.changhong.changhongcare.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.changhong.changhongcare.R;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.customview.CustomMembershipDialog;
import com.changhong.changhongcare.customview.CustomProgressDialog;

import java.util.Calendar;

import static com.changhong.changhongcare.R.id.btn_open_member;

public class MyWalletActivity extends AppCompatActivity {
    private final static String TAG = "MyWalletActivity";

    private TextView tv_detail;//充值明细
    private TextView tv_deadline;//免费日期(从绑定成功后，由服务器确定时间，客户端从服务器获取)
    private LinearLayout linearLayout;//免费日期到后，删除免费提示控件
    private Button btnTopUp;//续费

    private String deadline;
    private Handler handler;
    private static final int MSG_TIP_USER = 0;

    private CustomProgressDialog customProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_wallet);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case MSG_TIP_USER://点击退出当前账号，销毁amap activity
                        tipUser();
                }
            }
        };

        bindViews();
        initDatas();
        bindEvents();


    }
   /**

    * **/
    private void bindViews(){
        tv_detail = (TextView) findViewById(R.id.tv_detail);
        tv_deadline = (TextView) findViewById(R.id.tv_deadline);
        btnTopUp = (Button) findViewById(btn_open_member);
        customProgressDialog = new CustomProgressDialog(this);
//        linearLayout = (LinearLayout) findViewById(R.id.ll_deadline);
//        mViewPager = (ViewPager)findViewById(R.id.viewpager);
//        rb1 = (RadioButton) findViewById(R.id.rb_1);
//        rb2 = (RadioButton) findViewById(R.id.rb_2);
//        rb3 = (RadioButton) findViewById(R.id.rb_3);
//
//
//        //将要分页显示的View装入数组中
//        LayoutInflater mLi = LayoutInflater.from(this);
//        View view1 = mLi.inflate(R.layout.content_boot_1, null);
//        View view2 = mLi.inflate(R.layout.content_boot_2, null);
//        View view3 = mLi.inflate(R.layout.content_boot_1, null);
//
//        //每个页面的数据
//        final ArrayList<View> views = new ArrayList<View>();
//        views.add(view1);
//        views.add(view2);
//        views.add(view3);
//
//        //填充ViewPager的数据适配器
//        PagerAdapter mPagerAdapter = new PagerAdapter() {
//
//            @Override
//            public boolean isViewFromObject(View arg0, Object arg1) {
//                return arg0 == arg1;
//            }
//
//            @Override
//            public int getCount() {
//                return views.size();
//            }
//
//            @Override
//            public void destroyItem(ViewGroup container, int position, Object object) {
//                ((ViewPager)container).removeView(views.get(position));
//            }
//
//            //                @Override
////                public CharSequence getPageTitle(int position) {
////                    return titles.get(position);
////                }
//            @Override
//            public Object instantiateItem(ViewGroup container, int position) {
//                ((ViewPager)container).addView(views.get(position));
//                return views.get(position);
//            }
//        };
//        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
//            @Override
//            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
//
//            }
//
//            @Override
//            public void onPageSelected(int position) {
//                page_position = position;
//                if (page_position == 0){
//                    rb1.setChecked(true);
//                    rb2.setChecked(false);
//                    rb3.setChecked(false);
//                }else if(1 == page_position){
//                    rb2.setChecked(true);
//                    rb1.setChecked(false);
//                    rb3.setChecked(false);
//                }else if(2 == page_position){
//                    rb3.setChecked(true);
//                    rb1.setChecked(false);
//                    rb2.setChecked(false);
//                }else{
//                    rb1.setChecked(true);
//                    rb2.setChecked(false);
//                    rb3.setChecked(false);
//                }
//            }
//
//            @Override
//            public void onPageScrollStateChanged(int state) {
//
//            }
//        });
//        mViewPager.setAdapter(mPagerAdapter);
//        mViewPager.setCurrentItem(1);
    }

    private void initDatas() {

        customProgressDialog.setMessage("数据加载中...");
        deadline = Config.deadLine;
        int tem = deadline.indexOf(' ');
        deadline = deadline.substring(0, tem);
        Log.d(TAG, "initDatas: deadline = " + deadline);
        tv_deadline.setText(deadline);

        Calendar c = Calendar.getInstance();
        int sys_year = c.get(Calendar.YEAR);
        int sys_month = c.get(Calendar.MONTH) + 1;
        int sys_day = c.get(Calendar.DAY_OF_MONTH);
        String sys_time = new String(sys_year + "-");

        if (sys_month < 10) {
            sys_time += ("0" + sys_month + "-");
        } else {
            sys_time += (sys_month + "-");
        }
        if (sys_day < 10) {
            sys_time += ("0" + sys_day);
        } else {
            sys_time += (sys_day);
        }
        Log.d(TAG, "initDatas: sys_time = " + sys_time);
        sys_time = "2017-10-20";
        if (deadline.compareTo(sys_time) > 0) {

        } else {

            Message message = Message.obtain();
            message.what = MSG_TIP_USER;
            message.setTarget(handler);
            handler.sendMessage(message);


//        rb1.setChecked(true);
//        rb2.setChecked(false);
//        rb3.setChecked(false);
        }
    }

    private void bindEvents(){
        //top up details
        tv_detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MyWalletActivity.this, TopUpDetailsActivity.class));
            }
        });
        btnTopUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MyWalletActivity.this,TopUpActivity.class));
            }
        });
    }

    private void tipUser(){
        final CustomMembershipDialog customMembershipDialog = new CustomMembershipDialog(this, R.layout.custom_dialog_membership_tip_2);
        customMembershipDialog.setTitle("会员福利");

        customMembershipDialog.setOnNegativeListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customMembershipDialog.dismiss();
            }
        });
        customMembershipDialog.setOnPositiveListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customMembershipDialog.dismiss();
            }
        });
        customMembershipDialog.show();
    }

}
