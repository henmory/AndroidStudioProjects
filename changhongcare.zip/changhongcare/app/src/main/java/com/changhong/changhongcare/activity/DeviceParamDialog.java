package com.changhong.changhongcare.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.customview.CustomAskUserDialog;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.newprotocol.service.DevicesService;
import com.changhong.changhongcare.newprotocol.structfromserver.FuncBasicPosView;
import com.changhong.changhongcare.newprotocol.structfromserver.FuncCurPosView;
import com.changhong.changhongcare.newprotocol.structfromserver.FuncPhoneView;
import com.changhong.changhongcare.utils.DisplayUtil;

import java.security.PrivateKey;
import java.util.List;
import java.util.Map;

/**
 * author: henmory
 * time:  12/6/16
 * function:
 * description: 设备详细参数对话框
 */

public class DeviceParamDialog extends Dialog {

    private final static String TAG = "DeviceParamDialog";
    private final static double HEIGHT_OF_PROPIRATION = 0.5;
    private final static int WIDTH = WindowManager.LayoutParams.MATCH_PARENT;
    private ImageView ivSaliteNum;//卫星数量
    private TextView tvSpeed;//速度
    private TextView tvDeviceName;//设备名称
    private TextView tvOnlineTime;//上次在线时间
    private TextView tvPosition;//设备位置
    private ImageView ivSingle;//信号强度
    private ImageView ivBattery;//电池图标
    private TextView tvBattery;//电池百分比
    private String deviceID;//设备的id

    private LinearLayout changeName;
    private LinearLayout footTrace;
    private LinearLayout familyNum;
    private LinearLayout positionMode;
    private LinearLayout deleteDevice;

    private CustomProgressDialog customProgressDialog;
    private Context context;
    //////////////////////////////////////业务相关//////////////////////////////////////////////////////////////

    public DeviceParamDialog(Context context, String deviceID) {

        //给dialog定制了一个主题（透明背景，无边框，无标题栏，浮在Activity上面，模糊）
        super(context, R.style.custom_bottom_dialog);
        setContentView(R.layout.bottom_dialog_device_param);
        initWindowParams(context);
        initViews();
        bindEvents();
        initDatas(deviceID);
        this.deviceID = deviceID;
    }

    //设置dialog参数
    private void initWindowParams(Context context) {
        this.context = context;
        //点击空白区域可以取消dialog
        this.setCanceledOnTouchOutside(true);
        //点击back键可以取消dialog
        this.setCancelable(true);
        Window window = this.getWindow();
        //让Dialog显示在屏幕的底部
        window.setGravity(Gravity.BOTTOM);
        //设置窗口出现和窗口隐藏的动画
        window.setWindowAnimations(R.style.custom_bottom_dialog_anim);
        //设置BottomDialog的宽高属性
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.width = WIDTH;
        lp.height = (int) (DisplayUtil.getDeviceHeight(context) * HEIGHT_OF_PROPIRATION);
        window.setAttributes(lp);
    }

    private void initViews() {
        changeName = (LinearLayout) findViewById(R.id.change_device_name);
        footTrace = (LinearLayout) findViewById(R.id.ll_foot_trace);
        familyNum = (LinearLayout) findViewById(R.id.ll_family_num);
        positionMode = (LinearLayout) findViewById(R.id.ll_position_mode);
        deleteDevice = (LinearLayout) findViewById(R.id.ll_delete_device);
        ivSaliteNum = (ImageView) findViewById(R.id.iv_satellite_num);
        tvSpeed = (TextView) findViewById(R.id.tv_walk_speed);
        tvDeviceName = (TextView) findViewById(R.id.tv_binde_device_name);
        tvOnlineTime = (TextView) findViewById(R.id.tv_time);
        tvPosition = (TextView) findViewById(R.id.tv_position_location);
        ivSingle = (ImageView) findViewById(R.id.iv_bind_device_single);
        ivBattery = (ImageView) findViewById(R.id.iv_bind_device_power);
        tvBattery = (TextView) findViewById(R.id.tv_bind_device_power);
        customProgressDialog = new CustomProgressDialog(context);

    }

    private void bindEvents() {
        footTrace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "足迹踏寻");
                Intent intent = new Intent();
                intent.setAction("android.intent.action.FOOTTRACE");
                intent.putExtra(Config.KEY_DEVICE_ID, deviceID);
                v.getContext().startActivity(intent);
                dismiss();
            }
        });
        familyNum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "亲情号码");
                Intent intent = new Intent();
                intent.setAction("android.intent.action.FAMILYNUMBERSETTING");
                intent.putExtra(Config.KEY_DEVICE_ID, deviceID);
                v.getContext().startActivity(intent);
                dismiss();

            }
        });

        positionMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "定位模式");
                Intent intent = new Intent();
                intent.setAction("android.intent.action.POSITIONMODE");
                intent.putExtra(Config.KEY_DEVICE_ID, deviceID);
                v.getContext().startActivity(intent);
                dismiss();

            }
        });
        deleteDevice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "删除设备");
                final CustomAskUserDialog dialog = new CustomAskUserDialog(v.getContext());
                dialog.setCanceledOnTouchOutside(false);
                dialog.setCancelable(true);
                dialog.setContent("确定删除设备?");
                dialog.setOnNegativeListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                dialog.setOnPositiveListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        System.out.println("sure");
                        dialog.dismiss();
                        deleteDevice(v.getContext());
                    }
                });
                dialog.show();

            }
        });

        changeName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "更改设备名称");
                Intent intent = new Intent();
                intent.setAction("android.intent.action.DEVICENAMEMODIFY");
                intent.putExtra(Config.KEY_DEVICE_ID, deviceID);
                v.getContext().startActivity(intent);
                dismiss();
            }
        });


    }

    //删除设备
    public  void deleteDevice(final Context context) {
        //根据imei删除设备
        String imei = null;
        List<FuncBasicPosView> deviceBasicInfos = DevicesService.getDevicePositionList();
        List<FuncPhoneView> funcPhoneViewList = DevicesService.getDeviceList();
        for (int i = 0; i < funcPhoneViewList.size(); i++) {
            if (deviceID.equals(funcPhoneViewList.get(i).getId())) {
                imei = funcPhoneViewList.get(i).getImei();
                break;
            }
        }
        Log.d(TAG, "delete device imei = " + imei);

        if (null != imei) {
            DevicesService.deleteBindDevice(context, Config.phoneNumber, imei, new SuccessCallback() {
                @Override
                public void onSuccess(Object object) {
                    Toast.makeText(context, "删除设备成功", Toast.LENGTH_SHORT).show();
                    dismiss();
                    AmapActivity.mInstace.sendUpdateAmapMessage();

                }
            }, new FailCallback() {
                @Override
                public void onFail(Object object) {
                    Toast.makeText(context, " 删除设备失败", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Toast.makeText(context, " 删除设备失败", Toast.LENGTH_SHORT).show();
        }

    }

    //////////////////////////////////////业务相关////////////////////////////////////////////////////////////////

    //根据imei显示不同设备的信息
    private void initDatas(String deviceID) {
        customProgressDialog.setMessage("数据加载中，请稍后...");
        customProgressDialog.show();

        DevicesService.getSingleBindDevicePosition(getContext(), Config.token, deviceID, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                initViewsContent();
                customProgressDialog.dismiss();
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                customProgressDialog.dismiss();
                Toast.makeText(context, " 获取数据失败", Toast.LENGTH_SHORT).show();
            }
        });


//        List<FuncBasicPosView> deviceBasicPositionInfoList = DevicesService.getDevicePositionList();
//        Map<String, String> map = DevicesService.getMap();
//        Log.d(TAG, map.toString());
//        for (int i = 0; i < deviceBasicPositionInfoList.size(); i++) {
//            device = deviceBasicPositionInfoList.get(i);
//            if (deviceID.equals(device.getDeviceID())) {
//                int speed = device.getSpeed();
//                tvSpeed.setText(Integer.toString(speed) + "km/h");
//                if (null != device.getNickName()) {
//                    tvDeviceName.setText(device.getNickName());
//                } else {
//                    tvDeviceName.setText(device.getDeviceName());
//                }
//                tvOnlineTime.setText(device.getGpsTime());
//                tvPosition.setText(map.get(device.getDeviceIMEI()));
//                switch (device.getGsm()) {//信号强度
//                    case 1:
//                        ivSingle.setImageResource(R.drawable.single_1);
//                        break;
//                    case 2:
//                        ivSingle.setImageResource(R.drawable.single_2);
//                        break;
//                    case 3:
//                        ivSingle.setImageResource(R.drawable.single_3);
//                        break;
//                    case 4:
//                        ivSingle.setImageResource(R.drawable.single_4);
//                        break;
//                    case 5:
//                        ivSingle.setImageResource(R.drawable.single_5);
//                        break;
//                    case 6:
//                        ivSingle.setImageResource(R.drawable.single_5);
//                        break;
//                }
//                int power = device.getPower();
//                if (power < 30) {
//                    ivBattery.setImageResource(R.drawable.battery_low);
//                } else if (power > 80) {
//                    ivBattery.setImageResource(R.drawable.battery_high);
//                } else {
//                    ivBattery.setImageResource(R.drawable.battery_middle);
//                }
//                tvBattery.setText(power + "" + "%");
//            }
//        }
    }

    private void initViewsContent() {
        FuncCurPosView funcCurPosView = DevicesService.getFuncCurPosView();
        List<FuncPhoneView> funcPhoneView = DevicesService.getDeviceList();
        Log.d(TAG, "initViewsContent: deviceID = " + deviceID);

        for (int i = 0; i < funcPhoneView.size(); i++) {
            if (deviceID.equals(funcPhoneView.get(i).getId()+"")) {
                if (null != funcPhoneView.get(i).getNick()) {
                    tvDeviceName.setText(funcPhoneView.get(i).getNick());
                } else {
                    tvDeviceName.setText(funcPhoneView.get(i).getId()+"");
                }
            }
        }
//            tvSpeed.setText(funcCurPosView + "km/h");

        tvOnlineTime.setText(funcCurPosView.getGpsTime());
        Map<String, String> map = DevicesService.getMap();
        tvPosition.setText(map.get(deviceID));
        switch (funcCurPosView.getGsm()) {//信号强度
            case 1:
                ivSingle.setImageResource(R.drawable.single_1);
                break;
            case 2:
                ivSingle.setImageResource(R.drawable.single_2);
                break;
            case 3:
                ivSingle.setImageResource(R.drawable.single_3);
                break;
            case 4:
                ivSingle.setImageResource(R.drawable.single_4);
                break;
            case 5:
                ivSingle.setImageResource(R.drawable.single_5);
                break;
            case 6:
                ivSingle.setImageResource(R.drawable.single_5);
                break;
        }
        int power = funcCurPosView.getPower();
        if (power < 30) {
            ivBattery.setImageResource(R.drawable.battery_low);
        } else if (power > 80) {
            ivBattery.setImageResource(R.drawable.battery_high);
        } else {
            ivBattery.setImageResource(R.drawable.battery_middle);
        }
        tvBattery.setText(power + "" + "%");
    }


}
