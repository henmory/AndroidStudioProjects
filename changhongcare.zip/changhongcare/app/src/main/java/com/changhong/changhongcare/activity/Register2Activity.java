package com.changhong.changhongcare.activity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.customview.CustomUserInputCodeDialog;
import com.changhong.changhongcare.newprotocol.okhttp.ServerConfig;
import com.changhong.changhongcare.newprotocol.service.PersonService;
import com.changhong.changhongcare.utils.FormatTools;
import com.changhong.changhongcare.utils.Utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * 该注册界面是与设备绑定无关的，注册成功后，没有任何绑定设备，只是在后台有个空账号而已
 */
public class Register2Activity extends AppCompatActivity {

    private final static String tag = "Register2Activity";
    private EditText evPhoneNumber;
    private EditText evCode;
    private EditText evPassword;
    private EditText evConfirmPassword;
    private Button btnRegister;
    private Button btnGetCode;

    private CustomProgressDialog customProgressDialog;


    //new倒计时对象,总共的时间,每隔多少秒更新一次时间
    final MyCountDownTimer myCountDownTimer = new MyCountDownTimer(120000, 1000);

    private String num;//phone number
    private String code; // verification code
    private String password; // password that user inputs
    private String confirmPassword; //password that user inputs to verify

    private String sessionId;
    private String graphicCode = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register2);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        bindViews();
        bindEvents();

        initVerificationRequest();

    }

    private void bindViews() {
        customProgressDialog = new CustomProgressDialog(this);
        evPhoneNumber = (EditText) findViewById(R.id.et_phone_number);
        evCode = (EditText) findViewById(R.id.et_sms_code);
        evPassword = (EditText) findViewById(R.id.et_password);
        evConfirmPassword = (EditText) findViewById(R.id.et_confirm_password);
        btnRegister = (Button) findViewById(R.id.btn_register);
        btnGetCode = (Button) findViewById(R.id.btn_get_code);
    }

    private void bindEvents() {
        btnGetCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSMSCode();

            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerAccount();
            }
        });
    }


    private void initVerificationRequest() {

        customProgressDialog.setMessage("数据初始化中...");
        customProgressDialog.show();
        PersonService.initVerificationRequest(this, "", "", new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(tag, object.toString());
                sessionId = (String) object;
                customProgressDialog.dismiss();

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                //do nothing
                Toast.makeText(Register2Activity.this, "初始化数据失败,请检查一下网络，稍后重试", Toast.LENGTH_SHORT).show();
                customProgressDialog.dismiss();
                finish();
            }
        });
    }


    //get verification code
    private void getSMSCode() {
        //verify the phone number whether is correct
        num = evPhoneNumber.getText().toString();
        if (TextUtils.isEmpty(num)) {
            Toast.makeText(Register2Activity.this, "电话号码不能为空", Toast.LENGTH_SHORT).show();
        } else {
            if (!Utils.checkMobileNumber(num)) {
                Toast.makeText(Register2Activity.this, "手机号码格式不对", Toast.LENGTH_SHORT).show();
            } else {
                myCountDownTimer.start();
                getSMSVerificationCode();
            }
        }

    }

    //register an account
    private void registerAccount() {

        num = evPhoneNumber.getText().toString();
        password = evPassword.getText().toString();
        confirmPassword = evConfirmPassword.getText().toString();
        code = evCode.getText().toString();
        if (!Utils.checkMobileNumber(num)) {
            Toast.makeText(Register2Activity.this, "手机号码格式不对", Toast.LENGTH_SHORT).show();
        } else if (!password.equals(confirmPassword)) {
            Toast.makeText(Register2Activity.this, "两次密码输入不一致", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(code)) {
            Toast.makeText(Register2Activity.this, "验证码不能为空", Toast.LENGTH_SHORT).show();
        } else {
            customProgressDialog.setMessage("注册中...");
            customProgressDialog.show();

            PersonService.verifyVerificationCode(Register2Activity.this, num, 0+"",sessionId, code,
                    new SuccessCallback() {
                @Override
                public void onSuccess(Object object) {
                    register();
                }
            }, new FailCallback() {
                @Override
                public void onFail(Object object) {
                    Toast.makeText(Register2Activity.this, "验证码错误", Toast.LENGTH_SHORT).show();
                    customProgressDialog.dismiss();
                }
            });
        }
    }

    private void verifyCode() {

    }


    private void getSMSVerificationCode() {
        customProgressDialog.setMessage("验证码获取中...");
        customProgressDialog.show();

        PersonService.getSMSVerificationCode(Register2Activity.this, num, 0 + "", sessionId, graphicCode,
                new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        customProgressDialog.dismiss();
                        Toast.makeText(Register2Activity.this, "验证码发送成功", Toast.LENGTH_SHORT).show();
                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        int errorCode = (int) object;
                        if (errorCode == ServerConfig.OKHTTP_ERROR_CODE ||
                                errorCode == ServerConfig.NET_BUSY_ERROR_CODE ||
                                errorCode == ServerConfig.PARSE_DATA_FAILED_ERROR_CODE ||
                                errorCode == -5 ||
                                errorCode == -17) {
                            customProgressDialog.dismiss();
                            Toast.makeText(Register2Activity.this, "网络连接失败", Toast.LENGTH_SHORT).show();
                        } else if (errorCode == -8) {//graphic code that user input is wrong
                            customProgressDialog.dismiss();
                            Toast.makeText(Register2Activity.this, "验证码输入错误", Toast.LENGTH_SHORT).show();
//                    getImageVerificationCode();
                        } else if (errorCode == -24) {
                            Log.d(tag, errorCode + "");
//                    customProgressDialog.dismiss();
                            getImageVerificationCode();
                        }
                    }
                });
    }


    private void getImageVerificationCode() {
//        final CustomProgressDialog customProgressDialog = new CustomProgressDialog(Register2Activity.this, "验证码获取中...");
//        customProgressDialog.show();
        PersonService.getImageVerificationCode(Register2Activity.this, num, sessionId, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {

                //get the drawable of graphic code
                String fileName = (String) object;
                Drawable drawable = null;
                try {
                    drawable = FormatTools.getInstance().InputStream2Drawable(new FileInputStream(fileName));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

                customProgressDialog.dismiss();

                //show the dialog
                final CustomUserInputCodeDialog dialog = new CustomUserInputCodeDialog(Register2Activity.this, drawable);
                dialog.setCanceledOnTouchOutside(false);
                dialog.setCancelable(true);
                dialog.setOnNegativeListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        graphicCode = "";
                    }
                });
                dialog.setOnPositiveListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        graphicCode = dialog.getEditText();
                        Log.d(tag, "user input the code = " + graphicCode);
                        getSMSCode();
                    }
                });
                dialog.show();

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                customProgressDialog.dismiss();
                Toast.makeText(Register2Activity.this, object.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void register() {
        PersonService.register(Register2Activity.this, num, confirmPassword, Config.PwdMode, Config.ClientId, code,
                new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        customProgressDialog.dismiss();
                        finish();
                        Toast.makeText(Register2Activity.this, "注册成功，请登陆", Toast.LENGTH_SHORT).show();
                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        customProgressDialog.dismiss();
                        int retCode = (int) object;
                        if (-5 == retCode) {
                            Toast.makeText(Register2Activity.this, "非法参数", Toast.LENGTH_SHORT).show();
                        } else if (-8 == retCode) {
                            Toast.makeText(Register2Activity.this, "验证码错误", Toast.LENGTH_SHORT).show();
                        } else if (-17 == retCode) {
                            Toast.makeText(Register2Activity.this, "用户名已存在", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(Register2Activity.this, "注册失败", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


    //复写倒计时
    private class MyCountDownTimer extends CountDownTimer {

        public MyCountDownTimer(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        //计时过程
        @Override
        public void onTick(long l) {
            //防止计时过程中重复点击
            btnGetCode.setClickable(false);
            btnGetCode.setText(l / 1000 + "s");

        }

        //计时完毕的方法
        @Override
        public void onFinish() {
            //重新给Button设置文字
            btnGetCode.setText("重新获取验证码");
            //设置可点击
            btnGetCode.setClickable(true);
        }
    }

}
