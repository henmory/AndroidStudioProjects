package com.changhong.changhongcare.activity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.amap.api.maps2d.AMap;
import com.amap.api.maps2d.AMapOptions;
import com.amap.api.maps2d.CameraUpdateFactory;
import com.amap.api.maps2d.MapView;
import com.amap.api.maps2d.UiSettings;
import com.amap.api.maps2d.model.BitmapDescriptor;
import com.amap.api.maps2d.model.BitmapDescriptorFactory;
import com.amap.api.maps2d.model.LatLng;
import com.amap.api.maps2d.model.MarkerOptions;
import com.amap.api.maps2d.model.PolylineOptions;
import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.newprotocol.service.DevicesService;
import com.changhong.changhongcare.newprotocol.structfromserver.FuncHistPosView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class FootTraceActivity extends AppCompatActivity {
    private static final String TAG = "FootTraceActivity";
    private TextView tvDate;
    private TextView tvStartHour;
    private TextView tvStartMinute;
    private TextView tvEndHour;
    private TextView tvEndMinute;
    private RelativeLayout rlDate;
    private LinearLayout llStartHour;
    private LinearLayout llStartMinute;
    private LinearLayout llEndHour;
    private LinearLayout llEndMinute;
    private Button btnCommitTime;
//    private ImageView ivMyPosition;
//////////////////////////////////高德地图相关控件////////////////////////////////////////////////////
    private AMap aMap;
    private MapView mapView;
    private UiSettings mUiSettings;

//    private Polyline polyline;
//    private Marker mLocMarker;

//////////////////////////////////////////////////////////////////////////////////////////////////////

    private String deviceID;//设备id

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foot_trace);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        initViews(savedInstanceState);
        initDatas();

    }
    //初始化控件
    void initViews(Bundle savedInstanceState){
        bindViews();
        initAmap(savedInstanceState);
    }

    void bindViews(){
        tvDate = (TextView) findViewById(R.id.tv_date);
        tvStartHour = (TextView) findViewById(R.id.tv_start_hour);
        tvStartMinute = (TextView) findViewById(R.id.tv_start_minute);
        tvEndHour = (TextView) findViewById(R.id.tv_end_hour);
        tvEndMinute = (TextView) findViewById(R.id.tv_end_minute);
        rlDate = (RelativeLayout) findViewById(R.id.ll_date);
        llStartHour = (LinearLayout) findViewById(R.id.ll_start_hour);
        llStartMinute = (LinearLayout) findViewById(R.id.ll_start_minute);
        llEndHour = (LinearLayout) findViewById(R.id.ll_end_hour);
        llEndMinute = (LinearLayout) findViewById(R.id.ll_end_minute);
        btnCommitTime = (Button) findViewById(R.id.btn_commit_time);
//        ivMyPosition = (ImageView) findViewById(R.id.iv_position);
        rlDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });
        llStartHour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStartTimerPickerDialog();
            }
        });
        llStartMinute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStartTimerPickerDialog();
            }
        });
        llEndHour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEndTimerPickerDialog();
            }
        });
        llEndMinute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEndTimerPickerDialog();
            }
        });
        btnCommitTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCurrentDayFootTrace();
            }
        });
//        ivMyPosition.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                LatLng location = AmapActivity.getMylocation();
//                addMarker(location, R.drawable.my_location);
//                aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 13));
//            }
//        });
    }

    //初始化数据
    void initDatas(){
        initTimeData();
        initDeviceData();
    }
    void initDeviceData(){
        //获取设备ID
        Intent intent = getIntent();
        deviceID = intent.getStringExtra(Config.KEY_DEVICE_ID);
        getCurrentDayFootTrace();
    }


    /**
     *  @author henmory
     *  @date 1/11/17
     *  @description    获取设备当天的历史轨迹
     *                  如果成功绘制轨迹
     *                  如果失败定位到设备的目前的位置
     *
     *  @param
     *
     *  @return
    */
    void getCurrentDayFootTrace(){
        //获取开始和结束时间
        String startTime;
        String endTime;
        int startHour = Integer.parseInt(tvStartHour.getText().toString());
        int endHour = Integer.parseInt(tvEndHour.getText().toString());
        int startMinute = Integer.parseInt(tvStartMinute.getText().toString());
        int endMinute = Integer.parseInt(tvEndMinute.getText().toString());
        Log.d(TAG, "start = " + startHour + ":" + startMinute + " end = " + endHour + ":" + endMinute);
        if ((startHour < endHour) || ((startHour == endHour) && (startMinute < endMinute))){
            startTime = tvDate.getText() + " " + startHour + ":" + startMinute;
            endTime = tvDate.getText() + " " + endHour + ":" + endMinute;
        }else{
            startTime = null;
            endTime = null;
        }

        if (null != startTime && null != endTime){
            final CustomProgressDialog customProgressDialog = new CustomProgressDialog(FootTraceActivity.this,
                    "数据初始化，请稍后...");
            customProgressDialog.show();
            DevicesService.getDeviceHistoryTrace(FootTraceActivity.this, Config.token, deviceID, 1, startTime, endTime,
                    new SuccessCallback() {
                        @Override
                        public void onSuccess(Object object) {
                            customProgressDialog.dismiss();
                            List<FuncHistPosView> datas = DevicesService.getHistoryPosition();
                            if (datas.size() > 0){
                                aMap.clear();
                                drawFootTrace(datas);
                            }
                        }
                    }, new FailCallback() {//获取估计失败，定位到该设备
                        @Override
                        public void onFail(Object object) {
                            customProgressDialog.dismiss();
                            Toast.makeText(FootTraceActivity.this, object.toString(), Toast.LENGTH_SHORT).show();
                            LatLng latlng = getDevicePosition(deviceID);
                            if (null != latlng){
//                                addMarker(latlng, R.drawable.device_position);
                                aMap.clear();
                                aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latlng, 13));
                            }
                        }
                    });
        }else{
            Toast.makeText(FootTraceActivity.this, "时间选择有误，请重新选择", Toast.LENGTH_SHORT).show();
        }

    }
    //初始化时间控件数据
    void initTimeData(){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH) +  1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        String sMonth;
        String sDay;
        if (month < 10){
            sMonth = "0" + month + "";
        }else{
            sMonth = month + "";
        }
        if (day < 10){
            sDay = "0" + day + "";
        }else{
            sDay = day + "";
        }
        tvDate.setText(year + "-" + sMonth + "-" + sDay);
        tvStartHour.setText("00");
        tvStartMinute.setText("00");
        tvEndHour.setText("23");
        tvEndMinute.setText("59");
    }
    //显示日历
    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(FootTraceActivity.this, android.R.style.Theme_Material_Light_Dialog_Alert, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                String sMonth;
                String sDay;
                if ((monthOfYear + 1)< 10){
                    sMonth = "0" + (monthOfYear + 1) + "";
                }else{
                    sMonth = (monthOfYear + 1) + "";
                }
                if (dayOfMonth < 10){
                    sDay = "0" + dayOfMonth + "";
                }else{
                    sDay = dayOfMonth + "";
                }
                tvDate.setText(year + "-" + sMonth + "-" + sDay);
            }
        }, year, month, day);
        datePickerDialog.setCancelable(true);
        datePickerDialog.show();

    }

    //显示开始时间
     void showStartTimerPickerDialog(){
         Calendar calendar = Calendar.getInstance();
         new TimePickerDialog(FootTraceActivity.this, new TimePickerDialog.OnTimeSetListener() {
             @Override
             public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                 String hour;
                 String min;
                 if (hourOfDay < 10){
                     hour = "0" + hourOfDay + "";
                 }else{
                     hour = hourOfDay + "";
                 }
                 if (minute < 10){
                     min = "0" + minute + "";
                 }else{
                     min = minute + "";
                 }
                 tvStartHour.setText(hour);
                 tvStartMinute.setText(min);
             }
         },calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
     }

    //显示截止时间
    void showEndTimerPickerDialog(){
        Calendar calendar = Calendar.getInstance();
        new TimePickerDialog(FootTraceActivity.this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String hour;
                String min;
                if (hourOfDay < 10){
                    hour = "0" + hourOfDay + "";
                }else{
                    hour = hourOfDay + "";
                }
                if (minute < 10){
                    min = "0" + minute + "";
                }else{
                    min = minute + "";
                }
                tvEndHour.setText(hour);
                tvEndMinute.setText(min);
            }
        },calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
    }

//////////////////////////////////高德地图相关///////////////////////////////////////////////////////
    void initAmap(Bundle savedInstanceState){
        mapView = (MapView) findViewById(R.id.map1);
        mapView.onCreate(savedInstanceState);// 此方法必须重写
        if (aMap == null) {
            aMap = mapView.getMap();
            mUiSettings = aMap.getUiSettings();

        }
        mUiSettings.setLogoPosition(AMapOptions.LOGO_POSITION_BOTTOM_CENTER);// 设置地图logo显示在底部居中
        mUiSettings.setScaleControlsEnabled(false);//设置地图默认的比例尺
        mUiSettings.setZoomControlsEnabled(true);//设置地图默认的缩放按钮
        mUiSettings.setCompassEnabled(false);//指南针
        mUiSettings.setMyLocationButtonEnabled(false); // 显示默认的定位按钮
        mUiSettings.setScrollGesturesEnabled(true);//手势滑动
        mUiSettings.setZoomGesturesEnabled(true);//手势放大缩小
    }


    /**
     * 方法必须重写
     */
    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause();
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    private void drawFootTrace(List<FuncHistPosView> datas){
        Log.d(TAG, "历史轨迹的移动点个数 = " + datas.size());
        LatLng latLng1 = null;
        LatLng latLng2 = null;
        Set<LatLng> markPositions = new HashSet<>();
        for (int i = 0; i < datas.size() - 1; i++){
            latLng1 = new LatLng(datas.get(i).getLat(), datas.get(i).getLng());
            latLng2 = new LatLng(datas.get(i + 1).getLat(), datas.get(i + 1).getLng());
            aMap.addPolyline((new PolylineOptions())
                    .add(latLng1, latLng2)
                    .color(Color.RED));
            markPositions.add(latLng1);
        }
        markPositions.add(latLng2);
        Iterator iterator = markPositions.iterator();
        while (iterator.hasNext()){
            addMarker((LatLng) iterator.next(), R.drawable.stop);
        }
        latLng1 = new LatLng(datas.get(0).getLat(), datas.get(0).getLng());
        latLng2 = new LatLng(datas.get(datas.size() - 1).getLat(), datas.get(datas.size() - 1).getLng());
        addMarker(latLng2, R.drawable.terminal);//添加终点
        addMarker(latLng1, R.drawable.device_position);//添加起点
        aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng1, 13));

    }



    private void addMarker(LatLng latlng, int id) {
        Bitmap bMap = BitmapFactory.decodeResource(this.getResources(),
                id);//显示我的位置图标
        BitmapDescriptor des = BitmapDescriptorFactory.fromBitmap(bMap);
        MarkerOptions options = new MarkerOptions();
        options.icon(des);
        options.anchor(0.5f, 1);
        options.position(latlng);
        options.title(Config.device_id);//用id作为每个设备的区别
        aMap.addMarker(options);
    }

    private LatLng getDevicePosition(String id){
        List<FuncHistPosView> position = DevicesService.getHistoryPosition();
        for (int i = 0; i < position.size(); i++){
            if (id.equals(position.get(i).getDeviceId())){
                return new LatLng(position.get(i).getLat(),position.get(i).getLng());
            }
        }
        return null;
    }





//////////////////////////////////////////////////////////////////////////////////////////////////////

}
