package com.changhong.changhongcare.adapter;

import android.content.Context;

import com.changhong.changhongcare.R;
import com.changhong.changhongcare.utils.CommonAdapter;
import com.changhong.changhongcare.utils.CommonViewHolder;

import java.util.List;

/**
 * author: henmory
 * time:  6/20/17
 * function:
 * description:
 */

public class PayDetailItemAdapter extends CommonAdapter<PayDetailItem> {

    public PayDetailItemAdapter(List<PayDetailItem> mDatas, Context mContext, int mItemLayout) {
        super(mDatas, mContext, mItemLayout);
    }

    @Override
    public void convert(CommonViewHolder holder, PayDetailItem payDetailItem) {
        holder.setText(R.id.tv_pay_date, payDetailItem.getTime());
        holder.setText(R.id.tv_pay_time, payDetailItem.getTime());
        holder.setText(R.id.tv_pay_flow, payDetailItem.getFlowNo());
        holder.setText(R.id.tv_pay_type, payDetailItem.getPayMethord() + payDetailItem.getPayStatus());
        holder.setText(R.id.tv_pay_month, payDetailItem.getServiceTime() + "");
    }
}
