package com.changhong.changhongcare.deprecated;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;

import com.changhong.changhongcare.R;
import com.changhong.changhongcare.adapter.UpdateTimeItem;
import com.changhong.changhongcare.adapter.UpdateTimeItemAdapter;
import com.changhong.changhongcare.appconfig.Config;

import java.util.ArrayList;
import java.util.List;

public class UpdateTimeActivity extends AppCompatActivity {

    private ListView listView;
    private UpdateTimeItemAdapter adapter;
    private List<UpdateTimeItem> updateTimeItem = new ArrayList<>();
    private ImageView select;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_time);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        select = (ImageView) findViewById(R.id.iv_item_update_time_select);
        listView = (ListView) findViewById(R.id.lv_update_time);
        if (0 == Config.refresh_index){
            updateTimeItem.add(new UpdateTimeItem(R.drawable.slow, "慢（间隔60秒）", R.drawable.select_update_time));
            updateTimeItem.add(new UpdateTimeItem(R.drawable.normal, "普通（间隔30秒）", R.drawable.unselect_update_time));
            updateTimeItem.add(new UpdateTimeItem(R.drawable.fast, "快（间隔10秒）", R.drawable.unselect_update_time));
        }else if(1 == Config.refresh_index){
            updateTimeItem.add(new UpdateTimeItem(R.drawable.slow, "慢（间隔60秒）", R.drawable.unselect_update_time));
            updateTimeItem.add(new UpdateTimeItem(R.drawable.normal, "普通（间隔30秒）", R.drawable.select_update_time));
            updateTimeItem.add(new UpdateTimeItem(R.drawable.fast, "快（间隔10秒）", R.drawable.unselect_update_time));
        }else if(2 == Config.refresh_index){
            updateTimeItem.add(new UpdateTimeItem(R.drawable.slow, "慢（间隔60秒）", R.drawable.unselect_update_time));
            updateTimeItem.add(new UpdateTimeItem(R.drawable.normal, "普通（间隔30秒）", R.drawable.unselect_update_time));
            updateTimeItem.add(new UpdateTimeItem(R.drawable.fast, "快（间隔10秒）", R.drawable.select_update_time));
        }else {
            updateTimeItem.add(new UpdateTimeItem(R.drawable.slow, "慢（间隔60秒）", R.drawable.select_update_time));
            updateTimeItem.add(new UpdateTimeItem(R.drawable.normal, "普通（间隔30秒）", R.drawable.unselect_update_time));
            updateTimeItem.add(new UpdateTimeItem(R.drawable.fast, "快（间隔10秒）", R.drawable.unselect_update_time));
        }

        adapter = new UpdateTimeItemAdapter(updateTimeItem, this, R.layout.list_item_update_time);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                UpdateTimeItem updateTimeItem;
                for (int i = 0; i < adapter.getCount(); i++) {
                    updateTimeItem = (UpdateTimeItem) parent.getItemAtPosition(i);
                    if (i == position) {
                        updateTimeItem.setSelect(R.drawable.select_update_time);
                    } else {
                        updateTimeItem.setSelect(R.drawable.unselect_update_time);
                    }
                }
                adapter.notifyDataSetInvalidated();
                Config.cacheRefreshTime(UpdateTimeActivity.this, position);
            }
        });
    }

}
