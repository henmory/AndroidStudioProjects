package com.changhong.changhongcare.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.changhong.changhongcare.R;
import com.changhong.changhongcare.appconfig.Config;

public class UserAccountActivity extends AppCompatActivity {

    private TextView textView;
    private LinearLayout switchUser;
    private LinearLayout modifyPassword;
    public static UserAccountActivity mInstance = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_account);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        switchUser = (LinearLayout) findViewById(R.id.ll_switch_user);
        modifyPassword = (LinearLayout) findViewById(R.id.ll_modify_password);
        textView = (TextView) findViewById(R.id.tv_personal_message_account);
        textView.setText("账号:" + Config.phoneNumber);

        switchUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserAccountActivity.this, LoginActivity.class));
                Config.removePassword(UserAccountActivity.this);
                Config.removePhoneNumber(UserAccountActivity.this);
                AmapActivity.mInstace.finish();
                finish();
            }
        });

        modifyPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserAccountActivity.this, ModifyPasswordActivity.class));

            }
        });

        mInstance = this;
    }

}
