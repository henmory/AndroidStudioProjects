package com.changhong.changhongcare.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.api.maps2d.CameraUpdateFactory;
import com.amap.api.maps2d.model.LatLng;
import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.oldprotocol.ksoap.DevicesService;
import com.changhong.changhongcare.adapter.DeviceItem;
import com.changhong.changhongcare.adapter.DeviceItemAdapter;
import com.changhong.changhongcare.oldprotocol.structFromService.Position;
import com.changhong.changhongcare.utils.DisplayUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * author: henmory
 * time:  12/6/16
 * function:
 * description:  设备列表对话框
 */

public class DeviceListDialog extends Dialog {

    private final static String TAG = "DeviceListDialog";
    private final static double HEIGHT_OF_PROPIRATION = 0.4;
    private final static int WIDTH = WindowManager.LayoutParams.MATCH_PARENT;
    private Button btnCancel;
    private TextView tvDeviceName;//设备列表中的名字
    private ListView lvDeviceItems;
    private RelativeLayout rlAddDevice;//添加设备
    private static Context context;

    //////////////////////////////////////业务相关////////////////////////////////////////////////////////////////
    private List<DeviceItem> deviceItems;//显示设备名称和头像

    public DeviceListDialog(Context context) {

        //给dialog定制了一个主题（透明背景，无边框，无标题栏，浮在Activity上面，模糊）
        super(context, R.style.custom_bottom_dialog);
        setContentView(R.layout.bottom_dialog_device_list);
        bindViews();
        initWindowParams(context);
        initDatas(context);
        operatorClickEvent();
        this.context = context;

    }    //初始化控件

    private void bindViews() {

        tvDeviceName = (TextView) findViewById(R.id.tv_device_item_name);
        btnCancel = (Button) findViewById(R.id.btn_cancel);
        lvDeviceItems = (ListView) findViewById(R.id.lv_device);
        rlAddDevice = (RelativeLayout) findViewById(R.id.ll_add_device);
    }


    //设置dialog参数
    private void initWindowParams(Context context) {

        //点击空白区域可以取消dialog
        this.setCanceledOnTouchOutside(true);
        //点击back键可以取消dialog
        this.setCancelable(true);
        Window window = this.getWindow();
        //让Dialog显示在屏幕的底部
        window.setGravity(Gravity.BOTTOM);
        //设置窗口出现和窗口隐藏的动画
        window.setWindowAnimations(R.style.custom_bottom_dialog_anim);
        //设置BottomDialog的宽高属性
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.width = WIDTH;
        lp.height = (int) (DisplayUtil.getDeviceHeight(context) * HEIGHT_OF_PROPIRATION);
        window.setAttributes(lp);
    }

    //初始化adapter参数
    private void initDatas(Context context) {
        getAllDeviceName();
        DeviceItemAdapter adapter = new DeviceItemAdapter(deviceItems, context, R.layout.list_item_device);
        lvDeviceItems.setAdapter(adapter);
    }

    //处理点击事件
    private void operatorClickEvent() {
        //取消按钮响应事件
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeviceListDialog.this.dismiss();
            }
        });
        //设备列表点击事件
        lvDeviceItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                dismiss();//关闭设备列表对话框
                //弹出设备详细信息对话框
                List<Position> devices = DevicesService.getPositionList();//获取从服务器获取的设备列表

                LatLng latLng = new LatLng(devices.get(position).getLa(), devices.get(position).getLo());
                AmapActivity amapActivity = (AmapActivity)context;
                amapActivity.getaMap().moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 13));

                DeviceParamDialog deviceParamDialog = new DeviceParamDialog(parent.getContext(), devices.get(position).getDeviceID());
                deviceParamDialog.show();
            }
        });

        //添加设备
        rlAddDevice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                context.startActivity(new Intent(context, BindDeviceActivity.class));
            }
        });
    }



    /**
     * @param
     * @return
     * @author henmory
     * @date 12/13/16
     * @description 获取设备列表
     */
    private void getAllDeviceName() {
        if (deviceItems == null) {
            deviceItems = new ArrayList<>();
        }
        deviceItems.clear();
        Log.d(TAG, deviceItems.size() + "");
        List<Position> deviceBasicInfos = DevicesService.getPositionList();
        for (int i = 0; i < deviceBasicInfos.size(); i++) {
            deviceItems.add(new DeviceItem(deviceBasicInfos.get(i).getNickName(), R.drawable.device_image, R.drawable.delete_family_num));
        }
    }

    //删除设备
    public static void deleteDevice(String name){
        String imei = null;
        List<Position> deviceBasicInfos = DevicesService.getPositionList();
        for (int i = 0; i < deviceBasicInfos.size(); i++) {
            if (name.equals(deviceBasicInfos.get(i).getNickName()) || name.equals(deviceBasicInfos.get(i).getDeviceName())){
                imei = deviceBasicInfos.get(i).getDeviceIMEI();
                break;
            }
        }
        Log.d(TAG, "delete device imei = " + imei);
        if (null != imei){
            DevicesService.deleteBindDevice(context, Config.phoneNumber, imei, new SuccessCallback() {
                @Override
                public void onSuccess(Object object) {

                }
            }, new FailCallback() {
                @Override
                public void onFail(Object object) {
                    Toast.makeText(context, " 删除设备失败", Toast.LENGTH_SHORT).show();
                }
            });
        }else{
            Toast.makeText(context, " 删除设备失败", Toast.LENGTH_SHORT).show();
        }

    }
}
