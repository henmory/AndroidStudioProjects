package com.changhong.changhongcare.oldprotocol.ksoap;

import android.content.Context;
import android.text.TextUtils;


import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.oldprotocol.structFromService.MessageModel;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;


/**
 * Created by dan on 10/24/16.
 *
 *  description：该文件逻辑主要是在网络通信基础上，判断用户的操作是否成功，不做具体数据的转换
 *              操作失败：返回错误原因
 *              操作成功：返回服务器给的数据内容，由上一层业务处理
 */

public class ServiceInterface {

    private final String tag = "ServiceInterface";


    //内部参数类
    private class Args{
        HttpTransportSE transport;
        String soapAction;
        SoapSerializationEnvelope envelope;
    }

    //构造输入参数
    private Args getData(final String endPoint, final String methordName, final String flag, final String... kvs) {

        Args args = new Args();
        args.soapAction = KsoapConfig.NAME_SPACE + flag + methordName;
        SoapObject rpc = new SoapObject(KsoapConfig.NAME_SPACE, methordName);
        for (int i = 0; i < kvs.length; i += 2) {
            rpc.addProperty((String)kvs[i], kvs[i + 1]);
        }
        args.envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        args.envelope.dotNet = true;
        args.envelope.setOutputSoapObject(rpc);
        args.transport = new HttpTransportSE(endPoint);

        return args;
    }

    //登陆接口，
    public void login(Context context, final String userAccount, final String password,
                      final SuccessCallback successCallback, final FailCallback failCallback) {

        if (TextUtils.isEmpty(userAccount) || TextUtils.isEmpty(password))
            return;

        Args args = getData(KsoapConfig.PersonService.END_POINT,
                KsoapConfig.PersonService.Login.KEY_METHORD_NAME,
                KsoapConfig.PersonService.KEY_FLAG,
                KsoapConfig.PersonService.Login.KEY_USER_ACCOUNT, userAccount,
                KsoapConfig.PersonService.Login.KEY_PASSWORD, password);
        
        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 0){//登陆失败
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }else{//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };
    }
    //注册账号
    public void register(Context context, final String userAccount, String code, String password,
                         final SuccessCallback successCallback, final FailCallback failCallback){

    }
    //重置密码
    public void resetPassword(Context context, final String userAccount, String Pwd,
                               final SuccessCallback successCallback, final FailCallback failCallback){
        if (TextUtils.isEmpty(userAccount) || TextUtils.isEmpty(Pwd)){
            return;
        }
        Args args = getData(KsoapConfig.PersonService.END_POINT,
                KsoapConfig.PersonService.ResetPwd.KEY_METHORD_NAME,
                KsoapConfig.PersonService.KEY_FLAG,
                KsoapConfig.PersonService.ResetPwd.KEY_USER_ACCOUNT, userAccount,
                KsoapConfig.PersonService.ResetPwd.KEY_PASSWORD, Pwd);

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 0){
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }else{//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };
    }
    //修改密码
    public void modifyPassword(Context context, final String userAccount, String newPwd, String oldPwd,
                              final SuccessCallback successCallback, final FailCallback failCallback){
        if (TextUtils.isEmpty(userAccount) || TextUtils.isEmpty(newPwd) || TextUtils.isEmpty(oldPwd)){
            return;
        }
        Args args = getData(KsoapConfig.PersonService.END_POINT,
                KsoapConfig.PersonService.ModifyPwd.KEY_METHORD_NAME,
                KsoapConfig.PersonService.KEY_FLAG,
                KsoapConfig.PersonService.ModifyPwd.KEY_USER_ACCOUNT, userAccount,
                KsoapConfig.PersonService.ModifyPwd.KEY_NEW_PWD, newPwd,
                KsoapConfig.PersonService.ModifyPwd.KEY_OLD_WD, oldPwd);

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 0){
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }else{//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };
    }
    //获取验证码短信
    public void getCode(Context context, final String userAccount, final SuccessCallback successCallback,
                        final FailCallback failCallback){
        if (TextUtils.isEmpty(userAccount)){
            return;
        }
        Args args = getData(KsoapConfig.PersonService.END_POINT,
                KsoapConfig.PersonService.GetCodeBySMS.KEY_METHORD_NAME,
                KsoapConfig.PersonService.KEY_FLAG,
                KsoapConfig.PersonService.GetCodeBySMS.KEY_TELEPHONE, userAccount);

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 0){
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }else{//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };

    }
    //判断验证码是否争取
    public void isVerCodeCorrect(Context context, final String userAccount, final  String code,
                                 final SuccessCallback successCallback, final FailCallback failCallback){
        if (TextUtils.isEmpty(userAccount) || TextUtils.isEmpty(code)){
            return;
        }
        Args args = getData(KsoapConfig.PersonService.END_POINT,
                KsoapConfig.PersonService.IsVeriCodeCorrect.KEY_METHORD_NAME,
                KsoapConfig.PersonService.KEY_FLAG,
                KsoapConfig.PersonService.IsVeriCodeCorrect.KEY_USER_ACCOUNT, userAccount,
                KsoapConfig.PersonService.IsVeriCodeCorrect.KEY_CODE, code);

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 0){
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }else{//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };
    }
    //更新设备昵称
    public void updateDeviceNIckName(Context context, final String userAccount,String deviceID, String nickName, String tele,
                                     final SuccessCallback successCallback, final FailCallback failCallback){
        if (TextUtils.isEmpty(userAccount) || TextUtils.isEmpty(deviceID) || TextUtils.isEmpty(nickName)){
            return;
        }
        Args args = getData(KsoapConfig.DeviceService.END_POINT,
                KsoapConfig.DeviceService.UpdateOneDeviceNickName.KEY_METHORD_NAME,
                KsoapConfig.DeviceService.KEY_FLAG,
                KsoapConfig.DeviceService.UpdateOneDeviceNickName.KEY_USER_ACCOUNT, userAccount,
                KsoapConfig.DeviceService.UpdateOneDeviceNickName.KEY_DEVICE_ID, deviceID,
                KsoapConfig.DeviceService.UpdateOneDeviceNickName.KEY_NICK_NAME,nickName,
                KsoapConfig.DeviceService.UpdateOneDeviceNickName.KEY_TELE,tele);

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 0){
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }else{//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };

    }
    //添加设备
    public void addBindDevice(Context context, final String userAccount,String userTele, String code,
                              final SuccessCallback successCallback, final FailCallback failCallback){
        if (TextUtils.isEmpty(userAccount) || TextUtils.isEmpty(userTele) || TextUtils.isEmpty(code)){
            return;
        }
        Args args = getData(KsoapConfig.PersonService.END_POINT,
                KsoapConfig.PersonService.AddDevice.KEY_METHORD_NAME,
                KsoapConfig.PersonService.KEY_FLAG,
                KsoapConfig.PersonService.AddDevice.KEY_USER_ACCOUNT, userAccount,
                KsoapConfig.PersonService.AddDevice.KEY_USER_TELE, userTele,
                KsoapConfig.PersonService.AddDevice.KEY_CODE,code);

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 0){
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }else{//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };

    }
    //删除设备
    public void deleteBindDevice(Context context, final String userAccount, String imei,
                                 final SuccessCallback successCallback, final FailCallback failCallback){
        if (TextUtils.isEmpty(userAccount) || TextUtils.isEmpty(imei)){
            return;
        }
        Args args = getData(KsoapConfig.PersonService.END_POINT,
                KsoapConfig.PersonService.RemoveDevice.KEY_METHORD_NAME,
                KsoapConfig.PersonService.KEY_FLAG,
                KsoapConfig.PersonService.RemoveDevice.KEY_USER_ACCOUNT, userAccount,
                KsoapConfig.PersonService.RemoveDevice.KEY_IMEI, imei);

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 0){
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }else{//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };
    }
    //获取设备列表
    public void getBindDevicesList(Context context, final String userAccount,
                                   final SuccessCallback successCallback, final FailCallback failCallback){
        if (TextUtils.isEmpty(userAccount)){
            return;
        }
        Args args = getData(KsoapConfig.PersonService.END_POINT,
                KsoapConfig.PersonService.GetPersonDevice.KEY_METHORD_NAME,
                KsoapConfig.PersonService.KEY_FLAG,
                KsoapConfig.PersonService.GetPersonDevice.KEY_USER_ACCOUNT, userAccount);

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 0){
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }else{//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };
    }
    //获取设备详细位置列表
    public  void getBindDevicesPositionList(Context context, String userAccount, String isNeedChangePoint,
                                                  final SuccessCallback successCallback, final FailCallback failCallback){
        if (TextUtils.isEmpty(userAccount)){
            return;
        }
        Args args = getData(KsoapConfig.PersonService.END_POINT,
                KsoapConfig.PersonService.GetPersonDevicesPosInfo.KEY_METHORD_NAME,
                KsoapConfig.PersonService.KEY_FLAG,
                KsoapConfig.PersonService.GetPersonDevicesPosInfo.KEY_USER_ACCOUNT, userAccount,
                KsoapConfig.PersonService.GetPersonDevicesPosInfo.KEY_IS_NEED_CHANGE_POINT, isNeedChangePoint);

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 0){
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }else{//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };
    }

    //获取亲情号码
    public  void getDeviceFamilyNumbers(Context context, String deviceID,
                                              final SuccessCallback successCallback, final FailCallback failCallback){
        Args args = getData(KsoapConfig.DeviceService.END_POINT,
                KsoapConfig.DeviceService.GetRelationsByDeviceID.KEY_METHORD_NAME,
                KsoapConfig.DeviceService.KEY_FLAG,
                KsoapConfig.DeviceService.GetRelationsByDeviceID.KEY_DEVICE_ID, deviceID);

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 0){
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }else{//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };
    }
    //删除亲情号码
    public void deleteDeviceFamilyNumbers(Context context, String userAccount, String deviceID, int seqNO, String telNO,
                                          final SuccessCallback successCallback, final FailCallback failCallback) {
        if (TextUtils.isEmpty(userAccount)){
            return;
        }
        Args args = getData(KsoapConfig.DeviceService.END_POINT,
                KsoapConfig.DeviceService.DeleteRelationByDeviceID.KEY_METHORD_NAME,
                KsoapConfig.DeviceService.KEY_FLAG,
                KsoapConfig.DeviceService.DeleteRelationByDeviceID.KEY_USER_ACCOUNT, userAccount,
                KsoapConfig.DeviceService.DeleteRelationByDeviceID.KEY_DEVICE_ID, deviceID,
                KsoapConfig.DeviceService.DeleteRelationByDeviceID.KEY_SEQ_NO, seqNO + "",
                KsoapConfig.DeviceService.DeleteRelationByDeviceID.KEY_TEL_NO, telNO);

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 1){//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }

                }else{
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };
    }
    //添加亲情号码
    public void addDeviceFamilyNumbers(Context context, String userAccount, String deviceID, int seqNO, String telNO, String name,
                                          final SuccessCallback successCallback, final FailCallback failCallback) {
        if (TextUtils.isEmpty(userAccount)){
            return;
        }
        Args args = getData(KsoapConfig.DeviceService.END_POINT,
                KsoapConfig.DeviceService.SetDeviceRelation.KEY_METHORD_NAME,
                KsoapConfig.DeviceService.KEY_FLAG,
                KsoapConfig.DeviceService.SetDeviceRelation.KEY_USER_ACCOUNT, userAccount,
                KsoapConfig.DeviceService.SetDeviceRelation.KEY_DEVICE_ID, deviceID,
                KsoapConfig.DeviceService.SetDeviceRelation.KEY_SEQ_NO, seqNO + "",
                KsoapConfig.DeviceService.SetDeviceRelation.KEY_TEL_NO, telNO,
                KsoapConfig.DeviceService.SetDeviceRelation.KEY_RELATION, name);

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 0){
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }else{//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };
    }

    //获取定位心跳接口
    public  void getBindDeviceUploadPositionInterval(Context context, String deviceID,
                                                           final SuccessCallback successCallback, final FailCallback failCallback){
        Args args = getData(KsoapConfig.DeviceService.END_POINT,
                KsoapConfig.DeviceService.GeDevicetInterval.KEY_METHORD_NAME,
                KsoapConfig.DeviceService.KEY_FLAG,
                KsoapConfig.DeviceService.GeDevicetInterval.KEY_DEVICE_ID, deviceID);

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 0){
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }else{//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };
    }

    //设置定位心跳接口
    public  void setBindDeviceUploadPositionInterval(Context context, String deviceID, int interval,
                                                     final SuccessCallback successCallback, final FailCallback failCallback){
        Args args = getData(KsoapConfig.DeviceService.END_POINT,
                KsoapConfig.DeviceService.SetDevicetInterval.KEY_METHORD_NAME,
                KsoapConfig.DeviceService.KEY_FLAG,
                KsoapConfig.DeviceService.SetDevicetInterval.KEY_INTERVAL, interval + "",
                KsoapConfig.DeviceService.SetDevicetInterval.KEY_DEVICE_ID, deviceID);

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 1){
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }

                }else{
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };
    }

    //获取历史轨迹
    public void getBindDeviceHistoryTrace(Context context, String userAccount, int isNeedChangePoint, String deviceID,
                                          String startTime, String endTime, int isNeedLBS,
                                          final SuccessCallback successCallback, final FailCallback failCallback){
        Args args = getData(KsoapConfig.DeviceService.END_POINT,
                KsoapConfig.DeviceService.GetDeviceHispos.KEY_METHORD_NAME,
                KsoapConfig.DeviceService.KEY_FLAG,
                KsoapConfig.DeviceService.GetDeviceHispos.KEY_USER_ACCOUNT, userAccount,
                KsoapConfig.DeviceService.GetDeviceHispos.KEY_IS_NEED_CHANGE_POINT, isNeedChangePoint + "",
                KsoapConfig.DeviceService.GetDeviceHispos.KEY_DEVICE_ID, deviceID,
                KsoapConfig.DeviceService.GetDeviceHispos.KEY_TIME_START, startTime,
                KsoapConfig.DeviceService.GetDeviceHispos.KEY_TIME_END, endTime,
                KsoapConfig.DeviceService.GetDeviceHispos.KEY_IS_NEED_LBS, isNeedLBS + "");

        new NetConnection(context, args.transport, args.soapAction, args.envelope) {
            @Override
            public void netConnectionSuccess(Object data) {//通信成功
                MessageModel messageModel = (MessageModel)data;
                if (messageModel.getReturnStatus() == 0){
                    if (null != failCallback){
                        failCallback.onFail(messageModel.getReturnMessage());
                    }
                }else{//登陆成功
                    if (null != successCallback){
                        successCallback.onSuccess(messageModel.getReturnObject());
                    }
                }
            }

            @Override
            public void netConnectionFail(Object data) {//通信失败
                MessageModel message = (MessageModel)data;
                if (null != failCallback){
                    failCallback.onFail(message.getReturnMessage());
                }
            }
        };
    }




}
