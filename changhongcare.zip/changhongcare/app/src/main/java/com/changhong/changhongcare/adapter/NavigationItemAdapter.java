package com.changhong.changhongcare.adapter;

import android.content.Context;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.utils.CommonAdapter;
import com.changhong.changhongcare.utils.CommonViewHolder;
import com.changhong.changhongcare.utils.DisplayUtil;

import java.util.List;

/**
 * author: henmory
 * time:  11/25/16
 * function:
 * description:
 */

public class NavigationItemAdapter extends CommonAdapter<NavigationItem> {

    public NavigationItemAdapter(List<NavigationItem> mDatas, Context mContext, int mItemLayout) {
        super(mDatas, mContext, mItemLayout);
    }

    @Override
    public void convert(CommonViewHolder holder, NavigationItem navigationItem) {
        holder.setText(R.id.tv_description, navigationItem.getDescription());
        holder.setImageResource(R.id.image_view, navigationItem.getIconId());
    }
}
