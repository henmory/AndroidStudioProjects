package com.changhong.changhongcare.utils;

import android.content.DialogInterface;

import com.changhong.changhongcare.oldprotocol.ksoap.NetConnection;


/**
 * author: henmory
 * time:  11/23/16
 * function:
 * description:
 */

public class DialogCancelListener implements DialogInterface.OnCancelListener {
    //如果已经开始下载，强制中断下载线程（true）,
    // (false)线程开始后会继续执行下载任务，只是不会调用onPostExecute接口
    @Override
    public void onCancel(DialogInterface dialog) {
        System.out.println("用户安返回键取消网络操作");

        if (NetConnection.getTask() != null){
            if (NetConnection.getTask().cancel(true)){
            }
        }
        dialog.dismiss();//还没有开始下载
    }
}
