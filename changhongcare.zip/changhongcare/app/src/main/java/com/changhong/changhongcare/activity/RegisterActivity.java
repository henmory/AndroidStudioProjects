package com.changhong.changhongcare.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.SmsSendFailedCallback;
import com.changhong.changhongcare.Interface.SmsSendSuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.utils.Utils;

public class RegisterActivity extends AppCompatActivity {

//    private EditText evNativePhoneNumber;
    private EditText evFeaturePhoneNumber;
    private Button btnBind;
    private CustomProgressDialog customProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        bindViews();
    }

    private void bindViews(){
//        evNativePhoneNumber = (EditText) findViewById(R.id.et_native_phone_number);
        evFeaturePhoneNumber = (EditText) findViewById(R.id.et_feature_phone_number);
        btnBind = (Button) findViewById(R.id.btn_bind);
        btnBind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                final String naticeNum = evNativePhoneNumber.getText().toString();
                String featureNum = evFeaturePhoneNumber.getText().toString();
                if (TextUtils.isEmpty(featureNum)){
                    Toast.makeText(RegisterActivity.this, "电话号码不能为空", Toast.LENGTH_SHORT).show();
                }else{
                    customProgressDialog = new CustomProgressDialog(RegisterActivity.this, "短信发送中...");
                    customProgressDialog.show();
                    Utils.sendSMS(RegisterActivity.this, featureNum, "bd", new SmsSendSuccessCallback() {
                        @Override
                        public void onSucess() {
                            customProgressDialog.dismiss();
                            Toast.makeText(RegisterActivity.this,"短信发送成功", Toast.LENGTH_SHORT).show();
                            finish();
                        }

                    }, new SmsSendFailedCallback() {
                        @Override
                        public void onFailed() {
                            customProgressDialog.dismiss();
                            Toast.makeText(RegisterActivity.this,"短信发送失败", Toast.LENGTH_SHORT).show();

                        }
                    });
//                    finish();
                }
            }
        });
    }







}
