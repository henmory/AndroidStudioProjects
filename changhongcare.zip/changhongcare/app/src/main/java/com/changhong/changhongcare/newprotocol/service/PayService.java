package com.changhong.changhongcare.newprotocol.service;

import android.content.Context;
import android.util.Log;

import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.newprotocol.okhttp.ServerConfig;
import com.changhong.changhongcare.pay.alipay.struct.AlipayResultParam;
import com.changhong.changhongcare.pay.alipay.struct.PayParam;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * author: henmory
 * time:  6/7/17
 * function:
 * description:
 */

public class PayService {

    private final static String tag = "PayService";


    public final static String KEY_CHANNEL = "Channel";
    public final static String KEY_TYPE = "Type";
    public final static String KEY_AMOUNT = "Amount";
    public final static String KEY_SERVICETIME = "ServiceTime";
    public final static String KEY_MEMO = "memo";
    public final static String KEY_RESULT = "result";
    public final static String KEY_RESULTSTATIS = "resultStatus";
    public final static String KEY_FLOWNO= "FlowNo";
    public final static String KEY_METHORD = "PayMethod";
    public final static String KEY_PAYSTATUS = "PayStatus";


    private static ServiceInterface serviceInterface = new ServiceInterface();


    public static void pay(Context context, String token, PayParam payParam,
                    final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.pay(context, token, payParam, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(tag, "pay: " + object.toString());
                JSONObject jsonObject = (JSONObject) object;
                try {
                    int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                    if (retCode == 0) {//success---code
                        if (null != successCallback) {
                            String ret = jsonObject.getString(PersonService.KEY_DADA);
                            successCallback.onSuccess(ret);
                        }

                    } else {
                        if (null != failCallback) {
                            failCallback.onFail(retCode);
                        }
                    }
                } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                    e.printStackTrace();
                    if (null != failCallback) {
                        failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                    }
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d(tag, "logout: " + object.toString());
                failed(object, failCallback);
            }
        });

    }

    // TODO: 6/8/17 如果同步结果发送失败，跟服务器端商量
    public static void payNotifyServer(Context context, String token, AlipayResultParam alipayResultParam,
                           final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.payNotifyServer(context, token, alipayResultParam, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(tag, "payNotifyServer: " + object.toString());
                JSONObject jsonObject = (JSONObject) object;
                try {
                    int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                    if (retCode == 0) {//success---code
                        if (null != successCallback) {
                            successCallback.onSuccess(retCode);
                        }
                    } else {
                        if (null != failCallback) {
                            failCallback.onFail(retCode);
                        }
                    }
                } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                    e.printStackTrace();
                    if (null != failCallback) {
                        failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                    }
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d(tag, "payNotifyServer: " + object.toString());
                failed(object, failCallback);
            }
        });

    }

    public static void getPayDetails(Context context, String token,
                                       final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.getPayDetails(context, token, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(tag, "getPayDetails: " + object.toString());
                JSONObject jsonObject = (JSONObject) object;
                try {
                    int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                    if (retCode == 0) {//success---code
                        JSONArray jsonArray = jsonObject.getJSONArray(ServerConfig.KEY_DATA);
                        if (null != successCallback) {
                            successCallback.onSuccess(jsonArray);
                        }
                    } else {
                        if (null != failCallback) {
                            failCallback.onFail(retCode);
                        }
                    }
                } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                    e.printStackTrace();
                    if (null != failCallback) {
                        failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                    }
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d(tag, "payNotifyServer: " + object.toString());
                failed(object, failCallback);
            }
        });

    }

    private static void failed(Object object, FailCallback failCallback){
        JSONObject jsonObject = (JSONObject) object;
        try {
            int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
            if (null != failCallback) {
                failCallback.onFail(retCode);
            }

        } catch (JSONException e) {
            e.printStackTrace();
            if (null != failCallback) {
                failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
            }
        }
    }
}
