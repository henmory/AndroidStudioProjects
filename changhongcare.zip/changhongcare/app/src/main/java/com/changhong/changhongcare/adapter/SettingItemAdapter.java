package com.changhong.changhongcare.adapter;

import android.content.Context;

import com.changhong.changhongcare.R;
import com.changhong.changhongcare.utils.CommonAdapter;
import com.changhong.changhongcare.utils.CommonViewHolder;

import java.util.List;

/**
 * author: henmory
 * time:  12/19/16
 * function:
 * description:
 */

public class SettingItemAdapter extends CommonAdapter<SettingItem> {
    public SettingItemAdapter(List<SettingItem> mDatas, Context mContext, int mItemLayout) {
        super(mDatas, mContext, mItemLayout);
    }

    @Override
    public void convert(CommonViewHolder holder, SettingItem settingItem) {
        holder.setImageResource(R.id.iv_item_setting_icon, settingItem.getIcon());
        holder.setText(R.id.tv_item_setting_description, settingItem.getDescription());
        holder.setImageResource(R.id.iv_item_setting_go_to_next, settingItem.getGoToNext());
    }
}
