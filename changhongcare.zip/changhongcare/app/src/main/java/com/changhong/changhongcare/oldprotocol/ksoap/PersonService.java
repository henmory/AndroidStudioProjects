package com.changhong.changhongcare.oldprotocol.ksoap;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;

import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;


/**
 * author: henmory
 * time:  11/22/16
 * function:
 * description: 该文件接口，服务处理界面用户需要的数据，丢掉不要，保存需要的
 */

public class PersonService {

    private final static String tag = "PersonService";
    private static ServiceInterface serviceInterface = new ServiceInterface();

    /**
     *  @author henmory
     *  @date 11/19/16
     *  @description    单击登陆按钮逻辑处理
     *
     *  @param
     *
     *  @return
     */
    public static void login(final Activity activity,  final String phoneNmber, final String password,
                             final SuccessCallback successCallback, final FailCallback failCallback){
        if (TextUtils.isEmpty(phoneNmber)  || TextUtils.isEmpty(password)){
            return;
        }

        serviceInterface.login(activity,  phoneNmber, password,new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                if (null != successCallback)
                    successCallback.onSuccess(null);
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (null != failCallback)
                    failCallback.onFail(object);

            }
        });
    }

    /**
     *  @author henmory
     *  @date 11/19/16
     *  @description 点击注册按钮，逻辑处理
     *
     *  @param
     *
     *  @return
     */
    public static void register(){

    }

    /**
     *  @author henmory
     *  @date 11/21/16
     *  @description    忘记密码处理逻辑
     *
     *  @param
     *
     *  @return
     */

    public static void forgetPassword(){

    }

    /**
     *  @author henmory
     *  @date 2/6/17
     *  @description    忘记密码的时候先获取验证码
     *
     *  @param
     *
     *  @return
    */
    public static void getCode(final Context context, final String phoneNmber,
                               final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.getCode(context, phoneNmber, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                if (null != successCallback){
                    successCallback.onSuccess(null);
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (null != failCallback){
                    failCallback.onFail(object);
                }
            }
        });
    }

    /**
     *  @author henmory
     *  @date 2/6/17
     *  @description    忘记密码后，先获取验证码，再验证code是否正确，最好在重置密码
     *
     *  @param
     *
     *  @return
    */
    public static void isVerCodeCorrect(final Context context, final String phoneNmber, final String code,
                               final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.isVerCodeCorrect(context, phoneNmber, code, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                if (null != successCallback){
                    successCallback.onSuccess(null);
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (null != failCallback){
                    failCallback.onFail(object);
                }
            }
        });
    }

    /**
     *  @author henmory
     *  @date 2/7/17
     *  @description    重置密码
     *
     *  @param
     *
     *  @return
    */
    public static void resetPwd(Context context, final String userAccount, String Pwd,
                                final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.resetPassword(context, userAccount, Pwd, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                if (null != successCallback){
                    successCallback.onSuccess(null);
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (null != failCallback){
                    failCallback.onFail(object);
                }
            }
        });
    }

    /**
     *  @author henmory
     *  @date 2/7/17
     *  @description    修改密码
     *
     *  @param
     *
     *  @return
    */

    public static void modifyPwd(Context context, final String userAccount, String newPwd, String oldPwd,
                                 final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.modifyPassword(context, userAccount, newPwd, oldPwd, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                if (null != successCallback){
                    successCallback.onSuccess(null);
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                if (null != failCallback){
                    failCallback.onFail(object);
                }
            }
        });
    }
}
