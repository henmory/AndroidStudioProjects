package com.changhong.changhongcare.pay.alipay.struct;

/**
 * author: henmory
 * time:  6/20/17
 * function:
 * description:
 */

public class PayFlowView {
    private int id; //流水id
    private String flowNo;//流水号
    private double amount;//消费金额
    private int type;//消费类型
    private String payMethord;//支付方式
    private int payStatus;//支付状态
    private int serviceTime;//购买服务套餐月数

    public PayFlowView() {
    }

    public PayFlowView(int id, String flowNo, double amount, int type, String payMethord, int payStatus, int serviceTime) {
        this.id = id;
        this.flowNo = flowNo;
        this.amount = amount;
        this.type = type;
        this.payMethord = payMethord;
        this.payStatus = payStatus;
        this.serviceTime = serviceTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFlowNo() {
        return flowNo;
    }

    public void setFlowNo(String flowNo) {
        this.flowNo = flowNo;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getPayMethord() {
        return payMethord;
    }

    public void setPayMethord(String payMethord) {
        this.payMethord = payMethord;
    }

    public int getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(int payStatus) {
        this.payStatus = payStatus;
    }

    public int getServiceTime() {
        return serviceTime;
    }

    public void setServiceTime(int serviceTime) {
        this.serviceTime = serviceTime;
    }
}
