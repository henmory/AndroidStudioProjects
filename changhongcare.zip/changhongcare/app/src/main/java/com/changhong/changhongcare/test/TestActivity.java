package com.changhong.changhongcare.test;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.alipay.sdk.app.PayTask;
import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.newprotocol.service.PayService;
import com.changhong.changhongcare.oldprotocol.ksoap.DevicesService;
import com.changhong.changhongcare.oldprotocol.ksoap.PersonService;
import com.changhong.changhongcare.pay.alipay.PayResult;
import com.changhong.changhongcare.pay.alipay.struct.PayParam;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;


public class TestActivity extends AppCompatActivity {

    Button btn;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 2: {
                    @SuppressWarnings("unchecked")
                    PayResult payResult = new PayResult((Map<String, String>) msg.obj);
                    /**
                     对于支付结果，请商户依赖服务端的异步通知结果。同步通知结果，仅作为支付结束的通知。
                     */
                    String resultInfo = payResult.getResult();// 同步返回需要验证的信息
                    Log.d("saf",resultInfo);
                    String resultStatus = payResult.getResultStatus();
                    // 判断resultStatus 为9000则代表支付成功
                    if (TextUtils.equals(resultStatus, "9000")) {
                        // 该笔订单是否真实支付成功，需要依赖服务端的异步通知。
                        Toast.makeText(TestActivity.this, "支付成功", Toast.LENGTH_SHORT).show();
                    } else {
                        // 该笔订单真实的支付结果，需要依赖服务端的异步通知。
                        Toast.makeText(TestActivity.this, "支付失败", Toast.LENGTH_SHORT).show();
                    }
                    break;
                }
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        btn = (Button) findViewById(R.id.btn_test);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                testGetFamilyNums();
//                testGetBindDevicePositionList();
//                testGetBindDeviceUploadPositionInterval();
//                testGetBindDeviceHistoryTrace();
//                testsetBindDeviceUploadPositionInterval();
                testPay();
            }


        });

    }
    void testLogin() {
        //登陆接口测试
        PersonService.login(TestActivity.this, "13488783239", "12345", new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                System.out.println("login success");
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                System.out.println("login failed");

            }
        });
    }

    void testGetBindDeviceList() {
        DevicesService.getBindDevicesList(TestActivity.this, "13488783239", new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                System.out.println("getBindDevicesList success = " + object.toString());

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                System.out.println("getBindDevicesList failed" + object.toString());

            }
        });
    }

    void testGetBindDevicePositionList() {
        DevicesService.getBindDevicesPositionList(TestActivity.this, "13488783239", 1 + "", new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                System.out.println("getBindDevicesPositionList success");
                System.out.println(object.toString());

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                System.out.println("getBindDevicesPositionList failed");

            }
        });

    }
    void testGetFamilyNums(){
        DevicesService.getDeviceFamilyNumbers(TestActivity.this, 1843387 + "", new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {

            }
        });
    }

    void testGetBindDeviceUploadPositionInterval(){
        DevicesService.getBindDeviceUploadPositionInterval(TestActivity.this, 1843387 + "", new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {

            }
        });
    }
    void testsetBindDeviceUploadPositionInterval(){
        DevicesService.setBindDeviceUploadPositionInterval(TestActivity.this, 1238387 + "", 600, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {

            }
        });
    }
    void testGetBindDeviceHistoryTrace(){
        DevicesService.getBindDeviceHistoryTrace(TestActivity.this, "17716154076", 1, 210209 + "", "2017-1-11 00:00", "2017-1-11 23:59", 1,
                new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {

                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        Toast.makeText(TestActivity.this, object.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    void testPay(){

        PayParam serviceRequestParam = new PayParam(0+"",0,0.01,1);

        PayService.pay(this, "hMx0WxA7Ks1a3hEHh1rP-gsICAgRRQ..", serviceRequestParam, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d("adf", object.toString());
                pay((String)object);
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d("adf", object.toString());

            }
        });

    }

    private void pay(final String orderInfo){
        Runnable payRunnable = new Runnable() {

			@Override
			public void run() {
				PayTask alipay = new PayTask(TestActivity.this);
				Map<String, String> result = alipay.payV2(orderInfo, true);
				Log.i("msp", result.toString());

				Message msg = new Message();
				msg.what = 2;
				msg.obj = result;
				mHandler.sendMessage(msg);
			}
		};

		Thread payThread = new Thread(payRunnable);
		payThread.start();
    }
}
