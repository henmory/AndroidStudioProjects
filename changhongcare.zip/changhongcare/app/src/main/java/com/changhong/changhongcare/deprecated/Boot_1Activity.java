package com.changhong.changhongcare.deprecated;

// TODO: 2/10/17 已经遗弃 
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;

import com.changhong.changhongcare.R;
import com.changhong.changhongcare.test.TestActivity;
import com.changhong.changhongcare.utils.MyGestureDetectorListener;

public class Boot_1Activity extends AppCompatActivity {

    private final static String tag = "Boot_1Activity";
    private MyGestureDetectorListener myGestureDetector;
    private GestureDetector mDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boot_1);
        Log.d(tag, "booot_1");
        myGestureDetector = new MyGestureDetectorListener() {
            @Override
            public void handleToLeft() {
                startActivity(new Intent(Boot_1Activity.this, Boot_2Activity.class));
//                overridePendingTransition(android.R.anim.slide_out_right,android.R.anim.slide_in_left);
                finish();
            }

            @Override
            public void handleToRight() {
            }
        };
        mDetector = new GestureDetector(this, myGestureDetector);

        // TODO: 11/18/16 测试
        if (false){
            test();
            return;
        }


    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return mDetector.onTouchEvent(event);
    }


    // TODO: 11/21/16 测试
    void test(){
        if(true){
            startActivity(new Intent(this, TestActivity.class));
        }
        finish();
    }
}

