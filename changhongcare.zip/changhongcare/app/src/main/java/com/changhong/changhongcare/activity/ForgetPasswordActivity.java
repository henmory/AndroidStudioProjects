package com.changhong.changhongcare.activity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.Callback;
import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.customview.CustomUserInputCodeDialog;
import com.changhong.changhongcare.newprotocol.okhttp.ServerConfig;
import com.changhong.changhongcare.newprotocol.service.PersonService;
import com.changhong.changhongcare.utils.FormatTools;
import com.changhong.changhongcare.utils.Utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ForgetPasswordActivity extends AppCompatActivity {
    private final static String tag = "ForgetPasswordActivity";

    private EditText evPhoneNumber; //phone number
    private EditText evCode; //verificaiton code
    private EditText evPassword; // new password
    private EditText evMarkPassword; //confirm password
    private Button btnResetPassword; //reset
    private Button btnGetCode; //getCode

    private String num;
    private String Code;
    private String password;
    private String markPassword;

    private String sessionId;
    private String graphicCode = "";

    private CustomProgressDialog customProgressDialog;
    //new倒计时对象,总共的时间,每隔多少秒更新一次时间
    final MyCountDownTimer myCountDownTimer = new MyCountDownTimer(120000, 1000);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        bindViews();
        bindEvents();

        initVerificationRequest();

    }

    private void initVerificationRequest() {

        customProgressDialog.setMessage("数据初始化中...");
        customProgressDialog.show();
        PersonService.initVerificationRequest(this, "", "", new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(tag, object.toString());
                sessionId = (String) object;
                customProgressDialog.dismiss();

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                //do nothing
                Toast.makeText(ForgetPasswordActivity.this, "初始化数据失败,请检查一下网络，稍后重试", Toast.LENGTH_SHORT).show();
                customProgressDialog.dismiss();
                finish();
            }
        });
    }


    private void bindViews() {
        customProgressDialog = new CustomProgressDialog(this);
        evPhoneNumber = (EditText) findViewById(R.id.et_phone_number);
        evCode = (EditText) findViewById(R.id.et_sms_code);
        evPassword = (EditText) findViewById(R.id.et_create_password);
        evMarkPassword = (EditText) findViewById(R.id.et_mark_password);
        btnResetPassword = (Button) findViewById(R.id.btn_mark);
        btnGetCode = (Button) findViewById(R.id.btn_get_code);


    }

    /**
     * @param
     * @return
     * @author henmory
     * @date 6/5/17
     * @description
     */
    private void bindEvents() {
        btnGetCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSMSCode();
            }
        });

        btnResetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetPassWord();
            }
        });
    }

    //get verification code
    private void getSMSCode() {
        //verify the phone number whether is correct
        num = evPhoneNumber.getText().toString();
        if (TextUtils.isEmpty(num)) {
            Toast.makeText(ForgetPasswordActivity.this, "电话号码不能为空", Toast.LENGTH_SHORT).show();
        } else {
            if (!Utils.checkMobileNumber(num)) {
                Toast.makeText(ForgetPasswordActivity.this, "手机号码格式不对", Toast.LENGTH_SHORT).show();
            } else {
                myCountDownTimer.start();
                getSMSVerificationCode();
            }
        }
    }


    private void getSMSVerificationCode() {
        customProgressDialog.setMessage("获取验证码...");
        customProgressDialog.show();

        PersonService.getSMSVerificationCode(ForgetPasswordActivity.this, num, 1 + "", sessionId, graphicCode,
                new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        customProgressDialog.dismiss();
                        Toast.makeText(ForgetPasswordActivity.this, "验证码发送成功", Toast.LENGTH_SHORT).show();
                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        int errorCode = (int) object;
                        if (errorCode == ServerConfig.OKHTTP_ERROR_CODE ||
                                errorCode == ServerConfig.NET_BUSY_ERROR_CODE ||
                                errorCode == ServerConfig.PARSE_DATA_FAILED_ERROR_CODE ||
                                errorCode == -5 ||
                                errorCode == -17) {
                            customProgressDialog.dismiss();
                            Toast.makeText(ForgetPasswordActivity.this, "网络连接失败", Toast.LENGTH_SHORT).show();
                        } else if (errorCode == -8) {//graphic code that user input is wrong
                            customProgressDialog.dismiss();
                            Toast.makeText(ForgetPasswordActivity.this, "验证码输入错误", Toast.LENGTH_SHORT).show();
//                    getImageVerificationCode();
                        } else if (errorCode == -24) {
                            Log.d(tag, errorCode + "");
//                    customProgressDialog.dismiss();
                            getImageVerificationCode();
                        }
                    }
                });
    }

    private void getImageVerificationCode() {
        PersonService.getImageVerificationCode(ForgetPasswordActivity.this, num, sessionId, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {

                //get the drawable of graphic code
                String fileName = (String) object;
                Drawable drawable = null;
                try {
                    drawable = FormatTools.getInstance().InputStream2Drawable(new FileInputStream(fileName));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

                customProgressDialog.dismiss();

                //show the dialog
                final CustomUserInputCodeDialog dialog = new CustomUserInputCodeDialog(ForgetPasswordActivity.this, drawable);
                dialog.setCanceledOnTouchOutside(false);
                dialog.setCancelable(true);
                dialog.setOnNegativeListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        graphicCode = "";
                    }
                });
                dialog.setOnPositiveListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        graphicCode = dialog.getEditText();
                        Log.d(tag, "user input the code = " + graphicCode);
                        getSMSCode();
                    }
                });
                dialog.show();

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                customProgressDialog.dismiss();
                Toast.makeText(ForgetPasswordActivity.this, object.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void resetPassWord() {

        num = evPhoneNumber.getText().toString();
        Code = evCode.getText().toString();
        password = evPassword.getText().toString();
        markPassword = evMarkPassword.getText().toString();

        if (TextUtils.isEmpty(num) || TextUtils.isEmpty(Code)
                || TextUtils.isEmpty(password) || TextUtils.isEmpty(markPassword)) {
            Toast.makeText(ForgetPasswordActivity.this, "所有字段不能为空", Toast.LENGTH_SHORT).show();
        } else {

            if (!password.equals(markPassword)) {
                Toast.makeText(ForgetPasswordActivity.this, "两次密码输入不一致", Toast.LENGTH_SHORT).show();
                return;
            }
            customProgressDialog.setMessage("重置密码...");
            customProgressDialog.show();

            PersonService.verifyVerificationCode(ForgetPasswordActivity.this, num, 1+"", sessionId, Code,
                    new SuccessCallback() {

                //验证验证码正确，重置密码
                @Override
                public void onSuccess(Object data) {
                    reset();
                }
            }, new FailCallback() {
                //验证码失败后，提示用户错误
                @Override
                public void onFail(Object data) {
                    customProgressDialog.dismiss();
                    Toast.makeText(ForgetPasswordActivity.this, "验证码错误", Toast.LENGTH_SHORT).show();
                }
            });
        }

    }

    private void reset() {
        //重置密码
        PersonService.reset(ForgetPasswordActivity.this, num, password, Config.PwdMode, Code, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                customProgressDialog.dismiss();
                Toast.makeText(ForgetPasswordActivity.this, "重置密码成功", Toast.LENGTH_SHORT).show();
                finish();//删除本页面
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                customProgressDialog.dismiss();
                int retcode = (int)object;
                String description = null;
                if (-5 == retcode){
                    description = "参数有误";
                }else if(-8 == retcode){
                    description = "验证码输入错误";
                }else if(-16 == retcode){
                    description = "验证码过期";
                }else{
                    description = "密码重置失败";
                }
                Toast.makeText(ForgetPasswordActivity.this, description, Toast.LENGTH_SHORT).show();
            }
        });
    }

    //复写倒计时
    private class MyCountDownTimer extends CountDownTimer {

        public MyCountDownTimer(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        //计时过程
        @Override
        public void onTick(long l) {
            //防止计时过程中重复点击
            btnGetCode.setClickable(false);
            btnGetCode.setText(l / 1000 + "s");

        }

        //计时完毕的方法
        @Override
        public void onFinish() {
            //重新给Button设置文字
            btnGetCode.setText("重新获取验证码");
            //设置可点击
            btnGetCode.setClickable(true);
        }
    }

}
