package com.changhong.changhongcare.oldprotocol.structFromService;


/**
 * author: henmory
 * time:  11/3/16
 * function:
 * description:
 */

public class SimpleDevicePos {
    private String deviceIMEI;
    private String deviceName;
    private String gpsTime;
    private double la;
    private double lo;
    private int num;
    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDeviceIMEI() {
        return deviceIMEI;
    }

    public void setDeviceIMEI(String deviceIMEI) {
        this.deviceIMEI = deviceIMEI;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getGpsTime() {
        return gpsTime;
    }

    public void setGpsTime(String gpsTime) {
        this.gpsTime = gpsTime;
    }

    public double getLa() {
        return la;
    }

    public void setLa(double la) {
        this.la = la;
    }

    public double getLo() {
        return lo;
    }

    public void setLo(double lo) {
        this.lo = lo;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    @Override
    public String toString() {
        return "SimpleDevicePos{" +
                "deviceIMEI='" + deviceIMEI + '\'' +
                ", deviceName='" + deviceName + '\'' +
                ", gpsTime='" + gpsTime + '\'' +
                ", la=" + la +
                ", lo=" + lo +
                ", num=" + num +
                ", type='" + type + '\'' +
                '}';
    }
}
