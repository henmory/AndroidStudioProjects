package com.changhong.changhongcare.activity;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.BounceInterpolator;
import android.view.animation.Interpolator;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationClientOption.AMapLocationMode;
import com.amap.api.location.AMapLocationListener;
import com.amap.api.maps2d.AMap;
import com.amap.api.maps2d.AMapOptions;
import com.amap.api.maps2d.CameraUpdateFactory;
import com.amap.api.maps2d.LocationSource;
import com.amap.api.maps2d.MapView;
import com.amap.api.maps2d.Projection;
import com.amap.api.maps2d.UiSettings;
import com.amap.api.maps2d.model.BitmapDescriptor;
import com.amap.api.maps2d.model.BitmapDescriptorFactory;
import com.amap.api.maps2d.model.Circle;
import com.amap.api.maps2d.model.LatLng;
import com.amap.api.maps2d.model.Marker;
import com.amap.api.maps2d.model.MarkerOptions;
import com.amap.api.services.core.LatLonPoint;
import com.amap.api.services.geocoder.GeocodeResult;
import com.amap.api.services.geocoder.GeocodeSearch;
import com.amap.api.services.geocoder.RegeocodeQuery;
import com.amap.api.services.geocoder.RegeocodeResult;
import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.adapter.DeviceItem;
import com.changhong.changhongcare.adapter.DeviceItemAdapter;
import com.changhong.changhongcare.customview.CustomAskUserDialog;
import com.changhong.changhongcare.customview.CustomMembershipDialog;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.newprotocol.service.DevicesService;
import com.changhong.changhongcare.newprotocol.service.PersonService;
import com.changhong.changhongcare.adapter.NavigationItem;
import com.changhong.changhongcare.adapter.NavigationItemAdapter;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.newprotocol.structfromserver.FuncBasicPosView;
import com.changhong.changhongcare.newprotocol.structfromserver.FuncPhoneView;
import com.changhong.changhongcare.utils.DisplayUtil;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;


public class AmapActivity extends AppCompatActivity implements LocationSource, AMapLocationListener, AMap.OnMarkerClickListener, GeocodeSearch.OnGeocodeSearchListener {

    private final static String TAG = "AmapActivity";

    //////////////////////////////////////界面相关////////////////////////////////////////////////////////////////
    private final static int TITLE_SIZE = 36;
    private final static int NAVIGATION_NAME_SIZE = 24;
    private final static int NAVIGATION_ITEM_SIZE = 50;

    private TextView tvTitle;//标题
    private Toolbar toolbar;//工具栏
    private ImageView ivDeviceList;//设备列表
    private List<NavigationItem> navigationItemList;//侧边栏项
    private ListView lv_navigation;
    private ActionBarDrawerToggle drawerToggle; //为actionbar设置的事件监听器
    private DrawerLayout mDrawerLayout; //整个布局
    private TextView tvUserName;//导航栏用户名称
    private ImageView ivUserImage;//用户头像
    private ClickEventHandler clickEventHandler = new ClickEventHandler();//处理界面的单击事件
    private ImageView ivPosition;
    private DeviceListDialog deviceListDialog;//设备列表对话框
    private DeviceParamDialog deviceParamDialog;//设备参数对话框

    private CustomProgressDialog customProgressDialog;//全局加载界面

    ///////////////////退出当前账号使用////////////////////////////
    private Handler handler;//处理activity,与界面更新复用
    private static final int MSG_DESTORY_AMAP_ACTIVITY = 0;
    public static AmapActivity mInstace = null;

    /////////////////界面更新相关////////////////
    private static final int MSG_RESRESH_AMAP_ACTIVITY = 1;
    private Timer timer;
    private TimerTask task;

    // 定义一个变量，来标识是否退出整个应用程序
    private static boolean isExit = false;
    private static final int MSG_RESET_CLOCK_ACTIVITY = 2;

    ////////////////////////////////////////高德地图相关变量////////////////////////////////////////////////////////////////
    public AMap getaMap() {
        return aMap;
    }

    private AMap aMap;
    private MapView mapView;
    private UiSettings mUiSettings;
    private OnLocationChangedListener mListener;
    private AMapLocationClient mlocationClient;
    private AMapLocationClientOption mLocationOption;
    private Circle mCircle;
    private boolean mFirstFix = false;
    private Marker mLocMarker;
    private String locationMessage; //点击位置图标显示的信息

    public static LatLng getMylocation() {
        return my_location;
    }

    private static LatLng my_location;//目前定位位置---点击定位时使用
    private GeocodeSearch geocoderSearch;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amap);
        customProgressDialog = new CustomProgressDialog(this);
        initToolBar();
//        initNavigation(); //不在这里初始化，在点击左上角图标时初始化
        ivPosition = (ImageView) findViewById(R.id.iv_position);
        ivPosition.setOnClickListener(clickEventHandler);
        mInstace = this;
        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case MSG_DESTORY_AMAP_ACTIVITY://点击退出当前账号，销毁amap activity
                        logout();
                        break;
                    case MSG_RESRESH_AMAP_ACTIVITY:
                        Log.d(TAG, "刷新主界面");

                        DevicesService.getBindDevicesPositionList(AmapActivity.this, Config.token, 1 +"", new SuccessCallback() {
                            @Override
                            public void onSuccess(Object object) {
                                Log.d(TAG, "getBindDevicesPositionList  onSuccess: ");
                                updateAmapActivity();//更新界面
                                changeBindDeviceLatLngToString();//更新设备位置信息
                            }
                        }, new FailCallback() {
                            @Override
                            public void onFail(Object object) {
                                Toast.makeText(AmapActivity.this, "数据获取失败", Toast.LENGTH_SHORT).show();
                            }
                        });
                        break;
                    case MSG_RESET_CLOCK_ACTIVITY:
                        isExit = false;
                        break;
                }
            }
        };


        //地图相关初始化
        mapView = (MapView) findViewById(R.id.map);
        mapView.onCreate(savedInstanceState);// 此方法必须重写
        init();


        //登陆成功后，获取绑定设备列表和位置信息.初始化地图完成后，在地图上标记设备位置
        showBindDevicesPositionOnAmap();

        //第一次进入app，引导用户绑定设备
        if (1 == Config.getFirst_enter_app(this, Config.KEY_FIRST_ENTRY_APP)){
            final CustomMembershipDialog customMembershipDialog = new CustomMembershipDialog(this, R.layout.custom_dialog_membership_tip);
            customMembershipDialog.setTitle("会员福利");
            customMembershipDialog.setOnNegativeListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    customMembershipDialog.dismiss();
                }
            });
            customMembershipDialog.setOnPositiveListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    customMembershipDialog.dismiss();
                    startActivity(new Intent(AmapActivity.this, BindDeviceActivity.class));
                }
            });
            customMembershipDialog.setCancelable(false);
            customMembershipDialog.show();
            Config.cacheFirst_enter_app(this, 0);//以后再也不会进入这里
        }

    }


    /**
     * @param
     * @return
     * @author henmory
     * @date 2/14/17
     * @description 当数据发生变化或者定时刷新界面
     */
    public void updateAmapActivity() {
        if (null != aMap) {
            aMap.clear();//清理地图标记

            //显示我的位置图标
            Bitmap bMap = BitmapFactory.decodeResource(this.getResources(),
                    R.drawable.my_location);
            BitmapDescriptor des = BitmapDescriptorFactory.fromBitmap(bMap);
            MarkerOptions options = new MarkerOptions();
            options.icon(des);
            options.anchor(0.5f, 1);
            options.position(my_location);
            options.title(null);//用id作为每个设备的区别
            options.draggable(true);
            aMap.addMarker(options);
            Log.d(TAG, "updateAmapActivity: ");
            showBindDevicesPositionOnAmap();//显示绑定设备
        }

    }

    /**
     * 初始化AMap对象
     */
    private void init() {
        if (aMap == null) {
            aMap = mapView.getMap();
            aMap.setOnMarkerClickListener(this);//添加点击我的位置监听器
            aMap.setLocationSource(this);// 设置定位监听
            aMap.setMyLocationEnabled(true);// 是否可触发定位并显示定位层
            mUiSettings = aMap.getUiSettings();

        }
        mUiSettings.setLogoPosition(AMapOptions.LOGO_POSITION_BOTTOM_CENTER);// 设置地图logo显示在底部居中
        mUiSettings.setScaleControlsEnabled(false);//设置地图默认的比例尺
        mUiSettings.setZoomControlsEnabled(true);//设置地图默认的缩放按钮
        mUiSettings.setCompassEnabled(false);//指南针
        mUiSettings.setMyLocationButtonEnabled(false); // 显示默认的定位按钮

        mUiSettings.setScrollGesturesEnabled(true);//手势滑动
        mUiSettings.setZoomGesturesEnabled(true);//手势放大缩小


        geocoderSearch = new GeocodeSearch(this);
        geocoderSearch.setOnGeocodeSearchListener(this);
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onResume() {
        Log.d(TAG, "amap resume");
        super.onResume();
        mapView.onResume();
        //初始化界面刷新时间,当界面处在最前面的适合开启定时器
        initRefreshTime();
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onPause() {
        Log.d(TAG, "amap pause");
        super.onPause();
        mapView.onPause();
        deactivate();
        mFirstFix = false;

        //与onresume相匹配
        task.cancel();
        timer.cancel();//amap不在最前面时，退出定时器
        task = null;
        timer = null;
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    @Override
    protected void onStop() {
        super.onStop();


    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }


    /**
     * 定位成功后回调函数
     */

    @Override
    public void onLocationChanged(AMapLocation amapLocation) {
        if (mListener != null && amapLocation != null) {
            if (amapLocation != null
                    && amapLocation.getErrorCode() == 0) {
                LatLng location = new LatLng(amapLocation.getLatitude(), amapLocation.getLongitude());
                my_location = location;
                if (!mFirstFix) {
                    mFirstFix = true;
//                    addCircle(location, amapLocation.getAccuracy());//添加定位精度圆
                    addMarker(location);//添加定位图标
                    locationMessage = amapLocation.getAddress();
                    System.out.println("我的位置: " + locationMessage);
//                    mSensorHelper.setCurrentMarker(mLocMarker);//定位图标旋转
                } else {
                    mCircle.setCenter(location);
                    mCircle.setRadius(amapLocation.getAccuracy());
                    mLocMarker.setPosition(location);
                }
                aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 13));
                changeBindDeviceLatLngToString();
            } else {
                String errText = "定位失败," + amapLocation.getErrorCode() + ": " + amapLocation.getErrorInfo();
                Log.e("AmapErr", errText);
            }
        }
    }

    /**
     * 激活定位
     */
    @Override
    public void activate(OnLocationChangedListener listener) {
        mFirstFix = false;
        mListener = listener;
        if (mlocationClient == null) {
            mlocationClient = new AMapLocationClient(this);
            mLocationOption = new AMapLocationClientOption();
            //设置定位监听
            mlocationClient.setLocationListener(this);
            //设置为高精度定位模式
            mLocationOption.setLocationMode(AMapLocationMode.Hight_Accuracy);
            //设置定位参数
            mlocationClient.setLocationOption(mLocationOption);
            // 此方法为每隔固定时间会发起一次定位请求，为了减少电量消耗或网络流量消耗，
            // 注意设置合适的定位时间的间隔（最小间隔支持为2000ms），并且在合适时间调用stopLocation()方法来取消定位请求
            // 在定位结束后，在合适的生命周期调用onDestroy()方法
            // 在单次定位情况下，定位无论成功与否，都无需调用stopLocation()方法移除请求，定位sdk内部会移除
            mlocationClient.startLocation();
        }
    }

    /**
     * 停止定位
     */
    @Override
    public void deactivate() {
        mListener = null;
        if (mlocationClient != null) {
            mlocationClient.stopLocation();
            mlocationClient.onDestroy();
        }
        mlocationClient = null;
    }

    public void addMarker(LatLng latlng) {
        if (mLocMarker != null) {
            return;
        }
        Bitmap bMap = BitmapFactory.decodeResource(this.getResources(),
                R.drawable.my_location);//显示我的位置图标
        BitmapDescriptor des = BitmapDescriptorFactory.fromBitmap(bMap);
        MarkerOptions options = new MarkerOptions();
        options.icon(des);
        options.anchor(0.5f, 1);
        options.position(latlng);
        options.title(Config.device_id);//用id作为每个设备的区别
        mLocMarker = aMap.addMarker(options);

    }

    /**
     * marker点击时跳动一下
     */
    public void jumpPoint(final Marker marker) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        Projection proj = aMap.getProjection();
        final LatLng markerLatlng = marker.getPosition();
        Point markerPoint = proj.toScreenLocation(markerLatlng);
        markerPoint.offset(0, -100);
        final LatLng startLatLng = proj.fromScreenLocation(markerPoint);
        final long duration = 1500;

        final Interpolator interpolator = new BounceInterpolator();
        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed
                        / duration);
                double lng = t * markerLatlng.longitude + (1 - t)
                        * startLatLng.longitude;
                double lat = t * markerLatlng.latitude + (1 - t)
                        * startLatLng.latitude;
                marker.setPosition(new LatLng(lat, lng));
                if (t < 1.0) {
                    handler.postDelayed(this, 16);
                }
            }
        });
    }

    /**
     * @param
     * @return
     * @author henmory
     * @date 11/25/16
     * @description 点击我的位置事件  如果是本机为imei，如果是绑定设备就是服务器分配的deviceID
     */

    @Override
    public boolean onMarkerClick(Marker marker) {
        if (aMap != null) {
            jumpPoint(marker);
        }
        //获取点击设备的标识
        String title = marker.getTitle();
        Log.d(TAG, "click device id = " + title);
        if (title == null) {//本机位置
            SharePositionDialog dialog = new SharePositionDialog(AmapActivity.this, locationMessage);
            dialog.show();
        } else {//绑定功能机位置
//            Log.d(TAG, "title = " + title);
            List<FuncPhoneView> basicPosViews = DevicesService.getDeviceList();
            String id = null;
            for (int i = 0; i < basicPosViews.size(); i++){
                if (title.equals(basicPosViews.get(i).getNick())){
                    id = basicPosViews.get(i).getId()+"";
                }
            }

            DeviceParamDialog deviceParamDialog = new DeviceParamDialog(AmapActivity.this, id);
            deviceParamDialog.show();
        }
        return true;
    }

    /**
     * 逆地理编码回调
     */

    //存储设备的位置字符串表示形式
    private void storeDevicePositionString(RegeocodeResult result) {
        List<FuncBasicPosView> positions = DevicesService.getDevicePositionList();//获取从服务器获取的设备列表
        RegeocodeQuery regeocodeQuery = result.getRegeocodeQuery();
        LatLonPoint latLonPoint = regeocodeQuery.getPoint();
        double lat = latLonPoint.getLatitude();
        double lon = latLonPoint.getLongitude();
        Log.d(TAG, "解析的位置为 la = " + lat + " ; lo = " + lon);
        Map<String, String> map = DevicesService.getMap();
        for (int i = 0; i < positions.size(); i++) {
            if (Math.abs(lat - positions.get(i).getLat()) < 0.000001
                    && Math.abs(lon - positions.get(i).getLng()) < 0.000001) {
                map.put(positions.get(i).getId() + "", result.getRegeocodeAddress().getFormatAddress());
                break;
            }
        }
        Log.d(TAG, "解析位置" + map.toString());
    }

    @Override
    public void onRegeocodeSearched(RegeocodeResult result, int rCode) {
        if (rCode == 1000) {
            if (result != null && result.getRegeocodeAddress() != null
                    && result.getRegeocodeAddress().getFormatAddress() != null) {
                storeDevicePositionString(result);

            } else {
                Log.d(TAG, "经纬度解码成字符串失败");
            }
        } else {
            Log.d(TAG, "经纬度解码成字符串失败");
        }
    }

    /**
     * 地理编码查询回调
     */
    @Override
    public void onGeocodeSearched(GeocodeResult geocodeResult, int i) {

    }

    //-----------------------------------高德地图以外的控件处理-----------------------------------------------------------

    int flag = 0;

    private void initLeftNavigation() {
        bindNavigationViews();
        initNavigationContent();
    }

    /**
     *  @author henmory
     *  @date 6/29/17
     *  @description 修改右侧导航栏内容为功能案件
     *
     *  @param
     *
     *  @return
    */
    private void initDeviceParam(final String nickName) {
        //不可添加，涉及网络请求，会出错
//        TextView onTime = (TextView) findViewById(R.id.tv_last_online_time);
//        onTime.setText("");
//        TextView time = (TextView) findViewById(R.id.tv_time);
//        time.setText("");
        TextView title = (TextView) findViewById(R.id.textView);
        title.setText(nickName);

        //要显示的数据
        String[] strs = {"足迹踏寻","亲情号码","定位模式","删除设备","修改设备名称"};
        //创建ArrayAdapter
        final ArrayAdapter<String> adapter = new ArrayAdapter<>
                (this,android.R.layout.simple_expandable_list_item_1,strs);
        //获取ListView对象，通过调用setAdapter方法为ListView设置Adapter设置适配器
        ListView list_test = (ListView) findViewById(R.id.lv_device);
        list_test.setAdapter(adapter);
        list_test.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mDrawerLayout.closeDrawers();//关闭导航栏

                //通过昵称获取设备id
                String device_id = null;
                List<FuncPhoneView> basic = DevicesService.getDeviceList();
                for (int i = 0; i <basic.size(); i++){
                    if (nickName.equals(basic.get(i).getNick())){
                        device_id = basic.get(i).getId() + "";
                    }
                }

                Intent intent = new Intent();
                switch (position){
                    case 0:
                        intent.setAction("android.intent.action.FOOTTRACE");
                        intent.putExtra(Config.KEY_DEVICE_ID, device_id);
                        startActivity(intent);
                        break;
                    case 1:
                        intent.setAction("android.intent.action.FAMILYNUMBERSETTING");
                        intent.putExtra(Config.KEY_DEVICE_ID, device_id);
                        startActivity(intent);
                        break;
                    case 2:
                        intent.setAction("android.intent.action.POSITIONMODE");
                        intent.putExtra(Config.KEY_DEVICE_ID, device_id);
                        startActivity(intent);
                        break;
                    case 3:
                        Log.d(TAG, "删除设备");
                        final CustomAskUserDialog dialog = new CustomAskUserDialog(AmapActivity.this);
                        dialog.setCanceledOnTouchOutside(false);
                        dialog.setCancelable(true);
                        dialog.setContent("确定删除设备?");
                        dialog.setOnNegativeListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });
                        dialog.setOnPositiveListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
//                                deleteDevice(v.getContext());
                            }
                        });
                        dialog.show();
                        break;
                    case 4:
                        intent.setAction("android.intent.action.DEVICENAMEMODIFY");
                        intent.putExtra(Config.KEY_DEVICE_ID, device_id);
                        startActivity(intent);
                        break;

                }
            }
        });

    }
    /**
     *  @author henmory
     *  @date 6/29/17
     *  @description 只显示设备列表
     *
     *  @param
     *
     *  @return
    */

    private void initRightNavigation() {
        //device list
        List<FuncPhoneView> deviceList = DevicesService.getDeviceList();
        Log.d(TAG, "initRightNavigation: deviceList = " + deviceList.toString());

//        TextView onTime = (TextView) findViewById(R.id.tv_last_online_time);
//        onTime.setText("");
//        TextView time = (TextView) findViewById(R.id.tv_time);
//        time.setText("");

        TextView title = (TextView) findViewById(R.id.textView);
        title.setText("设备列表");
        List<DeviceItem> deviceItems = new ArrayList<>();

        //显示设备名称和头像
        ListView lvDeviceItems = (ListView) findViewById(R.id.lv_device);
        deviceItems.clear();

        for (int i = 0; i < deviceList.size(); i++) {
            deviceItems.add(new DeviceItem(deviceList.get(i).getNick(), R.drawable.device_image, 0));
        }
        final DeviceItemAdapter adapter = new DeviceItemAdapter(deviceItems, getApplicationContext(), R.layout.list_item_device);
        lvDeviceItems.setAdapter(adapter);

        lvDeviceItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                initDeviceParam(adapter.getItem(position).getName());
            }
        });

    }

    /**
     * @param
     * @return
     * @author henmory
     * @date 12/7/16
     * @description 初始化导航栏
     */
    void initNavigation() {
        if (0 == flag) {
            initLeftNavigation();//初始化左侧导航栏
        } else {
            initRightNavigation();//初始化右侧导航栏
        }
    }

    void bindNavigationViews() {
        lv_navigation = (ListView) findViewById(R.id.drawer_setting);
        ivUserImage = (ImageView) findViewById(R.id.iv_user_account_image);
        tvUserName = (TextView) findViewById(R.id.tv_navigation_user_account_name);
    }

    void initNavigationContent() {
        //设置标题
        tvUserName.setText(Config.phoneNumber);//设置用户名
//        int frontSize = DisplayUtil.px2sp(AmapActivity.this, NAVIGATION_NAME_SIZE);
//        tvUserName.setTextSize(frontSize);

        //drawer设置
        navigationItemList = new ArrayList<>();
        navigationItemList.add(new NavigationItem(R.drawable.member_icon, "会员"));
        navigationItemList.add(new NavigationItem(R.drawable.add_device, "添加设备"));

//        navigationItemList.add(new NavigationItem(R.drawable.refresh, "位置更新频率"));
        navigationItemList.add(new NavigationItem(R.drawable.help, "帮助手册"));
        navigationItemList.add(new NavigationItem(R.drawable.exit, "退出当前账号"));
        int tap = DisplayUtil.px2dip(AmapActivity.this, NAVIGATION_ITEM_SIZE);
        lv_navigation.setDividerHeight(tap);
        NavigationItemAdapter adapter = new NavigationItemAdapter(navigationItemList, AmapActivity.this, R.layout.list_item_navigation);
        lv_navigation.setAdapter(adapter);
        lv_navigation.setOnItemClickListener(clickEventHandler);
        ivUserImage.setOnClickListener(clickEventHandler);
    }


    /**
     * @param
     * @return
     * @author henmory
     * @date 12/7/16
     * @description 初始化工具栏
     */
    void initToolBar() {

        bindToolBarViews();//绑定视图
        setSupportActionBar(toolbar);//工具栏设置
        toolbar.setNavigationIcon(R.drawable.main_setting);//设置工具栏图标
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        //初始化标题
        initTitle();
        //设置标题点击事件
        tvTitle.setOnClickListener(clickEventHandler);

        //标题栏图标单击事件设置
        drawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.open, R.string.close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                initNavigation();
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                //关闭的为右边侧栏
                if (1 == flag){
                    initRightNavigation();
                    flag = 0;
                }
            }
        };
//        drawerToggle.syncState();
        mDrawerLayout.addDrawerListener(drawerToggle);//设置监听
        //菜单按钮开启drawable
        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.menu_right_drawer:
                        flag = 1;
                        mDrawerLayout.openDrawer(GravityCompat.END);
                        break;
                }
                return false;
            }
        });
    }

    void bindToolBarViews() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        tvTitle = (TextView) findViewById(R.id.tv_title);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout); //整个布局的id
    }

    void initTitle() {
        tvTitle.setText("长虹关爱");//默认标题
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        drawerToggle.onConfigurationChanged(newConfig);
    }
    /**
     * @param
     * @author henmory
     * @date 12/7/16
     * @description 导航栏和工具栏点击事件处理类
     * @return
     */

    private class ClickEventHandler implements View.OnClickListener, AdapterView.OnItemClickListener {

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.iv_position://自定义定位我的位置，高德地图默认位置在右上角
                    aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(my_location, 13));
                    break;
                case R.id.tv_title://点击标题进入设备列表对话框
//                    deviceListDialog =  new DeviceListDialog(AmapActivity.this);
//                    deviceListDialog.show();
                    break;
                case R.id.iv_user_account_image://点击用户图标，进入用户信息
                    mDrawerLayout.closeDrawers();

                    startActivity(new Intent(AmapActivity.this, UserAccountActivity.class));
                    break;
                default:
            }

        }

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            mDrawerLayout.closeDrawers();
            switch (position) {
                case 0://钱包
                    startActivity(new Intent(AmapActivity.this,MyWalletActivity.class));
                    break;
                case 1://添加设备
                    startActivity(new Intent(AmapActivity.this, AddDeviceActivity.class));
                    break;
//                case 1://设置位置更新频率
//                    startActivity(new Intent(AmapActivity.this, UpdateTimeActivity.class));
//                    break;
//                case 1://进入设置界面
//                    startActivity(new Intent(AmapActivity.this, SettingActivity.class));
//                    break;
                case 2://帮助手册
                    startActivity(new Intent(AmapActivity.this, HelpActivity.class));
                    break;
                case 3://退出当前账号
                    exitCurrentAccount();
                    break;
            }

        }

    }

    private void fromMainToLogin() {
        mInstace.startActivity(new Intent(AmapActivity.this, LoginActivity.class));
        Config.cachePhoneNumber(AmapActivity.this, null);
        Config.cachePassword(AmapActivity.this, null);
        Config.cacheToken(AmapActivity.this, null);
        mInstace.finish();
        customProgressDialog.dismiss();
    }

    private void logout() {
        PersonService.logout(AmapActivity.this, Config.token, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                fromMainToLogin();
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                fromMainToLogin();
            }
        });
    }

    /**
     * @param
     * @return
     * @author henmory
     * @date 12/8/16
     * @description 退出当前账户，目前没有跟服务器交互
     */

    private void exitCurrentAccount() {

        final CustomAskUserDialog dialog = new CustomAskUserDialog(AmapActivity.this);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(true);
        dialog.setContent("确定退出当前账户?");
        dialog.setOnNegativeListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.setOnPositiveListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("sure");
                dialog.dismiss();
                Message message = Message.obtain();
                message.what = MSG_DESTORY_AMAP_ACTIVITY;
                message.setTarget(handler);
                handler.sendMessage(message);
                customProgressDialog.setMessage("正在退出...");
                customProgressDialog.show();
            }
        });
        dialog.show();
    }

    //登陆成功后，获取绑定设备列表和位置信息.初始化地图完成后，在地图上标记设备位置
    public void showBindDevicesPositionOnAmap() {

        List<FuncBasicPosView> positions = DevicesService.getDevicePositionList();
        List<FuncPhoneView> deviceList = DevicesService.getDeviceList();
        LatLng location;
        MarkerOptions options = new MarkerOptions();
        Marker marker = null;
        Log.d(TAG, "showBindDevicesPositionOnAmap: position = " + positions.toString());
        for (int i = 0; i < positions.size(); i++) {
            location = new LatLng(positions.get(i).getLat(), positions.get(i).getLng());
            int icon_id = 0;
            // TODO: 6/30/17 区分是否为在线设备
            if (positions.get(i).getStatus() == 1){//设备在线   
                icon_id = R.drawable.bind_device_position_big;
            }else{
                icon_id = R.drawable.bind_device_position_big;
            }
            Bitmap bMap = BitmapFactory.decodeResource(this.getResources(), icon_id);//显示绑定设备的位置图标
            BitmapDescriptor des = BitmapDescriptorFactory.fromBitmap(bMap);

            options.icon(des);
            options.anchor(0.5f, 1);
            options.position(location);
            options.draggable(true);

            long id = positions.get(i).getId();
            for (int j = 0; j < deviceList.size(); j++) {
                if (deviceList.get(j).getId() == id) {
                    options.title(deviceList.get(j).getNick());//设置标题
                    Log.d(TAG, "showBindDevicesPositionOnAmap: title = " + options.getTitle());
                }
            }

            marker = aMap.addMarker(options);
        }
//        marker.showInfoWindow();

        Log.d(TAG, "showBindDevicesPositionOnAmap");
    }

    //通过设备的经纬度，上传高德，获取位置字符串表示形式
    //onRegeocodeSearched为回调函数
    public void changeBindDeviceLatLngToString() {
        List<FuncBasicPosView> positions = DevicesService.getDevicePositionList();
        ;//获取从服务器获取的设备列表
        for (int i = 0; i < positions.size(); i++) {
            Log.d(TAG, "解析绑定设备的位置 la = " + positions.get(i).getLat() + "; lo = " + positions.get(i).getLng());
            changePositionLatLngToString(new LatLng(positions.get(i).getLat(), positions.get(i).getLng()));
        }
    }

    //通过设备的经纬度，上传高德，获取位置字符串表示形式
    private void changePositionLatLngToString(LatLng latLng) {
        LatLonPoint latLonPoint = new LatLonPoint(latLng.latitude, latLng.longitude);
        RegeocodeQuery query = new RegeocodeQuery(latLonPoint, 200,
                GeocodeSearch.AMAP);// 第一个参数表示一个Latlng，第二参数表示范围多少米，第三个参数表示是火系坐标系还是GPS原生坐标系
        geocoderSearch.getFromLocationAsyn(query);// 设置同步逆地理编码请求
    }

    //初始化界面刷新时间，开启定时器刷新界面
    private void initRefreshTime() {
        Log.d(TAG, "初始定时器");
        int index = Config.refresh_index;
        int time;
        switch (index) {
            case 0:
                time = 10;
                break;
            case 1:
                time = 30;
                break;
            case 2:
                time = 60;
                break;
            default:
                time = 60;
        }

        if (null == task) {
            task = new TimerTask() {
                @Override
                public void run() {
                    Log.d(TAG, "run");
                    sendUpdateAmapMessage();
                }
            };
        }

        Log.d(TAG, "time = " + time + "");
        if (null == timer) {
            timer = new Timer();
        }

        timer.schedule(task, time * 1000, time * 1000);

    }

    public void sendUpdateAmapMessage() {
        Message message = Message.obtain();
        message.what = MSG_RESRESH_AMAP_ACTIVITY;
        message.setTarget(handler);
        handler.sendMessage(message);
    }

    //退出整个应用程序
    private void exit() {
        if (!isExit) {
            isExit = true;
            Toast.makeText(getApplicationContext(), "再按一次退出程序",
                    Toast.LENGTH_SHORT).show();
            // 利用handler延迟发送更改状态信息
            handler.sendEmptyMessageDelayed(MSG_RESET_CLOCK_ACTIVITY, 2000);
        } else {
            finish();
            System.exit(0);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            exit();
            return false;
        }
        return super.onKeyDown(keyCode, event);
    }
}

