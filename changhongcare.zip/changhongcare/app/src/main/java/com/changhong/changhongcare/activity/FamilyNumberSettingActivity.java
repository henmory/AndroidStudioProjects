package com.changhong.changhongcare.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.adapter.FamilyNumItem;
import com.changhong.changhongcare.adapter.FamilyNumberItemAdapter;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.customview.CustomAskUserDialog;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.newprotocol.structfromserver.FuncFamNumView;
import com.changhong.changhongcare.newprotocol.service.DevicesService;
import java.util.ArrayList;
import java.util.List;

public class FamilyNumberSettingActivity extends AppCompatActivity {
    private static final String TAG = "FamilyNumSettActivity";


    private ListView listViews;//亲情号码显示控件
    private FamilyNumberItemAdapter adapter; //适配器
    private List<FamilyNumItem> familyNumItems = new ArrayList<>();//填充adapter数据
    private List<FuncFamNumView> familyNumbers = new ArrayList<>(); //服务器返回的亲情号码数据
    private String deviceID;//设备id，通过id向服务器请求亲情号码
    private TextView tel;
    private ImageView ivAddTel;//添加动作控件
    private EditText edAddTel;//编辑新添加号码控件


    private Handler handler;//用户选择确定删除亲情号码后处理事件
    private static final int MSG_DELETE_FAMILY_NUM = 0;//删除亲情号码事件
    private int select_index;

    private CustomProgressDialog customProgressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_family_number_setting);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        bindViews();

        initData();
        //处理删除亲情号码逻辑
        handler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                switch(msg.what){
                    case MSG_DELETE_FAMILY_NUM://点击确定，删除亲情号码
                        deleteFamilyNumber();
                        break;
                }
            }
        };

    }

    void bindViews(){
        customProgressDialog = new CustomProgressDialog(FamilyNumberSettingActivity.this);
        listViews = (ListView) findViewById(R.id.lv_family_num);
        tel = (TextView) findViewById(R.id.tv_family_num_description);
        edAddTel = (EditText) findViewById(R.id.et_add_family_num);
        ivAddTel = (ImageView) findViewById(R.id.iv_add_family_num);
        ivAddTel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addFamilyNumber();
            }
        });
    }

    void initData() {

        //从前一个activity中获取deviceID
        Intent intent = getIntent();
        deviceID = intent.getStringExtra(Config.KEY_DEVICE_ID);

//        从服务器获取心跳间隔
        customProgressDialog.setMessage("数据获取中，请稍后");
        customProgressDialog.show();
        DevicesService.getFamilyNumberList(FamilyNumberSettingActivity.this, Config.token, deviceID+"", new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                familyNumbers = DevicesService.getDeviceFamNumList();
                initViews(familyNumbers);
                customProgressDialog.dismiss();
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                initViews(familyNumbers);
                customProgressDialog.dismiss();
                Toast.makeText(FamilyNumberSettingActivity.this, object.toString(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    void initViews(List<FuncFamNumView> familyNumbers){

        //添加listview数据
        for (int i = 0; i < familyNumbers.size(); i++){
            familyNumItems.add(new FamilyNumItem(familyNumbers.get(i).getPhone(), R.drawable.delete_family_num));
        }

        adapter = new FamilyNumberItemAdapter(familyNumItems, FamilyNumberSettingActivity.this, R.layout.list_item_family_num);
        listViews.setAdapter(adapter);

        //删除亲情号码
        listViews.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                select_index = position;
                checkIfDeleteFamilyNumber();
            }
        });
    }

    //获取上传亲情号码的索引，以1开始
    int getFamilyIndex(){
        int index = 1;
        boolean ok = true;
        while(ok){
            for (int i = 0; i < familyNumbers.size(); i++){
                if (index == familyNumbers.get(i).getSeq()){
                    index++;
                }
            }
            ok = false;
        }

        return index;
    }


    //弹出对话框让用户选择
    void checkIfDeleteFamilyNumber(){
        final CustomAskUserDialog dialog = new CustomAskUserDialog(FamilyNumberSettingActivity.this);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(true);
        dialog.setContent("确实删除亲情号码?");
        dialog.setOnNegativeListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.setOnPositiveListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Message message = Message.obtain();
                message.what = MSG_DELETE_FAMILY_NUM;
                message.setTarget(handler);
                handler.sendMessage(message);
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    /**
     *  @author henmory
     *  @date 1/10/17
     *  @description 获取用户选择亲情号码信息, 如果找不到数据返回null
     *
     *  @param
     *
     *  @return
    */

    FuncFamNumView getDeleteFamilyNumContent(int index){
        //通过index在listview中找到电话号码
        String  num = familyNumItems.get(index).getDescription();

        //通过电话号码找到在服务器中的记录
        for (int i = 0; i < familyNumbers.size(); i++){
            if (num.equals(familyNumbers.get(i).getPhone())){
                return familyNumbers.get(i);
            }
        }
        return null;
    }

    void addFamilyNumber(){
        String tel = edAddTel.getText().toString();
        if (tel.length() > 0 ){
            final FuncFamNumView target = new FuncFamNumView();
            target.setName("亲情号码" + (familyNumbers.size() + 1));//昵称
            int index = getFamilyIndex();
//            target.setSeqNum(familyNumbers.size() + 1);
            target.setSeq(index);
            target.setPhone(tel);
            long id = Long.parseLong(deviceID);
            target.setDevID(id);
            Log.d(TAG, "添加的亲情号码为" + target.toString());

            for (int i = 0; i < familyNumbers.size(); i++){
                if (tel.equals(familyNumbers.get(i).getPhone())){
                    Toast.makeText(FamilyNumberSettingActivity.this, "亲情号码已存在", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            customProgressDialog.setMessage("亲情号码添加中，请稍后");
            customProgressDialog.show();

            DevicesService.addFamilyNumber(FamilyNumberSettingActivity.this, Config.token, target,
                    new SuccessCallback() {
                        @Override
                        public void onSuccess(Object object) {
                            customProgressDialog.dismiss();
                            Toast.makeText(FamilyNumberSettingActivity.this, "添加成功", Toast.LENGTH_SHORT).show();
                            addFamilyNumberSuccessufllyUpdateView();
                            addFamilyNumberSuccessufllyUpdateRam(target);

                        }
                    }, new FailCallback() {
                        @Override
                        public void onFail(Object object) {
                            customProgressDialog.dismiss();
                            Toast.makeText(FamilyNumberSettingActivity.this, "添加失败", Toast.LENGTH_SHORT).show();
                        }
                    });

        }else{
            Toast.makeText(FamilyNumberSettingActivity.this, "请输入电话号码", Toast.LENGTH_SHORT).show();
        }
    }

    //删除亲情号码
    void deleteFamilyNumber(){
        final FuncFamNumView number = getDeleteFamilyNumContent(select_index);

        if (number != null){
            Log.d(TAG,"删除的亲情号码为:" + number.toString());

            customProgressDialog.setMessage("删除中，请稍后");

            customProgressDialog.show();

            DevicesService.deleteFamilyNumber(FamilyNumberSettingActivity.this, Config.token, number.getDevID()+"", number.getSeq(),
                    new SuccessCallback() {
                        @Override
                        public void onSuccess(Object object) {
                            customProgressDialog.dismiss();
                            Toast.makeText(FamilyNumberSettingActivity.this, "删除亲情号码成功!", Toast.LENGTH_SHORT).show();
                            deleteFamilyNumberSuccessufllyUpdateView(number);
                            deleteFamilyNumberSuccessufllyUpdateRam(number);
                        }
                    }, new FailCallback() {
                        @Override
                        public void onFail(Object object) {
                            customProgressDialog.dismiss();
                            Toast.makeText(FamilyNumberSettingActivity.this, "删除亲情号码失败!", Toast.LENGTH_SHORT).show();
                        }
                    });

        }else{
            Toast.makeText(FamilyNumberSettingActivity.this, "删除亲情号码失败!", Toast.LENGTH_SHORT).show();
        }
    }
    //添加成功后更新界面
    void addFamilyNumberSuccessufllyUpdateView(){
        FamilyNumItem item = new FamilyNumItem(edAddTel.getText().toString(), R.drawable.delete_family_num);
        adapter.add(item);
        edAddTel.setText("");
    }
    //添加成功后更新更新ram数据
    void addFamilyNumberSuccessufllyUpdateRam(FuncFamNumView number){
        familyNumbers.add(number);
    }
    //删除成功后更新界面
    void deleteFamilyNumberSuccessufllyUpdateView(FuncFamNumView number){
        Log.d(TAG, "界面上删除的数据:" + number.toString());
        for (int i = 0; i < familyNumItems.size(); i++){
            if (number.getPhone().equals(familyNumbers.get(i).getPhone())){
                adapter.delete(familyNumItems.get(i));
            }
        }
        edAddTel.setText("");
    }
    //删除成功后更新更新ram数据
    void deleteFamilyNumberSuccessufllyUpdateRam(FuncFamNumView number){
        familyNumbers.remove(number);
    }

}
