package com.changhong.changhongcare.activity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;

import com.alipay.sdk.app.PayTask;
import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.newprotocol.service.PayService;
import com.changhong.changhongcare.pay.alipay.PayResult;
import com.changhong.changhongcare.pay.alipay.struct.AlipayResultParam;
import com.changhong.changhongcare.pay.alipay.struct.PayParam;

import java.util.Map;

public class TopUpActivity extends AppCompatActivity {

    private static final String tag = "TopUpActivity";
    private PayParam payParam = new PayParam(0+"",0,0.01,1);
    private RadioButton rb_alipay; //阿里支付按钮
    private RadioButton rb_wechat; //微信支付按钮
    private Button btn_top_up; //充值

    private LinearLayout ll1;
    private LinearLayout ll2;
    private LinearLayout ll3;
    private LinearLayout ll4;
    private LinearLayout ll5;
    private LinearLayout ll6;

    private static final int MSG_PAY_RESULT = 1;

    Button btn;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_PAY_RESULT: {
                    @SuppressWarnings("unchecked")
                    PayResult payResult = new PayResult((Map<String, String>) msg.obj);
                    Log.d(tag, "alipay result = " + payResult.toString());
                    /**
                     对于支付结果，请商户依赖服务端的异步通知结果。同步通知结果，仅作为支付结束的通知。
                     */
                    String resultInfo = payResult.getResult();// 同步返回需要验证的信息
                    Log.d(tag, resultInfo);
                    String resultStatus = payResult.getResultStatus();
                    // 判断resultStatus 为9000则代表支付成功
                    if (TextUtils.equals(resultStatus, "9000")) {
                        // 该笔订单是否真实支付成功，需要依赖服务端的异步通知。
                        Toast.makeText(TopUpActivity.this, "支付成功", Toast.LENGTH_SHORT).show();

                    } else {
                        // 该笔订单真实的支付结果，需要依赖服务端的异步通知。
                        Toast.makeText(TopUpActivity.this, "支付失败", Toast.LENGTH_SHORT).show();
                    }

                    //client pays free successfully, and return to result to server
                    notifyServer(payResult);
                    break;
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_up);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        bindViews();
        initDatas();
        bindEvents();

    }

    private void bindViews() {
        btn_top_up = (Button) findViewById(R.id.btn_topup);
        rb_alipay = (RadioButton) findViewById(R.id.rb_alipay);
        rb_wechat = (RadioButton) findViewById(R.id.rb_wechat);

        ll1 = (LinearLayout) findViewById(R.id.ll1);
        ll2 = (LinearLayout) findViewById(R.id.ll2);
        ll3 = (LinearLayout) findViewById(R.id.ll3);
        ll4 = (LinearLayout) findViewById(R.id.ll4);
        ll5 = (LinearLayout) findViewById(R.id.ll5);
        ll6 = (LinearLayout) findViewById(R.id.ll6);

    }

    private void initDatas() {

    }

    private void bindEvents() {

        ll1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ll1.setBackgroundResource(R.drawable.top_up_sum_select);
                ll2.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll3.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll4.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll5.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll6.setBackgroundResource(R.drawable.top_up_sum_unselect);
                payParam.setAmount(0.01);
            }
        });
        ll2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ll2.setBackgroundResource(R.drawable.top_up_sum_select);
                ll1.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll3.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll4.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll5.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll6.setBackgroundResource(R.drawable.top_up_sum_unselect);
                payParam.setAmount(0.01);
            }
        });
        ll3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ll3.setBackgroundResource(R.drawable.top_up_sum_select);
                ll2.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll1.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll4.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll5.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll6.setBackgroundResource(R.drawable.top_up_sum_unselect);
                payParam.setAmount(0.01);

            }
        });
        ll4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ll4.setBackgroundResource(R.drawable.top_up_sum_select);
                ll2.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll3.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll1.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll5.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll6.setBackgroundResource(R.drawable.top_up_sum_unselect);
                payParam.setAmount(0.01);

            }
        });
        ll5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ll5.setBackgroundResource(R.drawable.top_up_sum_select);
                ll2.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll3.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll4.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll1.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll6.setBackgroundResource(R.drawable.top_up_sum_unselect);
                payParam.setAmount(0.01);

            }
        });
        ll6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ll6.setBackgroundResource(R.drawable.top_up_sum_select);
                ll2.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll3.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll4.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll5.setBackgroundResource(R.drawable.top_up_sum_unselect);
                ll1.setBackgroundResource(R.drawable.top_up_sum_unselect);
//                startActivity(new Intent(TopUpActivity.this, )); // TODO: 5/24/17 添加其他界面
            }
        });

        //支付宝支付发生变化
        rb_alipay.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //支付宝支付
                if (isChecked) {
                    rb_wechat.setChecked(false);
                    payParam.setChannel(0+"");

                }
            }
        });

        //微信支付发生变化
        rb_wechat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //微信支付
                if (isChecked) {
                    rb_alipay.setChecked(false);
                    payParam.setChannel(1+"");
                }
            }
        });

        //开始支付
        btn_top_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PayService.pay(TopUpActivity.this, Config.token, payParam, new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        Log.d(tag, object.toString());
                        pay((String) object);


                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        Log.d(tag, object.toString());
                        Toast.makeText(TopUpActivity.this, object.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }



    private void pay(final String orderInfo) {
        Runnable payRunnable = new Runnable() {

            @Override
            public void run() {
                PayTask alipay = new PayTask(TopUpActivity.this);
                Map<String, String> result = alipay.payV2(orderInfo, true);
                Log.i(tag, result.toString());

                Message msg = new Message();
                msg.what = MSG_PAY_RESULT;
                msg.obj = result;
                mHandler.sendMessage(msg);
            }
        };

        Thread payThread = new Thread(payRunnable);
        payThread.start();
    }

    private void notifyServer(PayResult payResult) {
        AlipayResultParam alipayResultParam = new AlipayResultParam(payResult.getMemo(), payResult.getResult(), payResult.getResultStatus());
        Log.d(tag, "notifyServer: " + alipayResultParam.toString());
        PayService.payNotifyServer(TopUpActivity.this, Config.token, alipayResultParam, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(tag, "onSuccess: " + object.toString());
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d(tag, "onFail: " + object.toString());
            }
        });


    }




}
