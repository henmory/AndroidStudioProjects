package com.changhong.changhongcare.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.changhong.changhongcare.R;
import com.changhong.changhongcare.activity.DeviceListDialog;
import com.changhong.changhongcare.utils.CommonAdapter;
import com.changhong.changhongcare.utils.CommonViewHolder;

import java.util.List;

/**
 * author: henmory
 * time:  12/6/16
 * function:
 * description:
 */

public class DeviceItemAdapter extends CommonAdapter<DeviceItem>{
    private final static String TAG = "DeviceItemAdapter";


    public DeviceItemAdapter(List<DeviceItem> mDatas, Context mContext, int mItemLayout) {
        super(mDatas, mContext, mItemLayout);
    }

    @Override
    public void convert(final CommonViewHolder holder, DeviceItem deviceItem) {

        holder.setText(R.id.tv_device_item_name, deviceItem.getName());
        holder.setImageResource(R.id.iv_device_item_image,deviceItem.getIcon());
        holder.setImageResource(R.id.iv_device_item_delete_image, deviceItem.getOperation());
//        holder.setOnClickListener(R.id.iv_device_item_delete_image, new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                TextView tvName = (TextView) holder.getView(R.id.tv_device_item_name);
//                DeviceListDialog.deleteDevice(tvName.getText().toString());
//            }
//        });


    }

}
