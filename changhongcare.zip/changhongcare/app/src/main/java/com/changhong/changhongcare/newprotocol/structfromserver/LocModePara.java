package com.changhong.changhongcare.newprotocol.structfromserver;

/**
 * author: henmory
 * time:  6/26/17
 * function:
 * description:
 */

public class LocModePara {
    private long id;
    private int locMode;

    public LocModePara(long id, int locMode) {
        this.id = id;
        this.locMode = locMode;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getLocMode() {
        return locMode;
    }

    public void setLocMode(int locMode) {
        this.locMode = locMode;
    }
}
