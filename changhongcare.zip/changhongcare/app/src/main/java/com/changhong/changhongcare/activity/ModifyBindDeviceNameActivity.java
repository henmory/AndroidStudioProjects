package com.changhong.changhongcare.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.R;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.customview.CustomProgressDialog;
import com.changhong.changhongcare.newprotocol.service.DevicesService;
import com.changhong.changhongcare.newprotocol.structfromserver.FuncPhoneView;
import com.changhong.changhongcare.newprotocol.structfromserver.NickSetParam;

import java.util.List;

public class ModifyBindDeviceNameActivity extends AppCompatActivity {

    private EditText etNewDeviceName;
    private Button btnModify;
    private CustomProgressDialog customProgressDialog;
    private String deviceID;//设备id，通过id向服务器请求nickname

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_bind_device_name);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initDatas();
        bindViews();
    }
    void initDatas() {

        //从前一个activity中获取deviceID
        Intent intent = getIntent();
        deviceID = intent.getStringExtra(Config.KEY_DEVICE_ID);
    }
    private void bindViews() {
        etNewDeviceName = (EditText) findViewById(R.id.et_new_name);
        btnModify = (Button) findViewById(R.id.btn_modify);
        btnModify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etNewDeviceName.getText().toString();
                if (TextUtils.isEmpty(name)) {
                    Toast.makeText(ModifyBindDeviceNameActivity.this, "设备名称不能为空", Toast.LENGTH_SHORT).show();
                } else {
                    customProgressDialog = new CustomProgressDialog(ModifyBindDeviceNameActivity.this, "名称修改中...");
                    customProgressDialog.show();

                    NickSetParam nickSetParam = new NickSetParam(Long.parseLong(deviceID), name);
                    DevicesService.updateDeviceNickname(ModifyBindDeviceNameActivity.this, Config.token, nickSetParam,
                            new SuccessCallback() {
                                @Override
                                public void onSuccess(Object object) {
                                    customProgressDialog.dismiss();
                                    Toast.makeText(ModifyBindDeviceNameActivity.this, "设备名称修改成功", Toast.LENGTH_SHORT).show();
                                    updateLoaclDatas();
                                    finish();
                                }
                            }, new FailCallback() {
                                @Override
                                public void onFail(Object object) {
                                    customProgressDialog.dismiss();
                                    Toast.makeText(ModifyBindDeviceNameActivity.this, "设备名称修改失败", Toast.LENGTH_SHORT).show();
                                }
                            });
                }
            }
        });
    }


    private void updateLoaclDatas(){
        List<FuncPhoneView> deviceList = DevicesService.getDeviceList();
        for (int i = 0; i < deviceList.size(); i++) {
            if (deviceID.equals(deviceList.get(i).getId() + "")){
                deviceList.get(i).setNick(etNewDeviceName.getText().toString());
            }

        }
    }

}
