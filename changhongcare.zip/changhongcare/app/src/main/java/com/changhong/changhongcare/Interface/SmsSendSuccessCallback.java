package com.changhong.changhongcare.Interface;

/**
 * author: henmory
 * time:  2/13/17
 * function:
 * description:
 */

public interface SmsSendSuccessCallback {
    void onSucess();
}
