package com.changhong.changhongcare.newprotocol.structfromserver;

/**
 * author: henmory
 * time:  6/21/17
 * function:
 * description:
 */

public class FuncPhoneView {
    private long id; //设备id
    private String nick; //设备昵称
    private int type;//设备类型
    private String imei;//imei

    public FuncPhoneView() {
    }

    public FuncPhoneView(long id, String nick, int type, String imei) {
        this.id = id;
        this.nick = nick;
        this.type = type;
        this.imei = imei;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    @Override
    public String toString() {
        return "FuncPhoneView{" +
                "id=" + id +
                ", nick='" + nick + '\'' +
                ", type=" + type +
                ", imei='" + imei + '\'' +
                '}';
    }
}
