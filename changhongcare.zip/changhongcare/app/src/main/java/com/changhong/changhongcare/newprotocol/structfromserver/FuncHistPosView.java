package com.changhong.changhongcare.newprotocol.structfromserver;

/**
 * author: henmory
 * time:  6/26/17
 * function:
 * description:
 */

public class FuncHistPosView {

    private long deviceId;// 设备ID
    private double lat;//纬度
    private double lng;//经度
    private String gpsTime;//定位时间
    private int satelliteNum;//卫星个数
    private int gsm;//信号强度
    private int power;//电量
    private int pointed;//定位模式
    private int status ;//状态
    private String alarm;//报警
    private int speed;//速度

    public FuncHistPosView() {
    }

    public FuncHistPosView(long deviceId, double lat, double lng, String gpsTime, int satelliteNum, int gsm, int power, int pointed, int status, String alarm, int speed) {
        this.deviceId = deviceId;
        this.lat = lat;
        this.lng = lng;
        this.gpsTime = gpsTime;
        this.satelliteNum = satelliteNum;
        this.gsm = gsm;
        this.power = power;
        this.pointed = pointed;
        this.status = status;
        this.alarm = alarm;
        this.speed = speed;
    }


    public long getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(long deviceId) {
        this.deviceId = deviceId;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public String getGpsTime() {
        return gpsTime;
    }

    public void setGpsTime(String gpsTime) {
        this.gpsTime = gpsTime;
    }

    public int getSatelliteNum() {
        return satelliteNum;
    }

    public void setSatelliteNum(int satelliteNum) {
        this.satelliteNum = satelliteNum;
    }

    public int getGsm() {
        return gsm;
    }

    public void setGsm(int gsm) {
        this.gsm = gsm;
    }

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public int getPointed() {
        return pointed;
    }

    public void setPointed(int pointed) {
        this.pointed = pointed;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getAlarm() {
        return alarm;
    }

    public void setAlarm(String alarm) {
        this.alarm = alarm;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    @Override
    public String toString() {
        return "FuncHistPosView{" +
                "deviceId=" + deviceId +
                ", lat=" + lat +
                ", lng=" + lng +
                ", gpsTime='" + gpsTime + '\'' +
                ", satelliteNum=" + satelliteNum +
                ", gsm=" + gsm +
                ", power=" + power +
                ", pointed=" + pointed +
                ", status=" + status +
                ", alarm='" + alarm + '\'' +
                ", speed=" + speed +
                '}';
    }
}
