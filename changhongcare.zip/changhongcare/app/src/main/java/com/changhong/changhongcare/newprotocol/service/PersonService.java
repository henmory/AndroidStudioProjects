package com.changhong.changhongcare.newprotocol.service;

import android.content.Context;
import android.util.Log;

import com.changhong.changhongcare.Interface.FailCallback;
import com.changhong.changhongcare.Interface.SuccessCallback;
import com.changhong.changhongcare.appconfig.Config;
import com.changhong.changhongcare.newprotocol.okhttp.ServerConfig;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * author: henmory
 * time:  11/22/16
 * function:
 * description:
 *              该文件所有数据已经判断操作正确还说错误，如果正确，直接解析data里面的数据，如果错误，按照下面说法做
 *              该文件接口处理所有返回的状态码和数据
 *              正确：投递所有数据内容,给界面层
 *              失败：返回错误码，并由界面层判断错误码更改相应逻辑或者直接提示用户
 */

public class PersonService {

    private final static String tag = "PersonService";
    private static ServiceInterface serviceInterface = new ServiceInterface();


    public final static String KEY_SESSION_ID = "sessionId";
    public final static String KEY_TOKEN = "Token";
    private static final  String KEY_EXTRA = "Extra";
    private static final String KEY_USERBASE = "UserBase";
    private static final String KEY_SERVICEDEADLINE = "ServiceDeadline";

    public final static String KEY_DADA = "Data";
    public final static String KEY_REQ_ID = "reqId";
    public final static String KEY_PHONE_NUM = "Username";
    public final static String KEY_NUM = "Name";
    public final static String KEY_LOGIN_TYPE = "LoginType";
    public final static String KEY_TYPE = "Type";
    public final static String KEY_VERIFICATION_CODE = "VerifyCode";
    public final static String KEY_GRAPHIC_VERIFICATION_CODE = "gphCode";
    public final static String KEY_CURRENT_PASSWORD = "CurPwd";
    public final static String KEY_NEW_PASSWORD = "NewPwd";
    public final static String KEY_PASSWORD_MODE = "PwdMode";
    public final static String KEY_CLIENT_ID = "ClientId";

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private static void failed(Object object, FailCallback failCallback){
        JSONObject jsonObject = (JSONObject) object;
        try {
            int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
            if (null != failCallback) {
                failCallback.onFail(retCode);
            }

        } catch (JSONException e) {
            e.printStackTrace();
            if (null != failCallback) {
                failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
            }
        }
    }

    /**
     * @param
     * @return
     * @author henmory
     * @date 5/27/17
     * @description init the request of service's verification code
     */
    public static void initVerificationRequest(Context context,  String key, String value,
                                               final SuccessCallback successCallback,
                                               final FailCallback failCallback) {
        serviceInterface.initVerificationRequest(context, key, value, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(tag, "initVerificationRequest: " + object.toString());
                JSONObject jsonObject = (JSONObject) object;
                try {
                    int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                    if (retCode == 0) {//success
                        if (null != successCallback) {
                            JSONObject data = jsonObject.getJSONObject(ServerConfig.KEY_DATA);
                            String sessionID = data.getString(KEY_SESSION_ID);
                            successCallback.onSuccess(sessionID);
                        }

                    } else {
                        if (null != failCallback) {
                            failCallback.onFail(retCode);
                        }
                    }
                } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                    e.printStackTrace();
                    if (null != failCallback) {
                        failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                    }
                }

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d(tag, "initVerificationRequest: " + object.toString());
                failed(object, failCallback);
            }
        });

    }
    /**
     *  @author henmory
     *  @date 5/27/17
     *  @description get sms code
     *
     *  @param
     *        codeType
     *        0:注册
     *        1:找回密码
     *        2:登陆
     *
     *  @return
    */
     public static void getSMSVerificationCode(Context context,  String phoneNumber, String codeType,
                                               String sessionId, String graphicCode,
                                            final SuccessCallback successCallback, final FailCallback failCallback){
         serviceInterface.getSMSVerificationCode(context, phoneNumber, codeType, sessionId, graphicCode, new SuccessCallback() {
             @Override
             public void onSuccess(Object object) {
                 Log.d(tag, "getVerificationCode: " + object.toString());
                 JSONObject jsonObject = (JSONObject) object;
                 try {
                     int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                     if (retCode == 0) {//success
                         if (null != successCallback) {// TODO: 6/1/17 the reason of data lost is unknown
//                             JSONObject data = jsonObject.getJSONObject(ServerConfig.KEY_DATA);
//                             String reqID = data.getString(KEY_REQ_ID);
                             successCallback.onSuccess(retCode);
                         }

                     } else {
                         if (null != failCallback) {
                             failCallback.onFail(retCode);
                         }
                     }
                 } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                     e.printStackTrace();
                     if (null != failCallback) {
                         failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                     }
                 }
             }
         }, new FailCallback() {
             @Override
             public void onFail(Object object) {
                 Log.d(tag, "getVerificationCode: " + object.toString());
                 failed(object, failCallback);
             }
         });
     }

    /**
     *  @author henmory
     *  @date 5/31/17
     *  @description get image code
     *
     *  @param
     *
     *  @return
    */
    public static void getImageVerificationCode(Context context,  String phoneNumber, String sessionId,
                                           final SuccessCallback successCallback,
                                           final FailCallback failCallback){
        serviceInterface.getImageVerificationCode(context, phoneNumber, sessionId, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(tag, "getImageVerificationCode: " + object.toString());
                if (null != successCallback) {
                    successCallback.onSuccess(object);
                }

            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d(tag, "getVerificationCode: " + object.toString());
                failed(object, failCallback);
            }
        });
    }

    /**
     *  @author henmory
     *  @date 5/31/17
     *  @description verify verification
     *
     *  @param
     *      codeType
     *          0:注册
     *          1:找回密码
     *          2:登陆
     *
     *  @return
    */


    public static void verifyVerificationCode(Context context,  String phoneNumber, String codeType, String sessionId, String verificationCode,
                                              final SuccessCallback successCallback,
                                              final FailCallback failCallback){
        serviceInterface.verifyVerificationCode(context, phoneNumber, codeType, sessionId, verificationCode,
                new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        Log.d(tag, "verifyVerificationCode: " + object.toString());
                        JSONObject jsonObject = (JSONObject) object;
                        try {
                            int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                            if (retCode == 0) {//success---code
                                if (null != successCallback) {
                                    successCallback.onSuccess(retCode);
                                }

                            } else {
                                if (null != failCallback) {
                                    failCallback.onFail(retCode);
                                }
                            }
                        } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                            e.printStackTrace();
                            if (null != failCallback) {
                                failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                            }
                        }
                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        Log.d(tag, "getVerificationCode: " + object.toString());
                        failed(object, failCallback);
                    }
                });

    }

    /**
     *  @author henmory
     *  @date 6/1/17
     *  @description register
     *
     *  @param
     *
     *  @return
    */

    public static void register(Context context,  String phoneNumber, String newPwd, int pwdMode,
                          int clientId, String verificationCode, final SuccessCallback successCallback,
                          final FailCallback failCallback){
        serviceInterface.register(context, phoneNumber, newPwd, pwdMode, clientId, verificationCode, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(tag, "register: " + object.toString());
                JSONObject jsonObject = (JSONObject) object;
                try {
                    int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                    if (retCode == 0) {//success---code
                        if (null != successCallback) {
                            successCallback.onSuccess(retCode);
                        }

                    } else {
                        if (null != failCallback) {
                            failCallback.onFail(retCode);
                        }
                    }
                } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                    e.printStackTrace();
                    if (null != failCallback) {
                        failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                    }
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d(tag, "register: " + object.toString());
                failed(object, failCallback);
            }
        });
    }

    /**
     *  @author henmory
     *  @date 6/2/17
     *  @description verify wheather the user exists
     *
     *  @param
     *
     *  @return
    */

    public static void verifyUserWhetherExist(Context context,  String phoneNumber,
                                        final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.verifyUserWhetherExist(context, phoneNumber, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(tag, "verifyUserWhetherExist: " + object.toString());
                JSONObject jsonObject = (JSONObject) object;
                try {
                    int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                    if (retCode == 0) {//success---code
                        if (null != successCallback) {
                            boolean ret = jsonObject.getBoolean(PersonService.KEY_DADA);
                            successCallback.onSuccess(ret);
                        }

                    } else {
                        if (null != failCallback) {
                            failCallback.onFail(retCode);
                        }
                    }
                } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                    e.printStackTrace();
                    if (null != failCallback) {
                        failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                    }
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d(tag, "verifyUserWhetherExist: " + object.toString());
                failed(object, failCallback);
            }
        });

    }


    private static  void getDeadLine(JSONObject object) throws JSONException {
        JSONObject jsonObject = object.getJSONObject(PersonService.KEY_EXTRA);
        JSONObject jsonObject1 = jsonObject.getJSONObject(PersonService.KEY_USERBASE);
        String deadLine = jsonObject1.getString(PersonService.KEY_SERVICEDEADLINE);
        Config.deadLine = deadLine;
    }
    /**
     *  @author henmory
     *  @date 6/1/17
     *  @description register
     *
     *  @param
     *
     *  @return
     */

    public static void login(Context context,  String phoneNumber, String curPwd, int pwdMode,
                                int clientId, final SuccessCallback successCallback,
                                final FailCallback failCallback){
        serviceInterface.login(context, phoneNumber, curPwd, pwdMode, clientId, new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(tag, "login: " + object.toString());
                JSONObject jsonObject = (JSONObject) object;
                try {
                    int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                    if (retCode == 0) {//success---code
                        if (null != successCallback) {
                            JSONObject jsonObject1 = jsonObject.getJSONObject(PersonService.KEY_DADA);
                            getDeadLine(jsonObject1);

                            successCallback.onSuccess(jsonObject1.getString(PersonService.KEY_TOKEN));
                        }

                    } else {
                        if (null != failCallback) {
                            failCallback.onFail(retCode);
                        }
                    }
                } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                    e.printStackTrace();
                    if (null != failCallback) {
                        failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                    }
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d(tag, "login: " + object.toString());
                failed(object, failCallback);
            }
        });
    }


    public static void reset(Context context,  String phoneNumber, String newPwd,
                             int pwdMode, String verifyCode, final SuccessCallback successCallback,
                             final FailCallback failCallback){
        serviceInterface.reset(context, phoneNumber, newPwd, pwdMode, verifyCode,
                new SuccessCallback() {
            @Override
            public void onSuccess(Object object) {
                Log.d(tag, "reset: " + object.toString());
                JSONObject jsonObject = (JSONObject) object;
                try {
                    int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                    if (retCode == 0) {//success---code
                        if (null != successCallback) {
//                            String ret = jsonObject.getString(PersonService.KEY_DADA);
                            successCallback.onSuccess(retCode);
                        }

                    } else {
                        if (null != failCallback) {
                            failCallback.onFail(retCode);
                        }
                    }
                } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                    e.printStackTrace();
                    if (null != failCallback) {
                        failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                    }
                }
            }
        }, new FailCallback() {
            @Override
            public void onFail(Object object) {
                Log.d(tag, "reset: " + object.toString());
                failed(object, failCallback);
            }
        });
    }

    public static void modifyPwd(Context context,  String phoneNumber, String curPwd, String newPwd,
                             int pwdMode, final SuccessCallback successCallback,
                             final FailCallback failCallback){
        serviceInterface.modifyPassword(context, phoneNumber, curPwd, newPwd, pwdMode,
                new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        Log.d(tag, "modifyPwd: " + object.toString());
                        JSONObject jsonObject = (JSONObject) object;
                        try {
                            int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                            if (retCode == 0) {//success---code
                                if (null != successCallback) {
//                            String ret = jsonObject.getString(PersonService.KEY_DADA);
                                    successCallback.onSuccess(retCode);
                                }

                            } else {
                                if (null != failCallback) {
                                    failCallback.onFail(retCode);
                                }
                            }
                        } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                            e.printStackTrace();
                            if (null != failCallback) {
                                failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                            }
                        }
                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        Log.d(tag, "modifyPwd: " + object.toString());
                        failed(object, failCallback);
                    }
                });
    }

    public static void logout(Context context, String token,  final SuccessCallback successCallback, final FailCallback failCallback){
        serviceInterface.logout(context, token, new SuccessCallback() {
                    @Override
                    public void onSuccess(Object object) {
                        Log.d(tag, "logout: " + object.toString());
                        JSONObject jsonObject = (JSONObject) object;
                        try {
                            int retCode = jsonObject.getInt(ServerConfig.KEY_STATUS_CODE);
                            if (retCode == 0) {//success---code
                                if (null != successCallback) {
//                            String ret = jsonObject.getString(PersonService.KEY_DADA);
                                    successCallback.onSuccess(retCode);
                                }

                            } else {
                                if (null != failCallback) {
                                    failCallback.onFail(retCode);
                                }
                            }
                        } catch (JSONException e) {//not find the key of ServerConfig.KEY_STATUS_CODE,
                            e.printStackTrace();
                            if (null != failCallback) {
                                failCallback.onFail(ServerConfig.PARSE_DATA_FAILED_ERROR_CODE);
                            }
                        }
                    }
                }, new FailCallback() {
                    @Override
                    public void onFail(Object object) {
                        Log.d(tag, "logout: " + object.toString());
                        failed(object, failCallback);
                    }
                });

    }
}
