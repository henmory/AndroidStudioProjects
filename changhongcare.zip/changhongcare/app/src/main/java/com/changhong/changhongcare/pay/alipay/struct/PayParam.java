package com.changhong.changhongcare.pay.alipay.struct;

/**
 * author: henmory
 * time:  6/8/17
 * function:
 * description:
 */

public class PayParam {
    private String channel; //支付渠道: {0:支付宝 1:微信}
    private int type;//0:购买服务
    private double amount;//消费金额
    private int month;//可用月份

    public PayParam(String channel, int type, double amount, int month) {
        this.channel = channel;
        this.type = type;
        this.amount = amount;
        this.month = month;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }
}
